﻿Public Class Form2

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If MessageBox.Show("Queres sair do Promo de Blackjack", "Blackjack", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) = Windows.Forms.DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Form1.Show()
        Form1.Button1.Text = TextBox1.Text
        Form1.Button2.Text = TextBox2.Text
        Form1.Label1.Text = TextBox1.Text
        Form1.Label5.Text = TextBox2.Text
        Me.Visible = False
    End Sub

    Private Sub Label7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label7.Click

    End Sub
End Class