﻿Public Class Form1
    Public P1Cards As Integer = 0
    Public P2Cards As Integer = 0
    Public P1Score As Integer = 0
    Public P2Score As Integer = 0
    Dim TheRandomClass As New Random
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim TheRandomClass As New Random
        Dim i As Integer = 0

        i = TheRandomClass.Next(1, 6)

        Label2.Text = i.ToString

        P1Cards += i

        Label1.Text = "Player 1 Cards: " + P1Cards.ToString

        If Label2.Text = 1 Then

            PictureBox1.Visible = True

            PictureBox2.Visible = False

            PictureBox3.Visible = False

            PictureBox4.Visible = False

            PictureBox5.Visible = False

        End If

        If Label2.Text = 2 Then

            PictureBox1.Visible = False

            PictureBox2.Visible = True

            PictureBox3.Visible = False

            PictureBox4.Visible = False

            PictureBox5.Visible = False

        End If

        If Label2.Text = 3 Then

            PictureBox1.Visible = False

            PictureBox2.Visible = False

            PictureBox3.Visible = True

            PictureBox4.Visible = False

            PictureBox5.Visible = False

        End If

        If Label2.Text = 4 Then

            PictureBox1.Visible = False

            PictureBox2.Visible = False

            PictureBox3.Visible = False

            PictureBox4.Visible = True

            PictureBox5.Visible = False

        End If

        If Label2.Text = 5 Then

            PictureBox1.Visible = False

            PictureBox2.Visible = False

            PictureBox3.Visible = False

            PictureBox4.Visible = False

            PictureBox5.Visible = True

        End If

        If P1Cards > 21 Then

            MsgBox("Falhou!", MsgBoxStyle.Critical, "Game_Over")

            P1Cards = 0

            Label2.Text = ""

            Label1.Text = "Player 1 Cards: 0"

            Button1.Enabled = False

            Button2.Enabled = True

            PictureBox1.Visible = False

            PictureBox2.Visible = False

            PictureBox3.Visible = False

            PictureBox4.Visible = False

            PictureBox5.Visible = False

        End If

        If P1Cards = 21 Then

            MsgBox("21!", MsgBoxStyle.Information, "Fim do Turno")

            P1Cards = 0

            Label4.Text = ""

            Label1.Text = "Player 1 Cards: 0"

            Dim o As Integer = 0

            o = 1

            P1Score += o

            Label4.Text = P1Score * 20

            ProgressBar1.Value = Label4.Text

            Button1.Enabled = False

            Button2.Enabled = True

            PictureBox1.Visible = False

            PictureBox2.Visible = False

            PictureBox3.Visible = False

            PictureBox4.Visible = False

            PictureBox5.Visible = False

        End If

        If ProgressBar1.Value = 100 Then

            MsgBox("1ºJogador Ganha", MsgBoxStyle.Information, "Parabens")

            Button1.Enabled = False

            Button2.Enabled = False

            Label1.Text = "Player 1 Cards: 0"

            Label5.Text = "Player 2 Cards: 0"

        End If


    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Button1.Text = "Desistir do Jogo"
        If MessageBox.Show("Queres sair do jogo", "Blackjack", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) = Windows.Forms.DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Button4.Text = "Novo Jogo"
        P1Cards = 0

        P2Cards = 0

        P1Score = 0

        P2Score = 0

        Label1.Text = "Player 1 Cards: 0"

        Label5.Text = "Player 2 Cards: 0"

        Label2.Text = ""

        Button1.Enabled = True

        Button2.Enabled = False

        ProgressBar1.Value = 0

        ProgressBar2.Value = 0

        PictureBox1.Visible = False

        PictureBox2.Visible = False

        PictureBox3.Visible = False

        PictureBox4.Visible = False

        PictureBox5.Visible = False
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim TheRandomClass As New Random

        Dim i As Integer = 0

        i = TheRandomClass.Next(1, 6)

        Label2.Text = i.ToString

        P2Cards += i

        Label5.Text = "Player 2 Cards: " + P2Cards.ToString

        If Label2.Text = 1 Then

            PictureBox1.Visible = True

            PictureBox2.Visible = False

            PictureBox3.Visible = False

            PictureBox4.Visible = False

            PictureBox5.Visible = False

        End If

        If Label2.Text = 2 Then

            PictureBox1.Visible = False

            PictureBox2.Visible = True

            PictureBox3.Visible = False

            PictureBox4.Visible = False

            PictureBox5.Visible = False

        End If

        If Label2.Text = 3 Then

            PictureBox1.Visible = False

            PictureBox2.Visible = False

            PictureBox3.Visible = True

            PictureBox4.Visible = False

            PictureBox5.Visible = False

        End If

        If Label2.Text = 4 Then

            PictureBox1.Visible = False

            PictureBox2.Visible = False

            PictureBox3.Visible = False

            PictureBox4.Visible = True

            PictureBox5.Visible = False

        End If

        If Label2.Text = 5 Then

            PictureBox1.Visible = False

            PictureBox2.Visible = False

            PictureBox3.Visible = False

            PictureBox4.Visible = False

            PictureBox5.Visible = True

        End If

        If P2Cards > 21 Then

            MsgBox("Falhou!", MsgBoxStyle.Critical, "Game Over")

            P2Cards = 0

            Label2.Text = ""

            Label5.Text = "Player 2 Cards: 0"

            Button2.Enabled = False

            Button1.Enabled = True

            PictureBox1.Visible = False

            PictureBox2.Visible = False

            PictureBox3.Visible = False

            PictureBox4.Visible = False

            PictureBox5.Visible = False

        End If

        If P2Cards = 21 Then

            MsgBox("21!", MsgBoxStyle.Information, "Fim_Tudo")

            P2Cards = 0

            Label2.Text = ""

            Label5.Text = "Player 2 Cards: 0"

            Dim o As Integer = 0

            o = 1

            P2Score += o

            Label7.Text = P2Score * 20

            ProgressBar2.Value = Label7.Text

            Button2.Enabled = False

            Button1.Enabled = True

            PictureBox1.Visible = False

            PictureBox2.Visible = False

            PictureBox3.Visible = False

            PictureBox4.Visible = False

            PictureBox5.Visible = False

        End If

        If ProgressBar2.Value = 100 Then

            MsgBox("2ºJogador Ganha!", MsgBoxStyle.Information, "Parabens")

            Button1.Enabled = False

            Button2.Enabled = False

            Label1.Text = "Player 1 Cards: 0"

            Label5.Text = "Player 2 Cards: 0"

        End If
    End Sub

    Private Sub ProgressBar2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProgressBar2.Click

    End Sub

    Private Sub ProgressBar1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProgressBar1.Click

    End Sub
End Class
