﻿Public Class Form1
    Dim num As Integer
    Dim r As New Random
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        If Val(TextBox1.Text) < num And Val(TextBox1.Text) <> num Then

            MessageBox.Show("O numero é maior", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If
        If Val(TextBox1.Text) <> num And Val(TextBox1.Text) = num Then

            MessageBox.Show("Parabens acertou", "OKI DOKI", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

        If Val(TextBox1.Text) > num And Val(TextBox1.Text) <> num Then

            MessageBox.Show("O numero é menor", "aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If

        If TextBox1.Text = "" Then

            MessageBox.Show("Tem que introduzir um palpite!!!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If


    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        num = r.Next(100)
        TextBox1.Focus()
        TextBox1.Clear()
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
       
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
