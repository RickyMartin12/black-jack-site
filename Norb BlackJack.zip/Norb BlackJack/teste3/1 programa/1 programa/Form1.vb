﻿Public Class Form1

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            Me.Text = "Color Mix//" & DateAndTime.TimeString
        End If
        If CheckBox1.Checked = False Then
            Me.Text = "Color Mix//"
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = "Color Mix//"
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If CheckBox1.Checked = True Then
            Me.Text = "Color Mix//" & DateAndTime.TimeString
        End If
        If CheckBox1.Checked = False Then
            Me.Text = "Color Mix//"
        End If
    End Sub

    Private Sub NumericUpDown1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown1.ValueChanged
        HScrollBar1.Value = NumericUpDown1.Value
        PictureBox1.BackColor = Color.FromArgb(NumericUpDown1.Value, NumericUpDown2.Value, NumericUpDown3.Value)
    End Sub

    Private Sub NumericUpDown2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown2.ValueChanged
        HScrollBar2.Value = NumericUpDown2.Value
        PictureBox1.BackColor = Color.FromArgb(NumericUpDown1.Value, NumericUpDown2.Value, NumericUpDown3.Value)
    End Sub

    Private Sub NumericUpDown3_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown3.ValueChanged
        HScrollBar3.Value = NumericUpDown3.Value
        PictureBox1.BackColor = Color.FromArgb(NumericUpDown1.Value, NumericUpDown2.Value, NumericUpDown3.Value)
    End Sub



    Private Sub HScrollBar1_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles HScrollBar1.Scroll
        NumericUpDown1.Value = HScrollBar1.Value
        PictureBox1.BackColor = Color.FromArgb(NumericUpDown1.Value, NumericUpDown2.Value, NumericUpDown3.Value)
    End Sub

    Private Sub HScrollBar2_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles HScrollBar2.Scroll
        NumericUpDown2.Value = HScrollBar2.Value
        PictureBox1.BackColor = Color.FromArgb(NumericUpDown1.Value, NumericUpDown2.Value, NumericUpDown3.Value)
    End Sub

    Private Sub HScrollBar3_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles HScrollBar3.Scroll
        NumericUpDown3.Value = HScrollBar3.Value
        PictureBox1.BackColor = Color.FromArgb(NumericUpDown1.Value, NumericUpDown2.Value, NumericUpDown3.Value)
    End Sub
End Class
