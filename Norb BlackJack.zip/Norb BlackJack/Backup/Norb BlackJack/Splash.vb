﻿Public Class Splash
    Public Cont As Integer

    Private Sub ProgressBar1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub



    Private Sub Splash_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ProgressBar1.Value = 0
        ProgressBar1.Maximum = 100
        Timer1.Enabled = True
        Timer1.Interval = 100
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If Cont < 100 Then
            ProgressBar1.Value = Cont
            Cont = Cont + 1
            Label2.Text = Cont & " % Concluido"
        Else
            Form2.StartPosition = FormStartPosition.CenterScreen
            Form2.Visible = True
            Me.Visible = False
            Timer1.Enabled = False
        End If
    End Sub
End Class