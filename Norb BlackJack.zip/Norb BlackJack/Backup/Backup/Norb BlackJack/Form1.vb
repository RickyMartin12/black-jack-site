﻿Public Class Form1
    Dim stage As Integer

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Close()
    End Sub

    Private Sub PictureBox1_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.MouseEnter
        PictureBox1.Height = PictureBox1.Height + 3
        PictureBox1.Top = PictureBox1.Top - 3
        Label1.Visible = True
    End Sub

    Private Sub PictureBox1_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.MouseLeave
        PictureBox1.Height = PictureBox1.Height - 3
        PictureBox1.Top = PictureBox1.Top + 3
        Label1.Visible = False
    End Sub

    Private Sub your_bet_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles your_bet.TextChanged
        Try
            If your_bet.Text < 100000 Then
                total_bets.Text = your_bet.Text * 2
                your_bet.ForeColor = Color.Black
                total_bets.ForeColor = Color.White
                out_cash.ForeColor = Color.White
                betButton.Enabled = True
            Else
                your_bet.ForeColor = Color.Black
                total_bets.ForeColor = Color.White
                betButton.Enabled = False
            End If
        Catch ex As Exception
            your_bet.Text = 0
        End Try
    End Sub

    Private Sub ExitToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem1.Click
        Close()
    End Sub

    Private Sub betButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles betButton.Click
        If out_cash.Text - your_bet.Text >= 0 Then
            your_bet.Enabled = False
            betButton.Enabled = False
            PictureBox1.Enabled = True
            out_cash.Text = out_cash.Text - your_bet.Text
            Button1.Enabled = True
        Else
            debug.Text = 1
            flasH_red.Enabled = True
            MsgBox("Já não tens dinheiro para jogar", 0, "Para!")
        End If
    End Sub

    Private Sub flasH_red_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles flasH_red.Tick
        If debug.Text = 1 Then
            out_cash.ForeColor = Color.Gold
            debug.Text = 2
        Else
            If debug.Text = 2 Then
                out_cash.ForeColor = Color.White
                debug.Text = 3
            Else
                If debug.Text = 3 Then
                    out_cash.ForeColor = Color.Gold
                    debug.Text = 4
                Else
                    If debug.Text = 4 Then
                        out_cash.ForeColor = Color.White
                        debug.Text = 1
                        flasH_red.Enabled = False
                    Else
                    End If
                End If
            End If
        End If
    End Sub

    Public Sub UpdateScore()
        Dim ps1 As Integer
        Dim ps2 As Integer
        Dim ps3 As Integer
        Dim ps4 As Integer
        Dim ps5 As Integer
        ps1 = player_score1.Text
        ps2 = player_score2.Text
        ps3 = player_score3.Text
        ps4 = player_score4.Text
        ps5 = player_score5.Text
        points.Text = ps1 + ps2 + ps3 + ps4 + ps5
        ps1 = op_score1.Text
        ps2 = op_score2.Text
        ps3 = op_score3.Text
        ps4 = op_score4.Text
        ps5 = op_score5.Text
        out_op_score.Text = ps1 + ps2 + ps3 + ps4 + ps5
        If points.Text < 19 Then
            points.ForeColor = Color.White
        End If
        If points.Text >= 19 And points.Text < 22 Then
            points.ForeColor = Color.LawnGreen
        End If
        If points.Text > 21 Then
            points.ForeColor = Color.Gold
        End If
        If out_op_score.Text < 19 Then
            out_op_score.ForeColor = Color.White
        End If
        If out_op_score.Text >= 19 And points.Text < 22 Then
            out_op_score.ForeColor = Color.LawnGreen
        End If
        If out_op_score.Text > 21 Then
            out_op_score.ForeColor = Color.Gold
        End If
        Try
            My.Computer.Audio.Play("DEAL.wav")
        Catch ex As Exception
        End Try
    End Sub

    Public Sub PlayerDealFirst()
        Dim RC As Integer
        Randomize()
        RC = 53 * Rnd()
        If RC = 53 Or RC = 0 Or RC = mem_op_card1.Text Or RC = mem_op_card2.Text Or RC = mem_op_card3.Text Or RC = mem_op_card4.Text Or RC = mem_op_card5.Text Or RC = mem_player_card1.Text Or RC = mem_player_card2.Text Or RC = mem_player_card3.Text Or RC = mem_player_card4.Text Or RC = mem_player_card5.Text Then
            PlayerDealFirst()
        Else
            player_card1.Visible = True
            player_score1.Visible = True
            If RC = 1 Or RC = 14 Or RC = 27 Or RC = 40 Then
                player_card1.Cursor = Cursors.Hand
                player_card1.ContextMenuStrip = card1MenuStrip
            End If
            If RC = 1 Then
                'CARD ID:1 = Ace of Hearths
                player_card1.Image = My.Resources.H1
                mem_player_card1.Text = 1
                player_score1.Text = 11
            End If
            If RC = 2 Then
                'CARD ID:2 = Two of Hearths
                player_card1.Image = My.Resources.H2
                mem_player_card1.Text = 2
                player_score1.Text = 2
            End If
            If RC = 3 Then
                'CARD ID:3 = Three of Hearths
                player_card1.Image = My.Resources.H3
                mem_player_card1.Text = 3
                player_score1.Text = 3
            End If
            If RC = 4 Then
                'CARD ID:4 = Four of Hearths
                player_card1.Image = My.Resources.H4
                mem_player_card1.Text = 4
                player_score1.Text = 4
            End If
            If RC = 5 Then
                'CARD ID:5 = Five of Hearths
                player_card1.Image = My.Resources.H5
                mem_player_card1.Text = 5
                player_score1.Text = 5
            End If
            If RC = 6 Then
                'CARD ID:6 = Six of Hearths
                player_card1.Image = My.Resources.H6
                mem_player_card1.Text = 6
                player_score1.Text = 6
            End If
            If RC = 7 Then
                'CARD ID:7 = Seven of Hearths
                player_card1.Image = My.Resources.H7
                mem_player_card1.Text = 7
                player_score1.Text = 7
            End If
            If RC = 8 Then
                'CARD ID:8 = Eight of Hearths
                player_card1.Image = My.Resources.H8
                mem_player_card1.Text = 8
                player_score1.Text = 8
            End If
            If RC = 9 Then
                'CARD ID:9 = Nine of Hearths
                player_card1.Image = My.Resources.H9
                mem_player_card1.Text = 9
                player_score1.Text = 9
            End If
            If RC = 10 Then
                'CARD ID:10 = Ten of Hearths
                player_card1.Image = My.Resources.H10
                mem_player_card1.Text = 10
                player_score1.Text = 10
            End If
            If RC = 11 Then
                'CARD ID:11 = Jack of Hearths
                player_card1.Image = My.Resources.H11
                mem_player_card1.Text = 11
                player_score1.Text = 10
            End If
            If RC = 12 Then
                'CARD ID:12 = Queen of Hearths
                player_card1.Image = My.Resources.H12
                mem_player_card1.Text = 12
                player_score1.Text = 10
            End If
            If RC = 13 Then
                'CARD ID:13 = King of Hearths
                player_card1.Image = My.Resources.H13
                mem_player_card1.Text = 13
                player_score1.Text = 10
            End If
            If RC = 14 Then
                'CARD ID:14 = Ace of Clubs
                player_card1.Image = My.Resources.C1
                mem_player_card1.Text = 14
                player_score1.Text = 11
            End If
            If RC = 15 Then
                'CARD ID:15 = Two of Clubs
                player_card1.Image = My.Resources.C2
                mem_player_card1.Text = 15
                player_score1.Text = 2
            End If
            If RC = 16 Then
                'CARD ID:16 = Three of Clubs
                player_card1.Image = My.Resources.C3
                mem_player_card1.Text = 16
                player_score1.Text = 3
            End If
            If RC = 17 Then
                'CARD ID:17 = Four of Clubs
                player_card1.Image = My.Resources.C4
                mem_player_card1.Text = 17
                player_score1.Text = 4
            End If
            If RC = 18 Then
                'CARD ID:18 = Five of Clubs
                player_card1.Image = My.Resources.C5
                mem_player_card1.Text = 18
                player_score1.Text = 5
            End If
            If RC = 19 Then
                'CARD ID:19 = Six of Clubs
                player_card1.Image = My.Resources.C6
                mem_player_card1.Text = 19
                player_score1.Text = 6
            End If
            If RC = 20 Then
                'CARD ID:20 = Seven of Clubs
                player_card1.Image = My.Resources.C7
                mem_player_card1.Text = 20
                player_score1.Text = 7
            End If
            If RC = 21 Then
                'CARD ID:21 = Eight of Clubs
                player_card1.Image = My.Resources.C8
                mem_player_card1.Text = 21
                player_score1.Text = 8
            End If
            If RC = 22 Then
                'CARD ID:22 = Nine of Clubs
                player_card1.Image = My.Resources.C9
                mem_player_card1.Text = 22
                player_score1.Text = 9
            End If
            If RC = 23 Then
                'CARD ID:23 = Ten of Clubs
                player_card1.Image = My.Resources.C10
                mem_player_card1.Text = 23
                player_score1.Text = 10
            End If
            If RC = 24 Then
                'CARD ID:24 = Jack of Clubs
                player_card1.Image = My.Resources.C11
                mem_player_card1.Text = 24
                player_score1.Text = 10
            End If
            If RC = 25 Then
                'CARD ID:25 = Queen of Clubs
                player_card1.Image = My.Resources.C12
                mem_player_card1.Text = 25
                player_score1.Text = 10
            End If
            If RC = 26 Then
                'CARD ID:26 = King of Clubs
                player_card1.Image = My.Resources.C13
                mem_player_card1.Text = 26
                player_score1.Text = 10
            End If
            If RC = 27 Then
                'CARD ID:27 = Ace of Diamonds
                player_card1.Image = My.Resources.D1
                mem_player_card1.Text = 27
                player_score1.Text = 11
            End If
            If RC = 28 Then
                'CARD ID:28 = Two of Diamonds
                player_card1.Image = My.Resources.D2
                mem_player_card1.Text = 28
                player_score1.Text = 2
            End If
            If RC = 29 Then
                'CARD ID:27 = Three of Diamonds
                player_card1.Image = My.Resources.D3
                mem_player_card1.Text = 29
                player_score1.Text = 3
            End If
            If RC = 30 Then
                'CARD ID:30 = Four of Diamonds
                player_card1.Image = My.Resources.D4
                mem_player_card1.Text = 30
                player_score1.Text = 4
            End If
            If RC = 31 Then
                'CARD ID:31 = Five of Diamonds
                player_card1.Image = My.Resources.D5
                mem_player_card1.Text = 31
                player_score1.Text = 5
            End If
            If RC = 32 Then
                'CARD ID:32 = Six of Diamonds
                player_card1.Image = My.Resources.D6
                mem_player_card1.Text = 32
                player_score1.Text = 6
            End If
            If RC = 33 Then
                'CARD ID:33 = Seven of Diamonds
                player_card1.Image = My.Resources.D7
                mem_player_card1.Text = 33
                player_score1.Text = 7
            End If
            If RC = 34 Then
                'CARD ID:34 = Eight of Diamonds
                player_card1.Image = My.Resources.D8
                mem_player_card1.Text = 34
                player_score1.Text = 8
            End If
            If RC = 35 Then
                'CARD ID:35 = Nine of Diamonds
                player_card1.Image = My.Resources.D9
                mem_player_card1.Text = 35
                player_score1.Text = 9
            End If
            If RC = 36 Then
                'CARD ID:36 = Ten of Diamonds
                player_card1.Image = My.Resources.D10
                mem_player_card1.Text = 36
                player_score1.Text = 10
            End If
            If RC = 37 Then
                'CARD ID:37 = Jack of Diamonds
                player_card1.Image = My.Resources.D11
                mem_player_card1.Text = 37
                player_score1.Text = 10
            End If
            If RC = 38 Then
                'CARD ID:38 = Queen of Diamonds
                player_card1.Image = My.Resources.D12
                mem_player_card1.Text = 38
                player_score1.Text = 10
            End If
            If RC = 39 Then
                'CARD ID:39 = King of Diamonds
                player_card1.Image = My.Resources.D13
                mem_player_card1.Text = 39
                player_score1.Text = 10
            End If
            If RC = 40 Then
                'CARD ID:40 = Ace of Spades
                player_card1.Image = My.Resources.S1
                mem_player_card1.Text = 40
                player_score1.Text = 11
            End If
            If RC = 41 Then
                'CARD ID:41 = Two of Spades
                player_card1.Image = My.Resources.S2
                mem_player_card1.Text = 41
                player_score1.Text = 2
            End If
            If RC = 42 Then
                'CARD ID:42 = Three of Spades
                player_card1.Image = My.Resources.S3
                mem_player_card1.Text = 42
                player_score1.Text = 3
            End If
            If RC = 43 Then
                'CARD ID:43 = Four of Spades
                player_card1.Image = My.Resources.S4
                mem_player_card1.Text = 43
                player_score1.Text = 4
            End If
            If RC = 44 Then
                'CARD ID:44 = Five of Spades
                player_card1.Image = My.Resources.S5
                mem_player_card1.Text = 44
                player_score1.Text = 5
            End If
            If RC = 45 Then
                'CARD ID:45 = Six of Spades
                player_card1.Image = My.Resources.S6
                mem_player_card1.Text = 45
                player_score1.Text = 6
            End If
            If RC = 46 Then
                'CARD ID:46 = Seven of Spades
                player_card1.Image = My.Resources.S7
                mem_player_card1.Text = 46
                player_score1.Text = 7
            End If
            If RC = 47 Then
                'CARD ID:47 = Eight of Spades
                player_card1.Image = My.Resources.S8
                mem_player_card1.Text = 47
                player_score1.Text = 8
            End If
            If RC = 48 Then
                'CARD ID:48 = Nine of Spades
                player_card1.Image = My.Resources.S9
                mem_player_card1.Text = 48
                player_score1.Text = 9
            End If
            If RC = 49 Then
                'CARD ID:49 = Ten of Spades
                player_card1.Image = My.Resources.S10
                mem_player_card1.Text = 49
                player_score1.Text = 10
            End If
            If RC = 50 Then
                'CARD ID:50 = Jack of Spades
                player_card1.Image = My.Resources.S11
                mem_player_card1.Text = 50
                player_score1.Text = 10
            End If
            If RC = 51 Then
                'CARD ID:51 = Queen of Spades
                player_card1.Image = My.Resources.S12
                mem_player_card1.Text = 51
                player_score1.Text = 10
            End If
            If RC = 52 Then
                'CARD ID:52 = King of Spades
                player_card1.Image = My.Resources.S13
                mem_player_card1.Text = 52
                player_score1.Text = 10
            End If
            UpdateScore()
        End If
    End Sub

    Public Sub PlayerDealSecond()
        Dim RC As Integer
        Randomize()
        RC = 53 * Rnd()
        If (mem_player_card1.Text = 1 Or mem_player_card1.Text = 14 Or mem_player_card1.Text = 27 Or mem_player_card1.Text = 40) And (RC = 1 Or RC = 14 Or RC = 27 Or RC = 40) Then
            PlayerDealSecond()
            'Don't want to have first cards as 2 aces :P too lazy to script "splits"...
            'So if you already picked up an ace in the first deal, u will redeal the second one if u get another ace...
            'Just preventing splits.
        End If
        If RC = 53 Or RC = 0 Or RC = mem_op_card1.Text Or RC = mem_op_card2.Text Or RC = mem_op_card3.Text Or RC = mem_op_card4.Text Or RC = mem_op_card5.Text Or RC = mem_player_card1.Text Or RC = mem_player_card2.Text Or RC = mem_player_card3.Text Or RC = mem_player_card4.Text Or RC = mem_player_card5.Text Then
            PlayerDealSecond()
        Else
            player_card2.Visible = True
            player_score2.Visible = True
            If RC = 1 Or RC = 14 Or RC = 27 Or RC = 40 Then
                player_card2.Cursor = Cursors.Hand
                player_card2.ContextMenuStrip = card2MenuStrip
            End If
            If RC = 1 Then
                'CARD ID:1 = Ace of Hearths
                player_card2.Image = My.Resources.H1
                mem_player_card2.Text = 1
                player_score2.Text = 11
            End If
            If RC = 2 Then
                'CARD ID:2 = Two of Hearths
                player_card2.Image = My.Resources.H2
                mem_player_card2.Text = 2
                player_score2.Text = 2
            End If
            If RC = 3 Then
                'CARD ID:3 = Three of Hearths
                player_card2.Image = My.Resources.H3
                mem_player_card2.Text = 3
                player_score2.Text = 3
            End If
            If RC = 4 Then
                'CARD ID:4 = Four of Hearths
                player_card2.Image = My.Resources.H4
                mem_player_card2.Text = 4
                player_score2.Text = 4
            End If
            If RC = 5 Then
                'CARD ID:5 = Five of Hearths
                player_card2.Image = My.Resources.H5
                mem_player_card2.Text = 5
                player_score2.Text = 5
            End If
            If RC = 6 Then
                'CARD ID:6 = Six of Hearths
                player_card2.Image = My.Resources.H6
                mem_player_card2.Text = 6
                player_score2.Text = 6
            End If
            If RC = 7 Then
                'CARD ID:7 = Seven of Hearths
                player_card2.Image = My.Resources.H7
                mem_player_card2.Text = 7
                player_score2.Text = 7
            End If
            If RC = 8 Then
                'CARD ID:8 = Eight of Hearths
                player_card2.Image = My.Resources.H8
                mem_player_card2.Text = 8
                player_score2.Text = 8
            End If
            If RC = 9 Then
                'CARD ID:9 = Nine of Hearths
                player_card2.Image = My.Resources.H9
                mem_player_card2.Text = 9
                player_score2.Text = 9
            End If
            If RC = 10 Then
                'CARD ID:10 = Ten of Hearths
                player_card2.Image = My.Resources.H10
                mem_player_card2.Text = 10
                player_score2.Text = 10
            End If
            If RC = 11 Then
                'CARD ID:11 = Jack of Hearths
                player_card2.Image = My.Resources.H11
                mem_player_card2.Text = 11
                player_score2.Text = 10
            End If
            If RC = 12 Then
                'CARD ID:12 = Queen of Hearths
                player_card2.Image = My.Resources.H12
                mem_player_card2.Text = 12
                player_score2.Text = 10
            End If
            If RC = 13 Then
                'CARD ID:13 = King of Hearths
                player_card2.Image = My.Resources.H13
                mem_player_card2.Text = 13
                player_score2.Text = 10
            End If
            If RC = 14 Then
                'CARD ID:14 = Ace of Clubs
                player_card2.Image = My.Resources.C1
                mem_player_card2.Text = 14
                player_score2.Text = 11
            End If
            If RC = 15 Then
                'CARD ID:15 = Two of Clubs
                player_card2.Image = My.Resources.C2
                mem_player_card2.Text = 15
                player_score2.Text = 2
            End If
            If RC = 16 Then
                'CARD ID:16 = Three of Clubs
                player_card2.Image = My.Resources.C3
                mem_player_card2.Text = 16
                player_score2.Text = 3
            End If
            If RC = 17 Then
                'CARD ID:17 = Four of Clubs
                player_card2.Image = My.Resources.C4
                mem_player_card2.Text = 17
                player_score2.Text = 4
            End If
            If RC = 18 Then
                'CARD ID:18 = Five of Clubs
                player_card2.Image = My.Resources.C5
                mem_player_card2.Text = 18
                player_score2.Text = 5
            End If
            If RC = 19 Then
                'CARD ID:19 = Six of Clubs
                player_card2.Image = My.Resources.C6
                mem_player_card2.Text = 19
                player_score2.Text = 6
            End If
            If RC = 20 Then
                'CARD ID:20 = Seven of Clubs
                player_card2.Image = My.Resources.C7
                mem_player_card2.Text = 20
                player_score2.Text = 7
            End If
            If RC = 21 Then
                'CARD ID:21 = Eight of Clubs
                player_card2.Image = My.Resources.C8
                mem_player_card2.Text = 21
                player_score2.Text = 8
            End If
            If RC = 22 Then
                'CARD ID:22 = Nine of Clubs
                player_card2.Image = My.Resources.C9
                mem_player_card2.Text = 22
                player_score2.Text = 9
            End If
            If RC = 23 Then
                'CARD ID:23 = Ten of Clubs
                player_card2.Image = My.Resources.C10
                mem_player_card2.Text = 23
                player_score2.Text = 10
            End If
            If RC = 24 Then
                'CARD ID:24 = Jack of Clubs
                player_card2.Image = My.Resources.C11
                mem_player_card2.Text = 24
                player_score2.Text = 10
            End If
            If RC = 25 Then
                'CARD ID:25 = Queen of Clubs
                player_card2.Image = My.Resources.C12
                mem_player_card2.Text = 25
                player_score2.Text = 10
            End If
            If RC = 26 Then
                'CARD ID:26 = King of Clubs
                player_card2.Image = My.Resources.C13
                mem_player_card2.Text = 26
                player_score2.Text = 10
            End If
            If RC = 27 Then
                'CARD ID:27 = Ace of Diamonds
                player_card2.Image = My.Resources.D1
                mem_player_card2.Text = 27
                player_score2.Text = 11
            End If
            If RC = 28 Then
                'CARD ID:28 = Two of Diamonds
                player_card2.Image = My.Resources.D2
                mem_player_card2.Text = 28
                player_score2.Text = 2
            End If
            If RC = 29 Then
                'CARD ID:27 = Three of Diamonds
                player_card2.Image = My.Resources.D3
                mem_player_card2.Text = 29
                player_score2.Text = 3
            End If
            If RC = 30 Then
                'CARD ID:30 = Four of Diamonds
                player_card2.Image = My.Resources.D4
                mem_player_card2.Text = 30
                player_score2.Text = 4
            End If
            If RC = 31 Then
                'CARD ID:31 = Five of Diamonds
                player_card2.Image = My.Resources.D5
                mem_player_card2.Text = 31
                player_score2.Text = 5
            End If
            If RC = 32 Then
                'CARD ID:32 = Six of Diamonds
                player_card2.Image = My.Resources.D6
                mem_player_card2.Text = 32
                player_score2.Text = 6
            End If
            If RC = 33 Then
                'CARD ID:33 = Seven of Diamonds
                player_card2.Image = My.Resources.D7
                mem_player_card2.Text = 33
                player_score2.Text = 7
            End If
            If RC = 34 Then
                'CARD ID:34 = Eight of Diamonds
                player_card2.Image = My.Resources.D8
                mem_player_card2.Text = 34
                player_score2.Text = 8
            End If
            If RC = 35 Then
                'CARD ID:35 = Nine of Diamonds
                player_card2.Image = My.Resources.D9
                mem_player_card2.Text = 35
                player_score2.Text = 9
            End If
            If RC = 36 Then
                'CARD ID:36 = Ten of Diamonds
                player_card2.Image = My.Resources.D10
                mem_player_card2.Text = 36
                player_score2.Text = 10
            End If
            If RC = 37 Then
                'CARD ID:37 = Jack of Diamonds
                player_card2.Image = My.Resources.D11
                mem_player_card2.Text = 37
                player_score2.Text = 10
            End If
            If RC = 38 Then
                'CARD ID:38 = Queen of Diamonds
                player_card2.Image = My.Resources.D12
                mem_player_card2.Text = 38
                player_score2.Text = 10
            End If
            If RC = 39 Then
                'CARD ID:39 = King of Diamonds
                player_card2.Image = My.Resources.D13
                mem_player_card2.Text = 39
                player_score2.Text = 10
            End If
            If RC = 40 Then
                'CARD ID:40 = Ace of Spades
                player_card2.Image = My.Resources.S1
                mem_player_card2.Text = 40
                player_score2.Text = 11
            End If
            If RC = 41 Then
                'CARD ID:41 = Two of Spades
                player_card2.Image = My.Resources.S2
                mem_player_card2.Text = 41
                player_score2.Text = 2
            End If
            If RC = 42 Then
                'CARD ID:42 = Three of Spades
                player_card2.Image = My.Resources.S3
                mem_player_card2.Text = 42
                player_score2.Text = 3
            End If
            If RC = 43 Then
                'CARD ID:43 = Four of Spades
                player_card2.Image = My.Resources.S4
                mem_player_card2.Text = 43
                player_score2.Text = 4
            End If
            If RC = 44 Then
                'CARD ID:44 = Five of Spades
                player_card2.Image = My.Resources.S5
                mem_player_card2.Text = 44
                player_score2.Text = 5
            End If
            If RC = 45 Then
                'CARD ID:45 = Six of Spades
                player_card2.Image = My.Resources.S6
                mem_player_card2.Text = 45
                player_score2.Text = 6
            End If
            If RC = 46 Then
                'CARD ID:46 = Seven of Spades
                player_card2.Image = My.Resources.S7
                mem_player_card2.Text = 46
                player_score2.Text = 7
            End If
            If RC = 47 Then
                'CARD ID:47 = Eight of Spades
                player_card2.Image = My.Resources.S8
                mem_player_card2.Text = 47
                player_score2.Text = 8
            End If
            If RC = 48 Then
                'CARD ID:48 = Nine of Spades
                player_card2.Image = My.Resources.S9
                mem_player_card2.Text = 48
                player_score2.Text = 9
            End If
            If RC = 49 Then
                'CARD ID:49 = Ten of Spades
                player_card2.Image = My.Resources.S10
                mem_player_card2.Text = 49
                player_score2.Text = 10
            End If
            If RC = 50 Then
                'CARD ID:50 = Jack of Spades
                player_card2.Image = My.Resources.S11
                mem_player_card2.Text = 50
                player_score2.Text = 10
            End If
            If RC = 51 Then
                'CARD ID:51 = Queen of Spades
                player_card2.Image = My.Resources.S12
                mem_player_card2.Text = 51
                player_score2.Text = 10
            End If
            If RC = 52 Then
                'CARD ID:52 = King of Spades
                player_card2.Image = My.Resources.S13
                mem_player_card2.Text = 52
                player_score2.Text = 10
            End If
            UpdateScore()
        End If
    End Sub

    Public Sub PlayerDealThird()
        Dim RC As Integer
        Randomize()
        RC = 53 * Rnd()
        If RC = 53 Or RC = 0 Or RC = mem_op_card1.Text Or RC = mem_op_card2.Text Or RC = mem_op_card3.Text Or RC = mem_op_card4.Text Or RC = mem_op_card5.Text Or RC = mem_player_card1.Text Or RC = mem_player_card2.Text Or RC = mem_player_card3.Text Or RC = mem_player_card4.Text Or RC = mem_player_card5.Text Then
            PlayerDealThird()
        Else
            player_card3.Visible = True
            player_score3.Visible = True
            If RC = 1 Or RC = 14 Or RC = 27 Or RC = 40 Then
                player_card3.Cursor = Cursors.Hand
                player_card3.ContextMenuStrip = card3MenuStrip
            End If
            If RC = 1 Then
                'CARD ID:1 = Ace of Hearths
                player_card3.Image = My.Resources.H1
                mem_player_card3.Text = 1
                player_score3.Text = 11
            End If
            If RC = 2 Then
                'CARD ID:2 = Two of Hearths
                player_card3.Image = My.Resources.H2
                mem_player_card3.Text = 2
                player_score3.Text = 2
            End If
            If RC = 3 Then
                'CARD ID:3 = Three of Hearths
                player_card3.Image = My.Resources.H3
                mem_player_card3.Text = 3
                player_score3.Text = 3
            End If
            If RC = 4 Then
                'CARD ID:4 = Four of Hearths
                player_card3.Image = My.Resources.H4
                mem_player_card3.Text = 4
                player_score3.Text = 4
            End If
            If RC = 5 Then
                'CARD ID:5 = Five of Hearths
                player_card3.Image = My.Resources.H5
                mem_player_card3.Text = 5
                player_score3.Text = 5
            End If
            If RC = 6 Then
                'CARD ID:6 = Six of Hearths
                player_card3.Image = My.Resources.H6
                mem_player_card3.Text = 6
                player_score3.Text = 6
            End If
            If RC = 7 Then
                'CARD ID:7 = Seven of Hearths
                player_card3.Image = My.Resources.H7
                mem_player_card3.Text = 7
                player_score3.Text = 7
            End If
            If RC = 8 Then
                'CARD ID:8 = Eight of Hearths
                player_card3.Image = My.Resources.H8
                mem_player_card3.Text = 8
                player_score3.Text = 8
            End If
            If RC = 9 Then
                'CARD ID:9 = Nine of Hearths
                player_card3.Image = My.Resources.H9
                mem_player_card3.Text = 9
                player_score3.Text = 9
            End If
            If RC = 10 Then
                'CARD ID:10 = Ten of Hearths
                player_card3.Image = My.Resources.H10
                mem_player_card3.Text = 10
                player_score3.Text = 10
            End If
            If RC = 11 Then
                'CARD ID:11 = Jack of Hearths
                player_card3.Image = My.Resources.H11
                mem_player_card3.Text = 11
                player_score3.Text = 10
            End If
            If RC = 12 Then
                'CARD ID:12 = Queen of Hearths
                player_card3.Image = My.Resources.H12
                mem_player_card3.Text = 12
                player_score3.Text = 10
            End If
            If RC = 13 Then
                'CARD ID:13 = King of Hearths
                player_card3.Image = My.Resources.H13
                mem_player_card3.Text = 13
                player_score3.Text = 10
            End If
            If RC = 14 Then
                'CARD ID:14 = Ace of Clubs
                player_card3.Image = My.Resources.C1
                mem_player_card3.Text = 14
                player_score3.Text = 11
            End If
            If RC = 15 Then
                'CARD ID:15 = Two of Clubs
                player_card3.Image = My.Resources.C2
                mem_player_card3.Text = 15
                player_score3.Text = 2
            End If
            If RC = 16 Then
                'CARD ID:16 = Three of Clubs
                player_card3.Image = My.Resources.C3
                mem_player_card3.Text = 16
                player_score3.Text = 3
            End If
            If RC = 17 Then
                'CARD ID:17 = Four of Clubs
                player_card3.Image = My.Resources.C4
                mem_player_card3.Text = 17
                player_score3.Text = 4
            End If
            If RC = 18 Then
                'CARD ID:18 = Five of Clubs
                player_card3.Image = My.Resources.C5
                mem_player_card3.Text = 18
                player_score3.Text = 5
            End If
            If RC = 19 Then
                'CARD ID:19 = Six of Clubs
                player_card3.Image = My.Resources.C6
                mem_player_card3.Text = 19
                player_score3.Text = 6
            End If
            If RC = 20 Then
                'CARD ID:20 = Seven of Clubs
                player_card3.Image = My.Resources.C7
                mem_player_card3.Text = 20
                player_score3.Text = 7
            End If
            If RC = 21 Then
                'CARD ID:21 = Eight of Clubs
                player_card3.Image = My.Resources.C8
                mem_player_card3.Text = 21
                player_score3.Text = 8
            End If
            If RC = 22 Then
                'CARD ID:22 = Nine of Clubs
                player_card3.Image = My.Resources.C9
                mem_player_card3.Text = 22
                player_score3.Text = 9
            End If
            If RC = 23 Then
                'CARD ID:23 = Ten of Clubs
                player_card3.Image = My.Resources.C10
                mem_player_card3.Text = 23
                player_score3.Text = 10
            End If
            If RC = 24 Then
                'CARD ID:24 = Jack of Clubs
                player_card3.Image = My.Resources.C11
                mem_player_card3.Text = 24
                player_score3.Text = 10
            End If
            If RC = 25 Then
                'CARD ID:25 = Queen of Clubs
                player_card3.Image = My.Resources.C12
                mem_player_card3.Text = 25
                player_score3.Text = 10
            End If
            If RC = 26 Then
                'CARD ID:26 = King of Clubs
                player_card3.Image = My.Resources.C13
                mem_player_card3.Text = 26
                player_score3.Text = 10
            End If
            If RC = 27 Then
                'CARD ID:27 = Ace of Diamonds
                player_card3.Image = My.Resources.D1
                mem_player_card3.Text = 27
                player_score3.Text = 11
            End If
            If RC = 28 Then
                'CARD ID:28 = Two of Diamonds
                player_card3.Image = My.Resources.D2
                mem_player_card3.Text = 28
                player_score3.Text = 2
            End If
            If RC = 29 Then
                'CARD ID:27 = Three of Diamonds
                player_card3.Image = My.Resources.D3
                mem_player_card3.Text = 29
                player_score3.Text = 3
            End If
            If RC = 30 Then
                'CARD ID:30 = Four of Diamonds
                player_card3.Image = My.Resources.D4
                mem_player_card3.Text = 30
                player_score3.Text = 4
            End If
            If RC = 31 Then
                'CARD ID:31 = Five of Diamonds
                player_card3.Image = My.Resources.D5
                mem_player_card3.Text = 31
                player_score3.Text = 5
            End If
            If RC = 32 Then
                'CARD ID:32 = Six of Diamonds
                player_card3.Image = My.Resources.D6
                mem_player_card3.Text = 32
                player_score3.Text = 6
            End If
            If RC = 33 Then
                'CARD ID:33 = Seven of Diamonds
                player_card3.Image = My.Resources.D7
                mem_player_card3.Text = 33
                player_score3.Text = 7
            End If
            If RC = 34 Then
                'CARD ID:34 = Eight of Diamonds
                player_card3.Image = My.Resources.D8
                mem_player_card3.Text = 34
                player_score3.Text = 8
            End If
            If RC = 35 Then
                'CARD ID:35 = Nine of Diamonds
                player_card3.Image = My.Resources.D9
                mem_player_card3.Text = 35
                player_score3.Text = 9
            End If
            If RC = 36 Then
                'CARD ID:36 = Ten of Diamonds
                player_card3.Image = My.Resources.D10
                mem_player_card3.Text = 36
                player_score3.Text = 10
            End If
            If RC = 37 Then
                'CARD ID:37 = Jack of Diamonds
                player_card3.Image = My.Resources.D11
                mem_player_card3.Text = 37
                player_score3.Text = 10
            End If
            If RC = 38 Then
                'CARD ID:38 = Queen of Diamonds
                player_card3.Image = My.Resources.D12
                mem_player_card3.Text = 38
                player_score3.Text = 10
            End If
            If RC = 39 Then
                'CARD ID:39 = King of Diamonds
                player_card3.Image = My.Resources.D13
                mem_player_card3.Text = 39
                player_score3.Text = 10
            End If
            If RC = 40 Then
                'CARD ID:40 = Ace of Spades
                player_card3.Image = My.Resources.S1
                mem_player_card3.Text = 40
                player_score3.Text = 11
            End If
            If RC = 41 Then
                'CARD ID:41 = Two of Spades
                player_card3.Image = My.Resources.S2
                mem_player_card3.Text = 41
                player_score3.Text = 2
            End If
            If RC = 42 Then
                'CARD ID:42 = Three of Spades
                player_card3.Image = My.Resources.S3
                mem_player_card3.Text = 42
                player_score3.Text = 3
            End If
            If RC = 43 Then
                'CARD ID:43 = Four of Spades
                player_card3.Image = My.Resources.S4
                mem_player_card3.Text = 43
                player_score3.Text = 4
            End If
            If RC = 44 Then
                'CARD ID:44 = Five of Spades
                player_card3.Image = My.Resources.S5
                mem_player_card3.Text = 44
                player_score3.Text = 5
            End If
            If RC = 45 Then
                'CARD ID:45 = Six of Spades
                player_card3.Image = My.Resources.S6
                mem_player_card3.Text = 45
                player_score3.Text = 6
            End If
            If RC = 46 Then
                'CARD ID:46 = Seven of Spades
                player_card3.Image = My.Resources.S7
                mem_player_card3.Text = 46
                player_score3.Text = 7
            End If
            If RC = 47 Then
                'CARD ID:47 = Eight of Spades
                player_card3.Image = My.Resources.S8
                mem_player_card3.Text = 47
                player_score3.Text = 8
            End If
            If RC = 48 Then
                'CARD ID:48 = Nine of Spades
                player_card3.Image = My.Resources.S9
                mem_player_card3.Text = 48
                player_score3.Text = 9
            End If
            If RC = 49 Then
                'CARD ID:49 = Ten of Spades
                player_card3.Image = My.Resources.S10
                mem_player_card3.Text = 49
                player_score3.Text = 10
            End If
            If RC = 50 Then
                'CARD ID:50 = Jack of Spades
                player_card3.Image = My.Resources.S11
                mem_player_card3.Text = 50
                player_score3.Text = 10
            End If
            If RC = 51 Then
                'CARD ID:51 = Queen of Spades
                player_card3.Image = My.Resources.S12
                mem_player_card3.Text = 51
                player_score3.Text = 10
            End If
            If RC = 52 Then
                'CARD ID:52 = King of Spades
                player_card3.Image = My.Resources.S13
                mem_player_card3.Text = 52
                player_score3.Text = 10
            End If
            UpdateScore()
        End If
    End Sub

    Public Sub PlayerDealFourth()
        Dim RC As Integer
        Randomize()
        RC = 53 * Rnd()
        If RC = 53 Or RC = 0 Or RC = mem_op_card1.Text Or RC = mem_op_card2.Text Or RC = mem_op_card3.Text Or RC = mem_op_card4.Text Or RC = mem_op_card5.Text Or RC = mem_player_card1.Text Or RC = mem_player_card2.Text Or RC = mem_player_card3.Text Or RC = mem_player_card4.Text Or RC = mem_player_card5.Text Then
            PlayerDealFourth()
        Else
            player_card4.Visible = True
            player_score4.Visible = True
            If RC = 1 Or RC = 14 Or RC = 27 Or RC = 40 Then
                player_card4.Cursor = Cursors.Hand
                player_card4.ContextMenuStrip = card4MenuStrip
            End If
            If RC = 1 Then
                'CARD ID:1 = Ace of Hearths
                player_card4.Image = My.Resources.H1
                mem_player_card4.Text = 1
                player_score4.Text = 11
            End If
            If RC = 2 Then
                'CARD ID:2 = Two of Hearths
                player_card4.Image = My.Resources.H2
                mem_player_card4.Text = 2
                player_score4.Text = 2
            End If
            If RC = 3 Then
                'CARD ID:3 = Three of Hearths
                player_card4.Image = My.Resources.H3
                mem_player_card4.Text = 3
                player_score4.Text = 3
            End If
            If RC = 4 Then
                'CARD ID:4 = Four of Hearths
                player_card4.Image = My.Resources.H4
                mem_player_card4.Text = 4
                player_score4.Text = 4
            End If
            If RC = 5 Then
                'CARD ID:5 = Five of Hearths
                player_card4.Image = My.Resources.H5
                mem_player_card4.Text = 5
                player_score4.Text = 5
            End If
            If RC = 6 Then
                'CARD ID:6 = Six of Hearths
                player_card4.Image = My.Resources.H6
                mem_player_card4.Text = 6
                player_score4.Text = 6
            End If
            If RC = 7 Then
                'CARD ID:7 = Seven of Hearths
                player_card4.Image = My.Resources.H7
                mem_player_card4.Text = 7
                player_score4.Text = 7
            End If
            If RC = 8 Then
                'CARD ID:8 = Eight of Hearths
                player_card4.Image = My.Resources.H8
                mem_player_card4.Text = 8
                player_score4.Text = 8
            End If
            If RC = 9 Then
                'CARD ID:9 = Nine of Hearths
                player_card4.Image = My.Resources.H9
                mem_player_card4.Text = 9
                player_score4.Text = 9
            End If
            If RC = 10 Then
                'CARD ID:10 = Ten of Hearths
                player_card4.Image = My.Resources.H10
                mem_player_card4.Text = 10
                player_score4.Text = 10
            End If
            If RC = 11 Then
                'CARD ID:11 = Jack of Hearths
                player_card4.Image = My.Resources.H11
                mem_player_card4.Text = 11
                player_score4.Text = 10
            End If
            If RC = 12 Then
                'CARD ID:12 = Queen of Hearths
                player_card4.Image = My.Resources.H12
                mem_player_card4.Text = 12
                player_score4.Text = 10
            End If
            If RC = 13 Then
                'CARD ID:13 = King of Hearths
                player_card4.Image = My.Resources.H13
                mem_player_card4.Text = 13
                player_score4.Text = 10
            End If
            If RC = 14 Then
                'CARD ID:14 = Ace of Clubs
                player_card4.Image = My.Resources.C1
                mem_player_card4.Text = 14
                player_score4.Text = 11
            End If
            If RC = 15 Then
                'CARD ID:15 = Two of Clubs
                player_card4.Image = My.Resources.C2
                mem_player_card4.Text = 15
                player_score4.Text = 2
            End If
            If RC = 16 Then
                'CARD ID:16 = Three of Clubs
                player_card4.Image = My.Resources.C3
                mem_player_card4.Text = 16
                player_score4.Text = 3
            End If
            If RC = 17 Then
                'CARD ID:17 = Four of Clubs
                player_card4.Image = My.Resources.C4
                mem_player_card4.Text = 17
                player_score4.Text = 4
            End If
            If RC = 18 Then
                'CARD ID:18 = Five of Clubs
                player_card4.Image = My.Resources.C5
                mem_player_card4.Text = 18
                player_score4.Text = 5
            End If
            If RC = 19 Then
                'CARD ID:19 = Six of Clubs
                player_card4.Image = My.Resources.C6
                mem_player_card4.Text = 19
                player_score4.Text = 6
            End If
            If RC = 20 Then
                'CARD ID:20 = Seven of Clubs
                player_card4.Image = My.Resources.C7
                mem_player_card4.Text = 20
                player_score4.Text = 7
            End If
            If RC = 21 Then
                'CARD ID:21 = Eight of Clubs
                player_card4.Image = My.Resources.C8
                mem_player_card4.Text = 21
                player_score4.Text = 8
            End If
            If RC = 22 Then
                'CARD ID:22 = Nine of Clubs
                player_card4.Image = My.Resources.C9
                mem_player_card4.Text = 22
                player_score4.Text = 9
            End If
            If RC = 23 Then
                'CARD ID:23 = Ten of Clubs
                player_card4.Image = My.Resources.C10
                mem_player_card4.Text = 23
                player_score4.Text = 10
            End If
            If RC = 24 Then
                'CARD ID:24 = Jack of Clubs
                player_card4.Image = My.Resources.C11
                mem_player_card4.Text = 24
                player_score4.Text = 10
            End If
            If RC = 25 Then
                'CARD ID:25 = Queen of Clubs
                player_card4.Image = My.Resources.C12
                mem_player_card4.Text = 25
                player_score4.Text = 10
            End If
            If RC = 26 Then
                'CARD ID:26 = King of Clubs
                player_card4.Image = My.Resources.C13
                mem_player_card4.Text = 26
                player_score4.Text = 10
            End If
            If RC = 27 Then
                'CARD ID:27 = Ace of Diamonds
                player_card4.Image = My.Resources.D1
                mem_player_card4.Text = 27
                player_score4.Text = 11
            End If
            If RC = 28 Then
                'CARD ID:28 = Two of Diamonds
                player_card4.Image = My.Resources.D2
                mem_player_card4.Text = 28
                player_score4.Text = 2
            End If
            If RC = 29 Then
                'CARD ID:27 = Three of Diamonds
                player_card4.Image = My.Resources.D3
                mem_player_card4.Text = 29
                player_score4.Text = 3
            End If
            If RC = 30 Then
                'CARD ID:30 = Four of Diamonds
                player_card4.Image = My.Resources.D4
                mem_player_card4.Text = 30
                player_score4.Text = 4
            End If
            If RC = 31 Then
                'CARD ID:31 = Five of Diamonds
                player_card4.Image = My.Resources.D5
                mem_player_card4.Text = 31
                player_score4.Text = 5
            End If
            If RC = 32 Then
                'CARD ID:32 = Six of Diamonds
                player_card4.Image = My.Resources.D6
                mem_player_card4.Text = 32
                player_score4.Text = 6
            End If
            If RC = 33 Then
                'CARD ID:33 = Seven of Diamonds
                player_card4.Image = My.Resources.D7
                mem_player_card4.Text = 33
                player_score4.Text = 7
            End If
            If RC = 34 Then
                'CARD ID:34 = Eight of Diamonds
                player_card4.Image = My.Resources.D8
                mem_player_card4.Text = 34
                player_score4.Text = 8
            End If
            If RC = 35 Then
                'CARD ID:35 = Nine of Diamonds
                player_card4.Image = My.Resources.D9
                mem_player_card4.Text = 35
                player_score4.Text = 9
            End If
            If RC = 36 Then
                'CARD ID:36 = Ten of Diamonds
                player_card4.Image = My.Resources.D10
                mem_player_card4.Text = 36
                player_score4.Text = 10
            End If
            If RC = 37 Then
                'CARD ID:37 = Jack of Diamonds
                player_card4.Image = My.Resources.D11
                mem_player_card4.Text = 37
                player_score4.Text = 10
            End If
            If RC = 38 Then
                'CARD ID:38 = Queen of Diamonds
                player_card4.Image = My.Resources.D12
                mem_player_card4.Text = 38
                player_score4.Text = 10
            End If
            If RC = 39 Then
                'CARD ID:39 = King of Diamonds
                player_card4.Image = My.Resources.D13
                mem_player_card4.Text = 39
                player_score4.Text = 10
            End If
            If RC = 40 Then
                'CARD ID:40 = Ace of Spades
                player_card4.Image = My.Resources.S1
                mem_player_card4.Text = 40
                player_score4.Text = 11
            End If
            If RC = 41 Then
                'CARD ID:41 = Two of Spades
                player_card4.Image = My.Resources.S2
                mem_player_card4.Text = 41
                player_score4.Text = 2
            End If
            If RC = 42 Then
                'CARD ID:42 = Three of Spades
                player_card4.Image = My.Resources.S3
                mem_player_card4.Text = 42
                player_score4.Text = 3
            End If
            If RC = 43 Then
                'CARD ID:43 = Four of Spades
                player_card4.Image = My.Resources.S4
                mem_player_card4.Text = 43
                player_score4.Text = 4
            End If
            If RC = 44 Then
                'CARD ID:44 = Five of Spades
                player_card4.Image = My.Resources.S5
                mem_player_card4.Text = 44
                player_score4.Text = 5
            End If
            If RC = 45 Then
                'CARD ID:45 = Six of Spades
                player_card4.Image = My.Resources.S6
                mem_player_card4.Text = 45
                player_score4.Text = 6
            End If
            If RC = 46 Then
                'CARD ID:46 = Seven of Spades
                player_card4.Image = My.Resources.S7
                mem_player_card4.Text = 46
                player_score4.Text = 7
            End If
            If RC = 47 Then
                'CARD ID:47 = Eight of Spades
                player_card4.Image = My.Resources.S8
                mem_player_card4.Text = 47
                player_score4.Text = 8
            End If
            If RC = 48 Then
                'CARD ID:48 = Nine of Spades
                player_card4.Image = My.Resources.S9
                mem_player_card4.Text = 48
                player_score4.Text = 9
            End If
            If RC = 49 Then
                'CARD ID:49 = Ten of Spades
                player_card4.Image = My.Resources.S10
                mem_player_card4.Text = 49
                player_score4.Text = 10
            End If
            If RC = 50 Then
                'CARD ID:50 = Jack of Spades
                player_card4.Image = My.Resources.S11
                mem_player_card4.Text = 50
                player_score4.Text = 10
            End If
            If RC = 51 Then
                'CARD ID:51 = Queen of Spades
                player_card4.Image = My.Resources.S12
                mem_player_card4.Text = 51
                player_score4.Text = 10
            End If
            If RC = 52 Then
                'CARD ID:52 = King of Spades
                player_card4.Image = My.Resources.S13
                mem_player_card4.Text = 52
                player_score4.Text = 10
            End If
            UpdateScore()
        End If
    End Sub

    Public Sub PlayerDealFifth()
        Dim RC As Integer
        Randomize()
        RC = 53 * Rnd()
        If RC = 53 Or RC = 0 Or RC = mem_op_card1.Text Or RC = mem_op_card2.Text Or RC = mem_op_card3.Text Or RC = mem_op_card4.Text Or RC = mem_op_card5.Text Or RC = mem_player_card1.Text Or RC = mem_player_card2.Text Or RC = mem_player_card3.Text Or RC = mem_player_card4.Text Or RC = mem_player_card5.Text Then
            PlayerDealFifth()
        Else
            player_card5.Visible = True
            player_score5.Visible = True
            If RC = 1 Or RC = 14 Or RC = 27 Or RC = 40 Then
                player_card5.Cursor = Cursors.Hand
                player_card5.ContextMenuStrip = card5MenuStrip
            End If
            If RC = 1 Then
                'CARD ID:1 = Ace of Hearths
                player_card5.Image = My.Resources.H1
                mem_player_card5.Text = 1
                player_score5.Text = 11
            End If
            If RC = 2 Then
                'CARD ID:2 = Two of Hearths
                player_card5.Image = My.Resources.H2
                mem_player_card5.Text = 2
                player_score5.Text = 2
            End If
            If RC = 3 Then
                'CARD ID:3 = Three of Hearths
                player_card5.Image = My.Resources.H3
                mem_player_card5.Text = 3
                player_score5.Text = 3
            End If
            If RC = 4 Then
                'CARD ID:4 = Four of Hearths
                player_card5.Image = My.Resources.H4
                mem_player_card5.Text = 4
                player_score5.Text = 4
            End If
            If RC = 5 Then
                'CARD ID:5 = Five of Hearths
                player_card5.Image = My.Resources.H5
                mem_player_card5.Text = 5
                player_score5.Text = 5
            End If
            If RC = 6 Then
                'CARD ID:6 = Six of Hearths
                player_card5.Image = My.Resources.H6
                mem_player_card5.Text = 6
                player_score5.Text = 6
            End If
            If RC = 7 Then
                'CARD ID:7 = Seven of Hearths
                player_card5.Image = My.Resources.H7
                mem_player_card5.Text = 7
                player_score5.Text = 7
            End If
            If RC = 8 Then
                'CARD ID:8 = Eight of Hearths
                player_card5.Image = My.Resources.H8
                mem_player_card5.Text = 8
                player_score5.Text = 8
            End If
            If RC = 9 Then
                'CARD ID:9 = Nine of Hearths
                player_card5.Image = My.Resources.H9
                mem_player_card5.Text = 9
                player_score5.Text = 9
            End If
            If RC = 10 Then
                'CARD ID:10 = Ten of Hearths
                player_card5.Image = My.Resources.H10
                mem_player_card5.Text = 10
                player_score5.Text = 10
            End If
            If RC = 11 Then
                'CARD ID:11 = Jack of Hearths
                player_card5.Image = My.Resources.H11
                mem_player_card5.Text = 11
                player_score5.Text = 10
            End If
            If RC = 12 Then
                'CARD ID:12 = Queen of Hearths
                player_card5.Image = My.Resources.H12
                mem_player_card5.Text = 12
                player_score5.Text = 10
            End If
            If RC = 13 Then
                'CARD ID:13 = King of Hearths
                player_card5.Image = My.Resources.H13
                mem_player_card5.Text = 13
                player_score5.Text = 10
            End If
            If RC = 14 Then
                'CARD ID:14 = Ace of Clubs
                player_card5.Image = My.Resources.C1
                mem_player_card5.Text = 14
                player_score5.Text = 11
            End If
            If RC = 15 Then
                'CARD ID:15 = Two of Clubs
                player_card5.Image = My.Resources.C2
                mem_player_card5.Text = 15
                player_score5.Text = 2
            End If
            If RC = 16 Then
                'CARD ID:16 = Three of Clubs
                player_card5.Image = My.Resources.C3
                mem_player_card5.Text = 16
                player_score5.Text = 3
            End If
            If RC = 17 Then
                'CARD ID:17 = Four of Clubs
                player_card5.Image = My.Resources.C4
                mem_player_card5.Text = 17
                player_score5.Text = 4
            End If
            If RC = 18 Then
                'CARD ID:18 = Five of Clubs
                player_card5.Image = My.Resources.C5
                mem_player_card5.Text = 18
                player_score5.Text = 5
            End If
            If RC = 19 Then
                'CARD ID:19 = Six of Clubs
                player_card5.Image = My.Resources.C6
                mem_player_card5.Text = 19
                player_score5.Text = 6
            End If
            If RC = 20 Then
                'CARD ID:20 = Seven of Clubs
                player_card5.Image = My.Resources.C7
                mem_player_card5.Text = 20
                player_score5.Text = 7
            End If
            If RC = 21 Then
                'CARD ID:21 = Eight of Clubs
                player_card5.Image = My.Resources.C8
                mem_player_card5.Text = 21
                player_score5.Text = 8
            End If
            If RC = 22 Then
                'CARD ID:22 = Nine of Clubs
                player_card5.Image = My.Resources.C9
                mem_player_card5.Text = 22
                player_score5.Text = 9
            End If
            If RC = 23 Then
                'CARD ID:23 = Ten of Clubs
                player_card5.Image = My.Resources.C10
                mem_player_card5.Text = 23
                player_score5.Text = 10
            End If
            If RC = 24 Then
                'CARD ID:24 = Jack of Clubs
                player_card5.Image = My.Resources.C11
                mem_player_card5.Text = 24
                player_score5.Text = 10
            End If
            If RC = 25 Then
                'CARD ID:25 = Queen of Clubs
                player_card5.Image = My.Resources.C12
                mem_player_card5.Text = 25
                player_score5.Text = 10
            End If
            If RC = 26 Then
                'CARD ID:26 = King of Clubs
                player_card5.Image = My.Resources.C13
                mem_player_card5.Text = 26
                player_score5.Text = 10
            End If
            If RC = 27 Then
                'CARD ID:27 = Ace of Diamonds
                player_card5.Image = My.Resources.D1
                mem_player_card5.Text = 27
                player_score5.Text = 11
            End If
            If RC = 28 Then
                'CARD ID:28 = Two of Diamonds
                player_card5.Image = My.Resources.D2
                mem_player_card5.Text = 28
                player_score5.Text = 2
            End If
            If RC = 29 Then
                'CARD ID:27 = Three of Diamonds
                player_card5.Image = My.Resources.D3
                mem_player_card5.Text = 29
                player_score5.Text = 3
            End If
            If RC = 30 Then
                'CARD ID:30 = Four of Diamonds
                player_card5.Image = My.Resources.D4
                mem_player_card5.Text = 30
                player_score5.Text = 4
            End If
            If RC = 31 Then
                'CARD ID:31 = Five of Diamonds
                player_card5.Image = My.Resources.D5
                mem_player_card5.Text = 31
                player_score5.Text = 5
            End If
            If RC = 32 Then
                'CARD ID:32 = Six of Diamonds
                player_card5.Image = My.Resources.D6
                mem_player_card5.Text = 32
                player_score5.Text = 6
            End If
            If RC = 33 Then
                'CARD ID:33 = Seven of Diamonds
                player_card5.Image = My.Resources.D7
                mem_player_card5.Text = 33
                player_score5.Text = 7
            End If
            If RC = 34 Then
                'CARD ID:34 = Eight of Diamonds
                player_card5.Image = My.Resources.D8
                mem_player_card5.Text = 34
                player_score5.Text = 8
            End If
            If RC = 35 Then
                'CARD ID:35 = Nine of Diamonds
                player_card5.Image = My.Resources.D9
                mem_player_card5.Text = 35
                player_score5.Text = 9
            End If
            If RC = 36 Then
                'CARD ID:36 = Ten of Diamonds
                player_card5.Image = My.Resources.D10
                mem_player_card5.Text = 36
                player_score5.Text = 10
            End If
            If RC = 37 Then
                'CARD ID:37 = Jack of Diamonds
                player_card5.Image = My.Resources.D11
                mem_player_card5.Text = 37
                player_score5.Text = 10
            End If
            If RC = 38 Then
                'CARD ID:38 = Queen of Diamonds
                player_card5.Image = My.Resources.D12
                mem_player_card5.Text = 38
                player_score5.Text = 10
            End If
            If RC = 39 Then
                'CARD ID:39 = King of Diamonds
                player_card5.Image = My.Resources.D13
                mem_player_card5.Text = 39
                player_score5.Text = 10
            End If
            If RC = 40 Then
                'CARD ID:40 = Ace of Spades
                player_card5.Image = My.Resources.S1
                mem_player_card5.Text = 40
                player_score5.Text = 11
            End If
            If RC = 41 Then
                'CARD ID:41 = Two of Spades
                player_card5.Image = My.Resources.S2
                mem_player_card5.Text = 41
                player_score5.Text = 2
            End If
            If RC = 42 Then
                'CARD ID:42 = Three of Spades
                player_card5.Image = My.Resources.S3
                mem_player_card5.Text = 42
                player_score5.Text = 3
            End If
            If RC = 43 Then
                'CARD ID:43 = Four of Spades
                player_card5.Image = My.Resources.S4
                mem_player_card5.Text = 43
                player_score5.Text = 4
            End If
            If RC = 44 Then
                'CARD ID:44 = Five of Spades
                player_card5.Image = My.Resources.S5
                mem_player_card5.Text = 44
                player_score5.Text = 5
            End If
            If RC = 45 Then
                'CARD ID:45 = Six of Spades
                player_card5.Image = My.Resources.S6
                mem_player_card5.Text = 45
                player_score5.Text = 6
            End If
            If RC = 46 Then
                'CARD ID:46 = Seven of Spades
                player_card5.Image = My.Resources.S7
                mem_player_card5.Text = 46
                player_score5.Text = 7
            End If
            If RC = 47 Then
                'CARD ID:47 = Eight of Spades
                player_card5.Image = My.Resources.S8
                mem_player_card5.Text = 47
                player_score5.Text = 8
            End If
            If RC = 48 Then
                'CARD ID:48 = Nine of Spades
                player_card5.Image = My.Resources.S9
                mem_player_card5.Text = 48
                player_score5.Text = 9
            End If
            If RC = 49 Then
                'CARD ID:49 = Ten of Spades
                player_card5.Image = My.Resources.S10
                mem_player_card5.Text = 49
                player_score5.Text = 10
            End If
            If RC = 50 Then
                'CARD ID:50 = Jack of Spades
                player_card5.Image = My.Resources.S11
                mem_player_card5.Text = 50
                player_score5.Text = 10
            End If
            If RC = 51 Then
                'CARD ID:51 = Queen of Spades
                player_card5.Image = My.Resources.S12
                mem_player_card5.Text = 51
                player_score5.Text = 10
            End If
            If RC = 52 Then
                'CARD ID:52 = King of Spades
                player_card5.Image = My.Resources.S13
                mem_player_card5.Text = 52
                player_score5.Text = 10
            End If
            UpdateScore()
        End If
    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click
        If mem_player_card5.Text > 0 Then
            MsgBox("Conseguiste uma Aposta Máxima", 0, "Para!")
        Else
            If mem_player_card4.Text > 0 Then
                PlayerDealFifth()
            Else
                If mem_player_card3.Text > 0 Then
                    PlayerDealFourth()
                Else
                    If mem_player_card2.Text > 0 Then
                        PlayerDealThird()
                    Else
                        If mem_player_card1.Text > 0 Then
                            PlayerDealSecond()
                        Else
                            PlayerDealFirst()
                        End If
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub player_card1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles player_card1.Click
        If player_score1.Text = 1 Then
            player_score1.Text = 11
        ElseIf player_score1.Text = 11 Then
            player_score1.Text = 1
        End If
        UpdateScore()
    End Sub

    Private Sub TogleToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TogleToolStripMenuItem.Click
        If player_score1.Text = 1 Then
            player_score1.Text = 11
        ElseIf player_score1.Text = 11 Then
            player_score1.Text = 1
        End If
        UpdateScore()
    End Sub

    Private Sub ToolStripMenuItem8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem8.Click
        If player_score2.Text = 1 Then
            player_score2.Text = 11
        ElseIf player_score2.Text = 11 Then
            player_score2.Text = 1
        End If
        UpdateScore()
    End Sub

    Private Sub player_card2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles player_card2.Click
        If player_score2.Text = 1 Then
            player_score2.Text = 11
        ElseIf player_score2.Text = 11 Then
            player_score2.Text = 1
        End If
        UpdateScore()
    End Sub

    Private Sub card3MenuStrip_Opening(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles card3MenuStrip.Opening
        If player_score3.Text = 1 Then
            player_score3.Text = 11
        ElseIf player_score3.Text = 11 Then
            player_score3.Text = 1
        End If
        UpdateScore()
    End Sub

    Private Sub player_card3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles player_card3.Click
        If player_score3.Text = 1 Then
            player_score3.Text = 11
        ElseIf player_score3.Text = 11 Then
            player_score3.Text = 1
        End If
        UpdateScore()
    End Sub

    Private Sub ToolStripMenuItem12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem12.Click
        If player_score4.Text = 1 Then
            player_score4.Text = 11
        ElseIf player_score4.Text = 11 Then
            player_score4.Text = 1
        End If
        UpdateScore()
    End Sub

    Private Sub player_card4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles player_card4.Click
        If player_score4.Text = 1 Then
            player_score4.Text = 11
        ElseIf player_score4.Text = 11 Then
            player_score4.Text = 1
        End If
        UpdateScore()
    End Sub

    Private Sub ToolStripMenuItem14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem14.Click
        If player_score5.Text = 1 Then
            player_score5.Text = 11
        ElseIf player_score5.Text = 11 Then
            player_score5.Text = 1
        End If
        UpdateScore()
    End Sub

    Private Sub player_card5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles player_card5.Click
        If player_score5.Text = 1 Then
            player_score5.Text = 11
        ElseIf player_score5.Text = 11 Then
            player_score5.Text = 1
        End If
        UpdateScore()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If mem_player_card2.Text > 0 Then
            Button1.Enabled = False
            player_card1.Cursor = Cursors.Arrow
            player_card2.Cursor = Cursors.Arrow
            player_card3.Cursor = Cursors.Arrow
            player_card4.Cursor = Cursors.Arrow
            player_card5.Cursor = Cursors.Arrow
            player_card1.Enabled = False
            player_card2.Enabled = False
            player_card3.Enabled = False
            player_card4.Enabled = False
            player_card5.Enabled = False
            player_card1.ContextMenuStrip = cancelMenuStrip
            player_card2.ContextMenuStrip = cancelMenuStrip
            player_card3.ContextMenuStrip = cancelMenuStrip
            player_card4.ContextMenuStrip = cancelMenuStrip
            player_card5.ContextMenuStrip = cancelMenuStrip
            PictureBox1.Enabled = False
            opponent_turn.Enabled = True
        Else
            MsgBox("Tu tens de escolher 2 ou mais cartas para jogar -.-", 0, "AH .. Não Muito?")
        End If
    End Sub

    Private Sub opponent_turn_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles opponent_turn.Tick
        If stage = 0 Then
            'DEAL 1
            deal_class.OpponentDealFirst()
            deal_class.CoverCard(1)
            stage = 1
            UpdateScore()

        Else
            If stage = 1 Then
                'DEAL 2
                deal_class.OpponentDealSecond()
                deal_class.CoverCard(2)
                stage = 2
                UpdateScore()
            Else
                If stage = 2 Then
                    'DEAL 3
                    If out_op_score.Text >= 15 Then
                        stage = 10
                    Else
                        deal_class.OpponentDealThird()
                        deal_class.CoverCard(3)
                        stage = 3
                        UpdateScore()
                    End If
                    'END DEAL 3
                Else
                    If stage = 3 Then
                        'DEAL 4
                        If out_op_score.Text >= 15 Then
                            stage = 10
                        Else
                            deal_class.OpponentDealFourth()
                            deal_class.CoverCard(4)
                            stage = 4
                            UpdateScore()
                        End If
                        'END DEAL 4
                    Else
                        If stage = 4 Then
                            'DEAL 5
                            If out_op_score.Text >= 15 Then
                                stage = 10
                            Else
                                deal_class.OpponentDealFifth()
                                deal_class.CoverCard(5)
                                stage = 10
                                UpdateScore()
                            End If
                            'END DEAL 5
                        Else
                            If stage = 10 Then
                                Try
                                    My.Computer.Audio.Play("DEAL.wav")
                                Catch ex As Exception
                                End Try
                                deal_class.UnCoverCard(1)
                                deal_class.UnCoverCard(2)
                                If mem_op_card3.Text > 0 Then
                                    deal_class.UnCoverCard(3)
                                End If
                                If mem_op_card4.Text > 0 Then
                                    deal_class.UnCoverCard(4)
                                End If
                                If mem_op_card5.Text > 0 Then
                                    deal_class.UnCoverCard(5)
                                End If
                                stage = 11
                            Else
                                If stage = 11 Then
                                    stage = 0
                                    opponent_turn.Enabled = False
                                    '
                                    'WIN/LOSE
                                    '
                                    If out_op_score.Text = points.Text And points.Text < 22 Then
                                        'DRAW
                                        MsgBox("Você tem tanto recolhidos a mesma quantidade de pontos. Portanto, não há vencedor.", 0, "EMPATE!")
                                        ResetBoard(True)
                                        'DRAW
                                    Else
                                        If out_op_score.Text > 21 And points.Text > 21 Then
                                            'DRAW
                                            MsgBox("Você tem tanto recolhidos a mesma quantidade de pontos. Portanto, não há vencedor.", 0, "EMPATE!")
                                            ResetBoard(True)
                                            'DRAW
                                        Else
                                            If points.Text > 21 Then
                                                'LOSE
                                                MsgBox("Você ultrapassou o limite de 21 anos. Portanto, você perde!", 0, "DERROTA!")
                                                ResetBoard(False)
                                                If out_cash.Text = 0 Then
                                                    MsgBox("Está sem dinheiro, começar um novo jogo.", 0, "~~~~Fim do Jogo!~~~~")
                                                    out_cash.Text = 100
                                                End If
                                                'LOSE
                                            Else
                                                If out_op_score.Text > 21 Then
                                                    'WIN
                                                    MsgBox("Seu adversário tem ultrapassou o limite de 21 anos. Assim você ganha!", 0, "VITÓRIA!")
                                                    ResetBoard(False)
                                                    Dim win As Integer
                                                    win = total_bets.Text
                                                    out_cash.Text = out_cash.Text + win
                                                    Try
                                                        My.Computer.Audio.Play("CASH.wav")
                                                    Catch ex As Exception
                                                    End Try
                                                    If out_cash.Text >= 99999999999999998 Then
                                                        MsgBox("Você coletou o máximo de dinheiro. Você pode enviar sua pontuação alta como MAX Cash.", 0, "~~~~~Dinheiro MAX chegou!!!~~~~~")
                                                        Submit_HighScore.score.Text = "MAX"
                                                        Submit_HighScore.Show()
                                                    End If
                                                    'WIN
                                                Else
                                                    If out_op_score.Text > points.Text Then
                                                        'LOSE
                                                        MsgBox("Você ultrapassou o limite de 21 anos. Portanto, você perde!", 0, "DERROTA!")
                                                        ResetBoard(False)
                                                        If out_cash.Text = 0 Then
                                                            MsgBox("Está sem dinheiro, começar um novo jogo.", 0, "~~~~Fim do Jogo!~~~~")
                                                            out_cash.Text = 100
                                                        End If
                                                        'LOSE
                                                    Else
                                                        If points.Text > out_op_score.Text Then
                                                            'WIN
                                                            MsgBox("Seu adversário tem ultrapassou o limite de 21 anos. Assim você ganha!", 0, "VITÓRIA!")
                                                            ResetBoard(False)
                                                            Dim win As Integer
                                                            win = total_bets.Text
                                                            out_cash.Text = out_cash.Text + win
                                                            Try
                                                                My.Computer.Audio.Play("CASH.wav")
                                                            Catch ex As Exception
                                                            End Try
                                                            If out_cash.Text >= 99999999999999998 Then
                                                                MsgBox("Você coletou o máximo de dinheiro. Você pode enviar sua pontuação alta como dinheiro máximo.", 0, "~~~~~Dinheiro MAX chegou!!!~~~~~")
                                                                Submit_HighScore.score.Text = "MAX"
                                                                Submit_HighScore.Show()
                                                            End If
                                                            'WIN
                                                        End If
                                                    End If
                                                End If
                                            End If
                                        End If
                                    End If




                                    '
                                    'WIN/LOSE
                                    '
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        End If
    End Sub

    Public Sub ResetBoard(ByVal ReturnMoney As Boolean)
        'Hiding
        op_score1.Visible = False
        op_score2.Visible = False
        op_score3.Visible = False
        op_score4.Visible = False
        op_score5.Visible = False
        player_score1.Visible = False
        player_score2.Visible = False
        player_score3.Visible = False
        player_score4.Visible = False
        player_score5.Visible = False
        mem_op_card1.Visible = False
        mem_op_card2.Visible = False
        mem_op_card3.Visible = False
        mem_op_card4.Visible = False
        mem_op_card5.Visible = False
        mem_player_card1.Visible = False
        mem_player_card2.Visible = False
        mem_player_card3.Visible = False
        mem_player_card4.Visible = False
        mem_player_card5.Visible = False
        op_card1.Visible = False
        op_card2.Visible = False
        op_card3.Visible = False
        op_card4.Visible = False
        op_card5.Visible = False
        player_card1.Visible = False
        player_card2.Visible = False
        player_card3.Visible = False
        player_card4.Visible = False
        player_card5.Visible = False
        cover1.Visible = False
        cover2.Visible = False
        cover3.Visible = False
        cover4.Visible = False
        cover5.Visible = False
        'Done Hiding
        'Returning Values to 0
        op_score1.Text = 0
        op_score2.Text = 0
        op_score3.Text = 0
        op_score4.Text = 0
        op_score5.Text = 0
        player_score1.Text = 0
        player_score2.Text = 0
        player_score3.Text = 0
        player_score4.Text = 0
        player_score5.Text = 0
        mem_op_card1.Text = 0
        mem_op_card2.Text = 0
        mem_op_card3.Text = 0
        mem_op_card4.Text = 0
        mem_op_card5.Text = 0
        mem_player_card1.Text = 0
        mem_player_card2.Text = 0
        mem_player_card3.Text = 0
        mem_player_card4.Text = 0
        mem_player_card5.Text = 0
        out_op_score.Text = 0
        points.Text = 0
        'Done returning values
        'Returning card backs
        op_card1.Image = My.Resources.back1
        op_card2.Image = My.Resources.back1
        op_card3.Image = My.Resources.back1
        op_card4.Image = My.Resources.back1
        op_card5.Image = My.Resources.back1
        'Disabling
        PictureBox1.Enabled = False
        'Enabling buttons
        betButton.Enabled = True
        Button1.Enabled = False
        player_card1.Enabled = True
        player_card2.Enabled = True
        player_card3.Enabled = True
        player_card4.Enabled = True
        your_bet.Enabled = True
        player_card5.Enabled = True
        'Stop timers
        opponent_turn.Enabled = False
        stage = 0
        If ReturnMoney = True Then
            Dim bet As Integer
            bet = your_bet.Text
            out_cash.Text = out_cash.Text + bet
        End If
    End Sub

    Private Sub NewGameToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewGameToolStripMenuItem1.Click
        ResetBoard(False)
        out_cash.Text = 100
    End Sub

    Private Sub OpenHighScoresToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenHighScoresToolStripMenuItem.Click
        HighScores.Show()
    End Sub

    Private Sub SubmitScoreToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SubmitScoreToolStripMenuItem.Click
        If out_cash.Text >= 99999999999999998 Then
            Submit_HighScore.score.Text = "MAX"
            Submit_HighScore.Show()
        Else : Submit_HighScore.score.Text = out_cash.Text
            Submit_HighScore.Show()

        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub HowToPlayToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HowToPlayToolStripMenuItem.Click
        Rules.Show()
    End Sub

    Private Sub CreditsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreditsToolStripMenuItem.Click
        MsgBox("Cartas e Programas feito pelo:" + ControlChars.NewLine + "Blackjack 21 - Ricardo Peleira" + ControlChars.NewLine + "Este é um programa livre. Se tiveres algumas duvidas sobre o jogo e o site blackjack contacto-me: 11knum15@gmail.com", 0, "Entertenimento")
    End Sub

    Private Sub Label7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label7.Click

    End Sub

    Private Sub out_cash_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles out_cash.Click

    End Sub
End Class
