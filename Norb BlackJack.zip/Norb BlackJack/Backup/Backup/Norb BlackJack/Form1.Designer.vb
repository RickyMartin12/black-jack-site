﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.dealMenuStrip = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.DealACardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripSeparator
        Me.CancelToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.out_cash = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.cancelMenuStrip = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.betButton = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.total_bets = New System.Windows.Forms.Label
        Me.your_bet = New System.Windows.Forms.TextBox
        Me.debug = New System.Windows.Forms.Label
        Me.op_card1 = New System.Windows.Forms.PictureBox
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.NewGameToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator
        Me.OpenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripSeparator
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.FileToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.NewGameToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.HighScoreToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OpenHighScoresToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripSeparator
        Me.SubmitScoreToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripSeparator
        Me.ExitToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.HelpToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.HowToPlayToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CreditsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.op_card2 = New System.Windows.Forms.PictureBox
        Me.op_card3 = New System.Windows.Forms.PictureBox
        Me.op_card4 = New System.Windows.Forms.PictureBox
        Me.op_card5 = New System.Windows.Forms.PictureBox
        Me.mem_op_card1 = New System.Windows.Forms.Label
        Me.mem_op_card2 = New System.Windows.Forms.Label
        Me.mem_op_card3 = New System.Windows.Forms.Label
        Me.mem_op_card4 = New System.Windows.Forms.Label
        Me.mem_op_card5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.player_card1 = New System.Windows.Forms.PictureBox
        Me.mem_player_card1 = New System.Windows.Forms.Label
        Me.player_card2 = New System.Windows.Forms.PictureBox
        Me.mem_player_card2 = New System.Windows.Forms.Label
        Me.player_card3 = New System.Windows.Forms.PictureBox
        Me.mem_player_card3 = New System.Windows.Forms.Label
        Me.player_card4 = New System.Windows.Forms.PictureBox
        Me.mem_player_card4 = New System.Windows.Forms.Label
        Me.player_card5 = New System.Windows.Forms.PictureBox
        Me.mem_player_card5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.flasH_red = New System.Windows.Forms.Timer(Me.components)
        Me.Button1 = New System.Windows.Forms.Button
        Me.points = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.player_score1 = New System.Windows.Forms.Label
        Me.player_score2 = New System.Windows.Forms.Label
        Me.player_score3 = New System.Windows.Forms.Label
        Me.player_score4 = New System.Windows.Forms.Label
        Me.player_score5 = New System.Windows.Forms.Label
        Me.card1MenuStrip = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.TogleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem7 = New System.Windows.Forms.ToolStripSeparator
        Me.CancelToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.card2MenuStrip = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem8 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripMenuItem9 = New System.Windows.Forms.ToolStripMenuItem
        Me.card3MenuStrip = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem10 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripMenuItem11 = New System.Windows.Forms.ToolStripMenuItem
        Me.card4MenuStrip = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem12 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripMenuItem13 = New System.Windows.Forms.ToolStripMenuItem
        Me.card5MenuStrip = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem14 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripMenuItem15 = New System.Windows.Forms.ToolStripMenuItem
        Me.op_score1 = New System.Windows.Forms.Label
        Me.op_score2 = New System.Windows.Forms.Label
        Me.op_score3 = New System.Windows.Forms.Label
        Me.op_score4 = New System.Windows.Forms.Label
        Me.op_score5 = New System.Windows.Forms.Label
        Me.opponent_turn = New System.Windows.Forms.Timer(Me.components)
        Me.cover1 = New System.Windows.Forms.PictureBox
        Me.cover2 = New System.Windows.Forms.PictureBox
        Me.cover3 = New System.Windows.Forms.PictureBox
        Me.cover4 = New System.Windows.Forms.PictureBox
        Me.cover5 = New System.Windows.Forms.PictureBox
        Me.out_op_score = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.dealMenuStrip.SuspendLayout()
        Me.cancelMenuStrip.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.op_card1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.op_card2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.op_card3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.op_card4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.op_card5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.player_card1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.player_card2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.player_card3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.player_card4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.player_card5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.card1MenuStrip.SuspendLayout()
        Me.card2MenuStrip.SuspendLayout()
        Me.card3MenuStrip.SuspendLayout()
        Me.card4MenuStrip.SuspendLayout()
        Me.card5MenuStrip.SuspendLayout()
        CType(Me.cover1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cover2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cover3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cover4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cover5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.ContextMenuStrip = Me.dealMenuStrip
        Me.PictureBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox1.Enabled = False
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(311, 202)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(162, 83)
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'dealMenuStrip
        '
        Me.dealMenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DealACardToolStripMenuItem, Me.ToolStripMenuItem3, Me.CancelToolStripMenuItem})
        Me.dealMenuStrip.Name = "dealMenuStrip"
        Me.dealMenuStrip.Size = New System.Drawing.Size(137, 54)
        '
        'DealACardToolStripMenuItem
        '
        Me.DealACardToolStripMenuItem.Name = "DealACardToolStripMenuItem"
        Me.DealACardToolStripMenuItem.Size = New System.Drawing.Size(136, 22)
        Me.DealACardToolStripMenuItem.Text = "Deal A Card"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(133, 6)
        '
        'CancelToolStripMenuItem
        '
        Me.CancelToolStripMenuItem.Name = "CancelToolStripMenuItem"
        Me.CancelToolStripMenuItem.Size = New System.Drawing.Size(136, 22)
        Me.CancelToolStripMenuItem.Text = "Cancel"
        '
        'out_cash
        '
        Me.out_cash.AutoSize = True
        Me.out_cash.BackColor = System.Drawing.Color.Transparent
        Me.out_cash.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.out_cash.ForeColor = System.Drawing.Color.White
        Me.out_cash.Location = New System.Drawing.Point(182, 488)
        Me.out_cash.Name = "out_cash"
        Me.out_cash.Size = New System.Drawing.Size(51, 25)
        Me.out_cash.TabIndex = 2
        Me.out_cash.Text = "100"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold)
        Me.Label1.ForeColor = System.Drawing.Color.PaleTurquoise
        Me.Label1.Location = New System.Drawing.Point(361, 283)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 25)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Feito"
        Me.Label1.Visible = False
        '
        'cancelMenuStrip
        '
        Me.cancelMenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem5})
        Me.cancelMenuStrip.Name = "dealMenuStrip"
        Me.cancelMenuStrip.Size = New System.Drawing.Size(111, 26)
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(110, 22)
        Me.ToolStripMenuItem5.Text = "Cancel"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.betButton)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.total_bets)
        Me.GroupBox1.Controls.Add(Me.your_bet)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold)
        Me.GroupBox1.ForeColor = System.Drawing.Color.Yellow
        Me.GroupBox1.Location = New System.Drawing.Point(27, 194)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(278, 100)
        Me.GroupBox1.TabIndex = 5
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Aposta"
        '
        'betButton
        '
        Me.betButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.betButton.ForeColor = System.Drawing.Color.Black
        Me.betButton.Location = New System.Drawing.Point(138, 74)
        Me.betButton.Name = "betButton"
        Me.betButton.Size = New System.Drawing.Size(70, 23)
        Me.betButton.TabIndex = 8
        Me.betButton.Text = "Apostar"
        Me.betButton.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(6, 27)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(162, 25)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "A Sua Aposta:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(6, 58)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 25)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Total:"
        '
        'total_bets
        '
        Me.total_bets.AutoSize = True
        Me.total_bets.Location = New System.Drawing.Point(75, 58)
        Me.total_bets.Name = "total_bets"
        Me.total_bets.Size = New System.Drawing.Size(0, 25)
        Me.total_bets.TabIndex = 1
        '
        'your_bet
        '
        Me.your_bet.Location = New System.Drawing.Point(172, 24)
        Me.your_bet.Name = "your_bet"
        Me.your_bet.Size = New System.Drawing.Size(100, 31)
        Me.your_bet.TabIndex = 0
        Me.your_bet.Text = "50"
        '
        'debug
        '
        Me.debug.AutoSize = True
        Me.debug.Location = New System.Drawing.Point(396, 497)
        Me.debug.Name = "debug"
        Me.debug.Size = New System.Drawing.Size(37, 13)
        Me.debug.TabIndex = 6
        Me.debug.Text = "debug"
        Me.debug.Visible = False
        '
        'op_card1
        '
        Me.op_card1.BackColor = System.Drawing.Color.Transparent
        Me.op_card1.Image = Global.Norb_BlackJack.My.Resources.Resources.back11
        Me.op_card1.Location = New System.Drawing.Point(14, 50)
        Me.op_card1.Name = "op_card1"
        Me.op_card1.Size = New System.Drawing.Size(87, 131)
        Me.op_card1.TabIndex = 7
        Me.op_card1.TabStop = False
        Me.op_card1.Visible = False
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewGameToolStripMenuItem, Me.ToolStripMenuItem1, Me.OpenToolStripMenuItem, Me.SaveToolStripMenuItem, Me.ToolStripMenuItem2, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(38, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'NewGameToolStripMenuItem
        '
        Me.NewGameToolStripMenuItem.Name = "NewGameToolStripMenuItem"
        Me.NewGameToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.NewGameToolStripMenuItem.Text = "New Game"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(129, 6)
        '
        'OpenToolStripMenuItem
        '
        Me.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem"
        Me.OpenToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.OpenToolStripMenuItem.Text = "Load"
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.SaveToolStripMenuItem.Text = "Save"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(129, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(45, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.SeaGreen
        Me.MenuStrip1.BackgroundImage = Global.Norb_BlackJack.My.Resources.Resources.casino_wallpaper_311
        Me.MenuStrip1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem1, Me.HelpToolStripMenuItem1})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(495, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem1
        '
        Me.FileToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewGameToolStripMenuItem1, Me.HighScoreToolStripMenuItem, Me.ToolStripMenuItem4, Me.ExitToolStripMenuItem1})
        Me.FileToolStripMenuItem1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.FileToolStripMenuItem1.Name = "FileToolStripMenuItem1"
        Me.FileToolStripMenuItem1.Size = New System.Drawing.Size(71, 20)
        Me.FileToolStripMenuItem1.Text = "Ficheiro"
        '
        'NewGameToolStripMenuItem1
        '
        Me.NewGameToolStripMenuItem1.Name = "NewGameToolStripMenuItem1"
        Me.NewGameToolStripMenuItem1.Size = New System.Drawing.Size(149, 22)
        Me.NewGameToolStripMenuItem1.Text = "Novo Jogo"
        '
        'HighScoreToolStripMenuItem
        '
        Me.HighScoreToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenHighScoresToolStripMenuItem, Me.ToolStripMenuItem6, Me.SubmitScoreToolStripMenuItem})
        Me.HighScoreToolStripMenuItem.Name = "HighScoreToolStripMenuItem"
        Me.HighScoreToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.HighScoreToolStripMenuItem.Text = "Pontuações"
        '
        'OpenHighScoresToolStripMenuItem
        '
        Me.OpenHighScoresToolStripMenuItem.Name = "OpenHighScoresToolStripMenuItem"
        Me.OpenHighScoresToolStripMenuItem.Size = New System.Drawing.Size(201, 22)
        Me.OpenHighScoresToolStripMenuItem.Text = "Abrir as pontuações"
        '
        'ToolStripMenuItem6
        '
        Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
        Me.ToolStripMenuItem6.Size = New System.Drawing.Size(198, 6)
        '
        'SubmitScoreToolStripMenuItem
        '
        Me.SubmitScoreToolStripMenuItem.Name = "SubmitScoreToolStripMenuItem"
        Me.SubmitScoreToolStripMenuItem.Size = New System.Drawing.Size(201, 22)
        Me.SubmitScoreToolStripMenuItem.Text = "Inserir pontuação"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(146, 6)
        '
        'ExitToolStripMenuItem1
        '
        Me.ExitToolStripMenuItem1.Name = "ExitToolStripMenuItem1"
        Me.ExitToolStripMenuItem1.Size = New System.Drawing.Size(149, 22)
        Me.ExitToolStripMenuItem1.Text = "Sair"
        '
        'HelpToolStripMenuItem1
        '
        Me.HelpToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HowToPlayToolStripMenuItem, Me.CreditsToolStripMenuItem})
        Me.HelpToolStripMenuItem1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.HelpToolStripMenuItem1.Name = "HelpToolStripMenuItem1"
        Me.HelpToolStripMenuItem1.Size = New System.Drawing.Size(55, 20)
        Me.HelpToolStripMenuItem1.Text = "Ajuda"
        '
        'HowToPlayToolStripMenuItem
        '
        Me.HowToPlayToolStripMenuItem.Name = "HowToPlayToolStripMenuItem"
        Me.HowToPlayToolStripMenuItem.Size = New System.Drawing.Size(174, 22)
        Me.HowToPlayToolStripMenuItem.Text = "Regras Basicas"
        '
        'CreditsToolStripMenuItem
        '
        Me.CreditsToolStripMenuItem.Name = "CreditsToolStripMenuItem"
        Me.CreditsToolStripMenuItem.Size = New System.Drawing.Size(174, 22)
        Me.CreditsToolStripMenuItem.Text = "Creditos"
        '
        'op_card2
        '
        Me.op_card2.BackColor = System.Drawing.Color.Transparent
        Me.op_card2.Image = Global.Norb_BlackJack.My.Resources.Resources.back11
        Me.op_card2.Location = New System.Drawing.Point(107, 50)
        Me.op_card2.Name = "op_card2"
        Me.op_card2.Size = New System.Drawing.Size(87, 131)
        Me.op_card2.TabIndex = 7
        Me.op_card2.TabStop = False
        Me.op_card2.Visible = False
        '
        'op_card3
        '
        Me.op_card3.BackColor = System.Drawing.Color.Transparent
        Me.op_card3.Image = Global.Norb_BlackJack.My.Resources.Resources.back11
        Me.op_card3.Location = New System.Drawing.Point(200, 50)
        Me.op_card3.Name = "op_card3"
        Me.op_card3.Size = New System.Drawing.Size(87, 131)
        Me.op_card3.TabIndex = 7
        Me.op_card3.TabStop = False
        Me.op_card3.Visible = False
        '
        'op_card4
        '
        Me.op_card4.BackColor = System.Drawing.Color.Transparent
        Me.op_card4.Image = Global.Norb_BlackJack.My.Resources.Resources.back11
        Me.op_card4.Location = New System.Drawing.Point(293, 50)
        Me.op_card4.Name = "op_card4"
        Me.op_card4.Size = New System.Drawing.Size(87, 131)
        Me.op_card4.TabIndex = 7
        Me.op_card4.TabStop = False
        Me.op_card4.Visible = False
        '
        'op_card5
        '
        Me.op_card5.BackColor = System.Drawing.Color.Transparent
        Me.op_card5.Image = Global.Norb_BlackJack.My.Resources.Resources.back11
        Me.op_card5.Location = New System.Drawing.Point(386, 50)
        Me.op_card5.Name = "op_card5"
        Me.op_card5.Size = New System.Drawing.Size(87, 131)
        Me.op_card5.TabIndex = 7
        Me.op_card5.TabStop = False
        Me.op_card5.Visible = False
        '
        'mem_op_card1
        '
        Me.mem_op_card1.AutoSize = True
        Me.mem_op_card1.Location = New System.Drawing.Point(14, 101)
        Me.mem_op_card1.Name = "mem_op_card1"
        Me.mem_op_card1.Size = New System.Drawing.Size(13, 13)
        Me.mem_op_card1.TabIndex = 8
        Me.mem_op_card1.Text = "0"
        Me.mem_op_card1.Visible = False
        '
        'mem_op_card2
        '
        Me.mem_op_card2.AutoSize = True
        Me.mem_op_card2.Location = New System.Drawing.Point(111, 101)
        Me.mem_op_card2.Name = "mem_op_card2"
        Me.mem_op_card2.Size = New System.Drawing.Size(13, 13)
        Me.mem_op_card2.TabIndex = 8
        Me.mem_op_card2.Text = "0"
        Me.mem_op_card2.Visible = False
        '
        'mem_op_card3
        '
        Me.mem_op_card3.AutoSize = True
        Me.mem_op_card3.Location = New System.Drawing.Point(200, 101)
        Me.mem_op_card3.Name = "mem_op_card3"
        Me.mem_op_card3.Size = New System.Drawing.Size(13, 13)
        Me.mem_op_card3.TabIndex = 8
        Me.mem_op_card3.Text = "0"
        Me.mem_op_card3.Visible = False
        '
        'mem_op_card4
        '
        Me.mem_op_card4.AutoSize = True
        Me.mem_op_card4.Location = New System.Drawing.Point(293, 101)
        Me.mem_op_card4.Name = "mem_op_card4"
        Me.mem_op_card4.Size = New System.Drawing.Size(13, 13)
        Me.mem_op_card4.TabIndex = 8
        Me.mem_op_card4.Text = "0"
        Me.mem_op_card4.Visible = False
        '
        'mem_op_card5
        '
        Me.mem_op_card5.AutoSize = True
        Me.mem_op_card5.Location = New System.Drawing.Point(393, 101)
        Me.mem_op_card5.Name = "mem_op_card5"
        Me.mem_op_card5.Size = New System.Drawing.Size(13, 13)
        Me.mem_op_card5.TabIndex = 8
        Me.mem_op_card5.Text = "0"
        Me.mem_op_card5.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold)
        Me.Label4.Location = New System.Drawing.Point(99, 296)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(134, 25)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "A Sua Mão:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold)
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label5.Location = New System.Drawing.Point(161, 23)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(146, 25)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Computador:"
        '
        'player_card1
        '
        Me.player_card1.BackColor = System.Drawing.Color.Transparent
        Me.player_card1.Image = Global.Norb_BlackJack.My.Resources.Resources.back11
        Me.player_card1.Location = New System.Drawing.Point(14, 324)
        Me.player_card1.Name = "player_card1"
        Me.player_card1.Size = New System.Drawing.Size(87, 131)
        Me.player_card1.TabIndex = 7
        Me.player_card1.TabStop = False
        Me.player_card1.Visible = False
        '
        'mem_player_card1
        '
        Me.mem_player_card1.AutoSize = True
        Me.mem_player_card1.Location = New System.Drawing.Point(14, 363)
        Me.mem_player_card1.Name = "mem_player_card1"
        Me.mem_player_card1.Size = New System.Drawing.Size(13, 13)
        Me.mem_player_card1.TabIndex = 8
        Me.mem_player_card1.Text = "0"
        Me.mem_player_card1.Visible = False
        '
        'player_card2
        '
        Me.player_card2.BackColor = System.Drawing.Color.Transparent
        Me.player_card2.Image = Global.Norb_BlackJack.My.Resources.Resources.back11
        Me.player_card2.Location = New System.Drawing.Point(107, 324)
        Me.player_card2.Name = "player_card2"
        Me.player_card2.Size = New System.Drawing.Size(87, 131)
        Me.player_card2.TabIndex = 7
        Me.player_card2.TabStop = False
        Me.player_card2.Visible = False
        '
        'mem_player_card2
        '
        Me.mem_player_card2.AutoSize = True
        Me.mem_player_card2.Location = New System.Drawing.Point(107, 390)
        Me.mem_player_card2.Name = "mem_player_card2"
        Me.mem_player_card2.Size = New System.Drawing.Size(13, 13)
        Me.mem_player_card2.TabIndex = 8
        Me.mem_player_card2.Text = "0"
        Me.mem_player_card2.Visible = False
        '
        'player_card3
        '
        Me.player_card3.BackColor = System.Drawing.Color.Transparent
        Me.player_card3.Image = Global.Norb_BlackJack.My.Resources.Resources.back11
        Me.player_card3.Location = New System.Drawing.Point(200, 324)
        Me.player_card3.Name = "player_card3"
        Me.player_card3.Size = New System.Drawing.Size(87, 131)
        Me.player_card3.TabIndex = 7
        Me.player_card3.TabStop = False
        Me.player_card3.Visible = False
        '
        'mem_player_card3
        '
        Me.mem_player_card3.AutoSize = True
        Me.mem_player_card3.Location = New System.Drawing.Point(200, 365)
        Me.mem_player_card3.Name = "mem_player_card3"
        Me.mem_player_card3.Size = New System.Drawing.Size(13, 13)
        Me.mem_player_card3.TabIndex = 8
        Me.mem_player_card3.Text = "0"
        Me.mem_player_card3.Visible = False
        '
        'player_card4
        '
        Me.player_card4.BackColor = System.Drawing.Color.Transparent
        Me.player_card4.Image = Global.Norb_BlackJack.My.Resources.Resources.back11
        Me.player_card4.Location = New System.Drawing.Point(293, 324)
        Me.player_card4.Name = "player_card4"
        Me.player_card4.Size = New System.Drawing.Size(87, 131)
        Me.player_card4.TabIndex = 7
        Me.player_card4.TabStop = False
        Me.player_card4.Visible = False
        '
        'mem_player_card4
        '
        Me.mem_player_card4.AutoSize = True
        Me.mem_player_card4.Location = New System.Drawing.Point(293, 396)
        Me.mem_player_card4.Name = "mem_player_card4"
        Me.mem_player_card4.Size = New System.Drawing.Size(13, 13)
        Me.mem_player_card4.TabIndex = 8
        Me.mem_player_card4.Text = "0"
        Me.mem_player_card4.Visible = False
        '
        'player_card5
        '
        Me.player_card5.BackColor = System.Drawing.Color.Transparent
        Me.player_card5.Image = Global.Norb_BlackJack.My.Resources.Resources.back11
        Me.player_card5.Location = New System.Drawing.Point(386, 324)
        Me.player_card5.Name = "player_card5"
        Me.player_card5.Size = New System.Drawing.Size(87, 131)
        Me.player_card5.TabIndex = 7
        Me.player_card5.TabStop = False
        Me.player_card5.Visible = False
        '
        'mem_player_card5
        '
        Me.mem_player_card5.AutoSize = True
        Me.mem_player_card5.Location = New System.Drawing.Point(386, 361)
        Me.mem_player_card5.Name = "mem_player_card5"
        Me.mem_player_card5.Size = New System.Drawing.Size(13, 13)
        Me.mem_player_card5.TabIndex = 8
        Me.mem_player_card5.Text = "0"
        Me.mem_player_card5.Visible = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.LightBlue
        Me.Label6.Location = New System.Drawing.Point(6, 488)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(175, 25)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "O teu dinheiro: "
        '
        'flasH_red
        '
        Me.flasH_red.Interval = 500
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.DarkGreen
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold)
        Me.Button1.ForeColor = System.Drawing.Color.Gold
        Me.Button1.Location = New System.Drawing.Point(385, 473)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(109, 38)
        Me.Button1.TabIndex = 10
        Me.Button1.Text = "Submeter "
        Me.Button1.UseVisualStyleBackColor = False
        '
        'points
        '
        Me.points.AutoSize = True
        Me.points.BackColor = System.Drawing.Color.Transparent
        Me.points.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.points.ForeColor = System.Drawing.Color.White
        Me.points.Location = New System.Drawing.Point(354, 470)
        Me.points.Name = "points"
        Me.points.Size = New System.Drawing.Size(25, 25)
        Me.points.TabIndex = 2
        Me.points.Text = "0"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Aqua
        Me.Label8.Location = New System.Drawing.Point(264, 470)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(92, 25)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "Pontos:"
        '
        'player_score1
        '
        Me.player_score1.AutoSize = True
        Me.player_score1.BackColor = System.Drawing.Color.Black
        Me.player_score1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.player_score1.ForeColor = System.Drawing.Color.White
        Me.player_score1.Location = New System.Drawing.Point(41, 441)
        Me.player_score1.Name = "player_score1"
        Me.player_score1.Size = New System.Drawing.Size(30, 31)
        Me.player_score1.TabIndex = 11
        Me.player_score1.Text = "0"
        Me.player_score1.Visible = False
        '
        'player_score2
        '
        Me.player_score2.AutoSize = True
        Me.player_score2.BackColor = System.Drawing.Color.Black
        Me.player_score2.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.player_score2.ForeColor = System.Drawing.Color.White
        Me.player_score2.Location = New System.Drawing.Point(134, 441)
        Me.player_score2.Name = "player_score2"
        Me.player_score2.Size = New System.Drawing.Size(30, 31)
        Me.player_score2.TabIndex = 11
        Me.player_score2.Text = "0"
        Me.player_score2.Visible = False
        '
        'player_score3
        '
        Me.player_score3.AutoSize = True
        Me.player_score3.BackColor = System.Drawing.Color.Black
        Me.player_score3.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.player_score3.ForeColor = System.Drawing.Color.White
        Me.player_score3.Location = New System.Drawing.Point(228, 441)
        Me.player_score3.Name = "player_score3"
        Me.player_score3.Size = New System.Drawing.Size(30, 31)
        Me.player_score3.TabIndex = 11
        Me.player_score3.Text = "0"
        Me.player_score3.Visible = False
        '
        'player_score4
        '
        Me.player_score4.AutoSize = True
        Me.player_score4.BackColor = System.Drawing.Color.Black
        Me.player_score4.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.player_score4.ForeColor = System.Drawing.Color.White
        Me.player_score4.Location = New System.Drawing.Point(322, 441)
        Me.player_score4.Name = "player_score4"
        Me.player_score4.Size = New System.Drawing.Size(30, 31)
        Me.player_score4.TabIndex = 11
        Me.player_score4.Text = "0"
        Me.player_score4.Visible = False
        '
        'player_score5
        '
        Me.player_score5.AutoSize = True
        Me.player_score5.BackColor = System.Drawing.Color.Black
        Me.player_score5.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.player_score5.ForeColor = System.Drawing.Color.White
        Me.player_score5.Location = New System.Drawing.Point(413, 441)
        Me.player_score5.Name = "player_score5"
        Me.player_score5.Size = New System.Drawing.Size(30, 31)
        Me.player_score5.TabIndex = 11
        Me.player_score5.Text = "0"
        Me.player_score5.Visible = False
        '
        'card1MenuStrip
        '
        Me.card1MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TogleToolStripMenuItem, Me.ToolStripMenuItem7, Me.CancelToolStripMenuItem1})
        Me.card1MenuStrip.Name = "card1MenuStrip"
        Me.card1MenuStrip.Size = New System.Drawing.Size(112, 54)
        '
        'TogleToolStripMenuItem
        '
        Me.TogleToolStripMenuItem.Name = "TogleToolStripMenuItem"
        Me.TogleToolStripMenuItem.Size = New System.Drawing.Size(111, 22)
        Me.TogleToolStripMenuItem.Text = "Toggle"
        '
        'ToolStripMenuItem7
        '
        Me.ToolStripMenuItem7.Name = "ToolStripMenuItem7"
        Me.ToolStripMenuItem7.Size = New System.Drawing.Size(108, 6)
        '
        'CancelToolStripMenuItem1
        '
        Me.CancelToolStripMenuItem1.Name = "CancelToolStripMenuItem1"
        Me.CancelToolStripMenuItem1.Size = New System.Drawing.Size(111, 22)
        Me.CancelToolStripMenuItem1.Text = "Cancel"
        '
        'card2MenuStrip
        '
        Me.card2MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem8, Me.ToolStripSeparator1, Me.ToolStripMenuItem9})
        Me.card2MenuStrip.Name = "card1MenuStrip"
        Me.card2MenuStrip.Size = New System.Drawing.Size(112, 54)
        '
        'ToolStripMenuItem8
        '
        Me.ToolStripMenuItem8.Name = "ToolStripMenuItem8"
        Me.ToolStripMenuItem8.Size = New System.Drawing.Size(111, 22)
        Me.ToolStripMenuItem8.Text = "Toggle"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(108, 6)
        '
        'ToolStripMenuItem9
        '
        Me.ToolStripMenuItem9.Name = "ToolStripMenuItem9"
        Me.ToolStripMenuItem9.Size = New System.Drawing.Size(111, 22)
        Me.ToolStripMenuItem9.Text = "Cancel"
        '
        'card3MenuStrip
        '
        Me.card3MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem10, Me.ToolStripSeparator2, Me.ToolStripMenuItem11})
        Me.card3MenuStrip.Name = "card1MenuStrip"
        Me.card3MenuStrip.Size = New System.Drawing.Size(112, 54)
        '
        'ToolStripMenuItem10
        '
        Me.ToolStripMenuItem10.Name = "ToolStripMenuItem10"
        Me.ToolStripMenuItem10.Size = New System.Drawing.Size(111, 22)
        Me.ToolStripMenuItem10.Text = "Toggle"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(108, 6)
        '
        'ToolStripMenuItem11
        '
        Me.ToolStripMenuItem11.Name = "ToolStripMenuItem11"
        Me.ToolStripMenuItem11.Size = New System.Drawing.Size(111, 22)
        Me.ToolStripMenuItem11.Text = "Cancel"
        '
        'card4MenuStrip
        '
        Me.card4MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem12, Me.ToolStripSeparator3, Me.ToolStripMenuItem13})
        Me.card4MenuStrip.Name = "card1MenuStrip"
        Me.card4MenuStrip.Size = New System.Drawing.Size(112, 54)
        '
        'ToolStripMenuItem12
        '
        Me.ToolStripMenuItem12.Name = "ToolStripMenuItem12"
        Me.ToolStripMenuItem12.Size = New System.Drawing.Size(111, 22)
        Me.ToolStripMenuItem12.Text = "Toggle"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(108, 6)
        '
        'ToolStripMenuItem13
        '
        Me.ToolStripMenuItem13.Name = "ToolStripMenuItem13"
        Me.ToolStripMenuItem13.Size = New System.Drawing.Size(111, 22)
        Me.ToolStripMenuItem13.Text = "Cancel"
        '
        'card5MenuStrip
        '
        Me.card5MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem14, Me.ToolStripSeparator4, Me.ToolStripMenuItem15})
        Me.card5MenuStrip.Name = "card1MenuStrip"
        Me.card5MenuStrip.Size = New System.Drawing.Size(112, 54)
        '
        'ToolStripMenuItem14
        '
        Me.ToolStripMenuItem14.Name = "ToolStripMenuItem14"
        Me.ToolStripMenuItem14.Size = New System.Drawing.Size(111, 22)
        Me.ToolStripMenuItem14.Text = "Toggle"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(108, 6)
        '
        'ToolStripMenuItem15
        '
        Me.ToolStripMenuItem15.Name = "ToolStripMenuItem15"
        Me.ToolStripMenuItem15.Size = New System.Drawing.Size(111, 22)
        Me.ToolStripMenuItem15.Text = "Cancel"
        '
        'op_score1
        '
        Me.op_score1.AutoSize = True
        Me.op_score1.BackColor = System.Drawing.Color.Black
        Me.op_score1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.op_score1.ForeColor = System.Drawing.Color.White
        Me.op_score1.Location = New System.Drawing.Point(41, 159)
        Me.op_score1.Name = "op_score1"
        Me.op_score1.Size = New System.Drawing.Size(30, 31)
        Me.op_score1.TabIndex = 11
        Me.op_score1.Text = "0"
        Me.op_score1.Visible = False
        '
        'op_score2
        '
        Me.op_score2.AutoSize = True
        Me.op_score2.BackColor = System.Drawing.Color.Black
        Me.op_score2.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.op_score2.ForeColor = System.Drawing.Color.White
        Me.op_score2.Location = New System.Drawing.Point(134, 159)
        Me.op_score2.Name = "op_score2"
        Me.op_score2.Size = New System.Drawing.Size(30, 31)
        Me.op_score2.TabIndex = 11
        Me.op_score2.Text = "0"
        Me.op_score2.Visible = False
        '
        'op_score3
        '
        Me.op_score3.AutoSize = True
        Me.op_score3.BackColor = System.Drawing.Color.Black
        Me.op_score3.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.op_score3.ForeColor = System.Drawing.Color.White
        Me.op_score3.Location = New System.Drawing.Point(228, 159)
        Me.op_score3.Name = "op_score3"
        Me.op_score3.Size = New System.Drawing.Size(30, 31)
        Me.op_score3.TabIndex = 11
        Me.op_score3.Text = "0"
        Me.op_score3.Visible = False
        '
        'op_score4
        '
        Me.op_score4.AutoSize = True
        Me.op_score4.BackColor = System.Drawing.Color.Black
        Me.op_score4.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.op_score4.ForeColor = System.Drawing.Color.White
        Me.op_score4.Location = New System.Drawing.Point(322, 159)
        Me.op_score4.Name = "op_score4"
        Me.op_score4.Size = New System.Drawing.Size(30, 31)
        Me.op_score4.TabIndex = 11
        Me.op_score4.Text = "0"
        Me.op_score4.Visible = False
        '
        'op_score5
        '
        Me.op_score5.AutoSize = True
        Me.op_score5.BackColor = System.Drawing.Color.Black
        Me.op_score5.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.op_score5.ForeColor = System.Drawing.Color.White
        Me.op_score5.Location = New System.Drawing.Point(413, 159)
        Me.op_score5.Name = "op_score5"
        Me.op_score5.Size = New System.Drawing.Size(30, 31)
        Me.op_score5.TabIndex = 11
        Me.op_score5.Text = "0"
        Me.op_score5.Visible = False
        '
        'opponent_turn
        '
        Me.opponent_turn.Interval = 1000
        '
        'cover1
        '
        Me.cover1.BackColor = System.Drawing.Color.Transparent
        Me.cover1.Image = Global.Norb_BlackJack.My.Resources.Resources.back11
        Me.cover1.Location = New System.Drawing.Point(14, 50)
        Me.cover1.Name = "cover1"
        Me.cover1.Size = New System.Drawing.Size(87, 131)
        Me.cover1.TabIndex = 7
        Me.cover1.TabStop = False
        Me.cover1.Visible = False
        '
        'cover2
        '
        Me.cover2.BackColor = System.Drawing.Color.Transparent
        Me.cover2.Image = Global.Norb_BlackJack.My.Resources.Resources.back11
        Me.cover2.Location = New System.Drawing.Point(107, 51)
        Me.cover2.Name = "cover2"
        Me.cover2.Size = New System.Drawing.Size(87, 131)
        Me.cover2.TabIndex = 7
        Me.cover2.TabStop = False
        Me.cover2.Visible = False
        '
        'cover3
        '
        Me.cover3.BackColor = System.Drawing.Color.Transparent
        Me.cover3.Image = Global.Norb_BlackJack.My.Resources.Resources.back11
        Me.cover3.Location = New System.Drawing.Point(200, 51)
        Me.cover3.Name = "cover3"
        Me.cover3.Size = New System.Drawing.Size(87, 131)
        Me.cover3.TabIndex = 7
        Me.cover3.TabStop = False
        Me.cover3.Visible = False
        '
        'cover4
        '
        Me.cover4.BackColor = System.Drawing.Color.Transparent
        Me.cover4.Image = Global.Norb_BlackJack.My.Resources.Resources.back11
        Me.cover4.Location = New System.Drawing.Point(293, 50)
        Me.cover4.Name = "cover4"
        Me.cover4.Size = New System.Drawing.Size(87, 131)
        Me.cover4.TabIndex = 7
        Me.cover4.TabStop = False
        Me.cover4.Visible = False
        '
        'cover5
        '
        Me.cover5.BackColor = System.Drawing.Color.Transparent
        Me.cover5.Image = Global.Norb_BlackJack.My.Resources.Resources.back11
        Me.cover5.Location = New System.Drawing.Point(386, 50)
        Me.cover5.Name = "cover5"
        Me.cover5.Size = New System.Drawing.Size(87, 131)
        Me.cover5.TabIndex = 7
        Me.cover5.TabStop = False
        Me.cover5.Visible = False
        '
        'out_op_score
        '
        Me.out_op_score.AutoSize = True
        Me.out_op_score.BackColor = System.Drawing.Color.Transparent
        Me.out_op_score.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.out_op_score.ForeColor = System.Drawing.Color.White
        Me.out_op_score.Location = New System.Drawing.Point(442, 24)
        Me.out_op_score.Name = "out_op_score"
        Me.out_op_score.Size = New System.Drawing.Size(25, 25)
        Me.out_op_score.TabIndex = 2
        Me.out_op_score.Text = "0"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Aqua
        Me.Label9.Location = New System.Drawing.Point(351, 24)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(92, 25)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "Pontos:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label7.Image = Global.Norb_BlackJack.My.Resources.Resources.casino_wallpaper_31
        Me.Label7.Location = New System.Drawing.Point(229, 488)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(25, 25)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "€"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(495, 513)
        Me.ContextMenuStrip = Me.cancelMenuStrip
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.player_score5)
        Me.Controls.Add(Me.player_score4)
        Me.Controls.Add(Me.player_score3)
        Me.Controls.Add(Me.player_score2)
        Me.Controls.Add(Me.player_score1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.op_score5)
        Me.Controls.Add(Me.op_score4)
        Me.Controls.Add(Me.mem_op_card5)
        Me.Controls.Add(Me.op_score3)
        Me.Controls.Add(Me.mem_op_card4)
        Me.Controls.Add(Me.op_score2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.op_score1)
        Me.Controls.Add(Me.mem_op_card3)
        Me.Controls.Add(Me.mem_op_card2)
        Me.Controls.Add(Me.mem_player_card5)
        Me.Controls.Add(Me.mem_player_card4)
        Me.Controls.Add(Me.mem_player_card3)
        Me.Controls.Add(Me.mem_player_card2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.mem_player_card1)
        Me.Controls.Add(Me.mem_op_card1)
        Me.Controls.Add(Me.debug)
        Me.Controls.Add(Me.player_card5)
        Me.Controls.Add(Me.player_card4)
        Me.Controls.Add(Me.player_card3)
        Me.Controls.Add(Me.player_card2)
        Me.Controls.Add(Me.player_card1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.op_card2)
        Me.Controls.Add(Me.cover2)
        Me.Controls.Add(Me.cover3)
        Me.Controls.Add(Me.op_card1)
        Me.Controls.Add(Me.op_card3)
        Me.Controls.Add(Me.op_card4)
        Me.Controls.Add(Me.cover1)
        Me.Controls.Add(Me.points)
        Me.Controls.Add(Me.cover4)
        Me.Controls.Add(Me.cover5)
        Me.Controls.Add(Me.op_card5)
        Me.Controls.Add(Me.out_op_score)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.out_cash)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(511, 549)
        Me.MinimumSize = New System.Drawing.Size(511, 549)
        Me.Name = "Form1"
        Me.Text = " BlackJack"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.dealMenuStrip.ResumeLayout(False)
        Me.cancelMenuStrip.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.op_card1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.op_card2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.op_card3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.op_card4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.op_card5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.player_card1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.player_card2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.player_card3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.player_card4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.player_card5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.card1MenuStrip.ResumeLayout(False)
        Me.card2MenuStrip.ResumeLayout(False)
        Me.card3MenuStrip.ResumeLayout(False)
        Me.card4MenuStrip.ResumeLayout(False)
        Me.card5MenuStrip.ResumeLayout(False)
        CType(Me.cover1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cover2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cover3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cover4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cover5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents out_cash As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents dealMenuStrip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents DealACardToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CancelToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cancelMenuStrip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents debug As System.Windows.Forms.Label
    Friend WithEvents your_bet As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents total_bets As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents betButton As System.Windows.Forms.Button
    Friend WithEvents op_card1 As System.Windows.Forms.PictureBox
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewGameToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents OpenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewGameToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExitToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HowToPlayToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents op_card2 As System.Windows.Forms.PictureBox
    Friend WithEvents op_card3 As System.Windows.Forms.PictureBox
    Friend WithEvents op_card4 As System.Windows.Forms.PictureBox
    Friend WithEvents op_card5 As System.Windows.Forms.PictureBox
    Friend WithEvents mem_op_card1 As System.Windows.Forms.Label
    Friend WithEvents mem_op_card2 As System.Windows.Forms.Label
    Friend WithEvents mem_op_card3 As System.Windows.Forms.Label
    Friend WithEvents mem_op_card4 As System.Windows.Forms.Label
    Friend WithEvents mem_op_card5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents player_card1 As System.Windows.Forms.PictureBox
    Friend WithEvents mem_player_card1 As System.Windows.Forms.Label
    Friend WithEvents player_card2 As System.Windows.Forms.PictureBox
    Friend WithEvents mem_player_card2 As System.Windows.Forms.Label
    Friend WithEvents player_card3 As System.Windows.Forms.PictureBox
    Friend WithEvents mem_player_card3 As System.Windows.Forms.Label
    Friend WithEvents player_card4 As System.Windows.Forms.PictureBox
    Friend WithEvents mem_player_card4 As System.Windows.Forms.Label
    Friend WithEvents player_card5 As System.Windows.Forms.PictureBox
    Friend WithEvents mem_player_card5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents flasH_red As System.Windows.Forms.Timer
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents points As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents player_score1 As System.Windows.Forms.Label
    Friend WithEvents player_score2 As System.Windows.Forms.Label
    Friend WithEvents player_score3 As System.Windows.Forms.Label
    Friend WithEvents player_score4 As System.Windows.Forms.Label
    Friend WithEvents player_score5 As System.Windows.Forms.Label
    Friend WithEvents card1MenuStrip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents TogleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CancelToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents card2MenuStrip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ToolStripMenuItem8 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripMenuItem9 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents card3MenuStrip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ToolStripMenuItem10 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripMenuItem11 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents card4MenuStrip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ToolStripMenuItem12 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripMenuItem13 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents card5MenuStrip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ToolStripMenuItem14 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripMenuItem15 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents op_score1 As System.Windows.Forms.Label
    Friend WithEvents op_score2 As System.Windows.Forms.Label
    Friend WithEvents op_score3 As System.Windows.Forms.Label
    Friend WithEvents op_score4 As System.Windows.Forms.Label
    Friend WithEvents op_score5 As System.Windows.Forms.Label
    Friend WithEvents opponent_turn As System.Windows.Forms.Timer
    Friend WithEvents cover1 As System.Windows.Forms.PictureBox
    Friend WithEvents cover2 As System.Windows.Forms.PictureBox
    Friend WithEvents cover3 As System.Windows.Forms.PictureBox
    Friend WithEvents cover4 As System.Windows.Forms.PictureBox
    Friend WithEvents cover5 As System.Windows.Forms.PictureBox
    Friend WithEvents out_op_score As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents HighScoreToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenHighScoresToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SubmitScoreToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CreditsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label7 As System.Windows.Forms.Label

End Class
