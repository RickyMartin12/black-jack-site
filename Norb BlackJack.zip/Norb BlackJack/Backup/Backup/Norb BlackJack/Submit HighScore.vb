﻿Public Class Submit_HighScore
    Dim new_place As Integer


    Private Sub Submit_HighScore_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            If My.Computer.FileSystem.FileExists("NorbBJhs.dat") Then
                Dim HSReader As IO.StreamReader
                HSReader = My.Computer.FileSystem.OpenTextFileReader("NorbBJhs.dat")
                player1.Text = HSReader.ReadLine
                score1.Text = HSReader.ReadLine
                player2.Text = HSReader.ReadLine
                score2.Text = HSReader.ReadLine
                player3.Text = HSReader.ReadLine
                score3.Text = HSReader.ReadLine
                player4.Text = HSReader.ReadLine
                score4.Text = HSReader.ReadLine
                player5.Text = HSReader.ReadLine
                score5.Text = HSReader.ReadLine
                player6.Text = HSReader.ReadLine
                score6.Text = HSReader.ReadLine
                player7.Text = HSReader.ReadLine
                score7.Text = HSReader.ReadLine
                player8.Text = HSReader.ReadLine
                score8.Text = HSReader.ReadLine
                player9.Text = HSReader.ReadLine
                score9.Text = HSReader.ReadLine
                player10.Text = HSReader.ReadLine
                score10.Text = HSReader.ReadLine
                HSReader.Close()
                DecideSpot()
            Else
                MsgBox("Não é possível encontrar pontos de alta", 0, "Ficheiro não encontrado")
                Close()
            End If
        Catch ex As Exception
            MsgBox("Não é possível ler de alta pontuação, tente executar como administrador", 0, "Não é possível ler o arquivo")
        End Try
    End Sub

    Public Sub DecideSpot()
        Dim int_score As Integer
        Dim int_score1 As Integer
        Dim int_score2 As Integer
        Dim int_score3 As Integer
        Dim int_score4 As Integer
        Dim int_score5 As Integer
        Dim int_score6 As Integer
        Dim int_score7 As Integer
        Dim int_score8 As Integer
        Dim int_score9 As Integer
        Dim int_score10 As Integer
        Try
            int_score = score.Text
        Catch ex As Exception
            int_score = -1
        End Try
        int_score1 = score1.Text
        int_score2 = score2.Text
        int_score3 = score3.Text
        int_score4 = score4.Text
        int_score5 = score5.Text
        int_score6 = score6.Text
        int_score7 = score7.Text
        int_score8 = score8.Text
        int_score9 = score9.Text
        int_score10 = score10.Text
        '
        If score.Text = "MAX" Then
            new_place = 1
        Else
            If int_score > int_score1 Then
                new_place = 1
            Else
                If int_score > int_score2 Then
                    new_place = 2
                Else
                    If int_score > int_score3 Then
                        new_place = 3
                    Else
                        If int_score > int_score4 Then
                            new_place = 4
                        Else
                            If int_score > int_score5 Then
                                new_place = 5
                            Else
                                If int_score > int_score6 Then
                                    new_place = 6
                                Else
                                    If int_score > int_score7 Then
                                        new_place = 7
                                    Else
                                        If int_score > int_score8 Then
                                            new_place = 8
                                        Else
                                            If int_score > int_score9 Then
                                                new_place = 9
                                            Else
                                                If int_score > int_score10 Then
                                                    new_place = 10
                                                Else
                                                    MsgBox("Desculpe, mas sua pontuação não vencer qualquer um na alta pontuação. Você precisa collecionar pelo menos 5" + score10.Text + ", Tente ser dificil", 0, "Perdeste")
                                                    Close()
                                                End If
                                            End If
                                        End If
                                    End If
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        End If
    End Sub

    Public Sub UpdateScores(ByVal spotTaken As Integer)
        If spotTaken = 1 Then
            player10.Text = player9.Text
            player9.Text = player8.Text
            player8.Text = player7.Text
            player7.Text = player6.Text
            player6.Text = player5.Text
            player5.Text = player4.Text
            player4.Text = player3.Text
            player3.Text = player2.Text
            player2.Text = player1.Text
            player1.Text = player.Text
            '
            score10.Text = score9.Text
            score9.Text = score8.Text
            score8.Text = score7.Text
            score7.Text = score6.Text
            score6.Text = score5.Text
            score5.Text = score4.Text
            score4.Text = score3.Text
            score3.Text = score2.Text
            score2.Text = score1.Text
            score1.Text = score.Text
        End If
        If spotTaken = 2 Then
            player10.Text = player9.Text
            player9.Text = player8.Text
            player8.Text = player7.Text
            player7.Text = player6.Text
            player6.Text = player5.Text
            player5.Text = player4.Text
            player4.Text = player3.Text
            player3.Text = player2.Text
            player2.Text = player.Text
            '
            score10.Text = score9.Text
            score9.Text = score8.Text
            score8.Text = score7.Text
            score7.Text = score6.Text
            score6.Text = score5.Text
            score5.Text = score4.Text
            score4.Text = score3.Text
            score3.Text = score2.Text
            score2.Text = score.Text
        End If
        If spotTaken = 3 Then
            player10.Text = player9.Text
            player9.Text = player8.Text
            player8.Text = player7.Text
            player7.Text = player6.Text
            player6.Text = player5.Text
            player5.Text = player4.Text
            player4.Text = player3.Text
            player3.Text = player.Text
            '
            score10.Text = score9.Text
            score9.Text = score8.Text
            score8.Text = score7.Text
            score7.Text = score6.Text
            score6.Text = score5.Text
            score5.Text = score4.Text
            score4.Text = score3.Text
            score3.Text = score.Text
        End If
        If spotTaken = 4 Then
            player10.Text = player9.Text
            player9.Text = player8.Text
            player8.Text = player7.Text
            player7.Text = player6.Text
            player6.Text = player5.Text
            player5.Text = player4.Text
            player4.Text = player.Text
            '
            score10.Text = score9.Text
            score9.Text = score8.Text
            score8.Text = score7.Text
            score7.Text = score6.Text
            score6.Text = score5.Text
            score5.Text = score4.Text
            score4.Text = score.Text
        End If
        If spotTaken = 5 Then
            player10.Text = player9.Text
            player9.Text = player8.Text
            player8.Text = player7.Text
            player7.Text = player6.Text
            player6.Text = player5.Text
            player5.Text = player.Text
            '
            score10.Text = score9.Text
            score9.Text = score8.Text
            score8.Text = score7.Text
            score7.Text = score6.Text
            score6.Text = score5.Text
            score5.Text = score.Text
        End If
        If spotTaken = 6 Then
            player10.Text = player9.Text
            player9.Text = player8.Text
            player8.Text = player7.Text
            player7.Text = player6.Text
            player6.Text = player.Text
            '
            score10.Text = score9.Text
            score9.Text = score8.Text
            score8.Text = score7.Text
            score7.Text = score6.Text
            score6.Text = score.Text
        End If
        If spotTaken = 7 Then
            player10.Text = player9.Text
            player9.Text = player8.Text
            player8.Text = player7.Text
            player7.Text = player.Text
            '
            score10.Text = score9.Text
            score9.Text = score8.Text
            score8.Text = score7.Text
            score7.Text = score.Text
        End If
        If spotTaken = 8 Then
            player10.Text = player9.Text
            player9.Text = player8.Text
            player8.Text = player.Text
            '
            score10.Text = score9.Text
            score9.Text = score8.Text
            score8.Text = score.Text
        End If
        If spotTaken = 9 Then
            player10.Text = player9.Text
            player9.Text = player.Text
            '
            score10.Text = score9.Text
            score9.Text = score.Text
        End If
        If spotTaken = 10 Then
            player10.Text = player.Text
            '
            score10.Text = score.Text
        End If
    End Sub

    Public Sub WriteScoreToFile()
        Try
            '
            If My.Computer.FileSystem.FileExists("NorbBJhs.dat") Then
                My.Computer.FileSystem.DeleteFile("NorbBJhs.dat")
            End If
            My.Computer.FileSystem.WriteAllText("NorbBJhs.dat", _
                                                player1.Text + ControlChars.NewLine + _
                                                score1.Text + ControlChars.NewLine + _
                                                player2.Text + ControlChars.NewLine + _
                                                score2.Text + ControlChars.NewLine + _
                                                player3.Text + ControlChars.NewLine + _
                                                score3.Text + ControlChars.NewLine + _
                                                player4.Text + ControlChars.NewLine + _
                                                score4.Text + ControlChars.NewLine + _
                                                player5.Text + ControlChars.NewLine + _
                                                score5.Text + ControlChars.NewLine + _
                                                player6.Text + ControlChars.NewLine + _
                                                score6.Text + ControlChars.NewLine + _
                                                player7.Text + ControlChars.NewLine + _
                                                score7.Text + ControlChars.NewLine + _
                                                player8.Text + ControlChars.NewLine + _
                                                score8.Text + ControlChars.NewLine + _
                                                player9.Text + ControlChars.NewLine + _
                                                score9.Text + ControlChars.NewLine + _
                                                player10.Text + ControlChars.NewLine + _
                                                score10.Text + ControlChars.NewLine, True)
            '
        Catch ex As Exception
            MsgBox("Não é possível atualizar a pontuação alta porque não pode escrever no arquivo. Tente executar como administrador ou que dão acesso ao programa.", 0, "Erro no Ficheiro")
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        UpdateScores(new_place)
        WriteScoreToFile()
        HighScores.Show()
        Close()
    End Sub
End Class