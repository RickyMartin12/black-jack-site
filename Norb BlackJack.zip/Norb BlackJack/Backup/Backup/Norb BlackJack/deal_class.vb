﻿Public Class deal_class
    '______________________________________________________________________
    '|####################################################################|
    '|####################################################################|
    '|############/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\############|
    '|############<             @@@    @@@   @@@@@            >###########|
    '|############<             @__@  @   @    @              >###########|
    '|############<             @  @  @   @    @              >###########|
    '|############<             @@@    @@@     @              >###########|
    '|############\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/############|
    '|############################\##########/############################|
    '|##############################\||||||/##############################|
    '----------------------------------------------------------------------

    Public Sub OpponentDealFirst()
        Dim RC As Integer
        Randomize()
        RC = 53 * Rnd()
        If RC = 1 Or RC = 14 Or RC = 27 Or RC = 40 Or RC = 53 Or RC = 0 Or RC = Form1.mem_op_card1.Text Or RC = Form1.mem_op_card2.Text Or RC = Form1.mem_op_card3.Text Or RC = Form1.mem_op_card4.Text Or RC = Form1.mem_op_card5.Text Or RC = Form1.mem_player_card1.Text Or RC = Form1.mem_player_card2.Text Or RC = Form1.mem_player_card3.Text Or RC = Form1.mem_player_card4.Text Or RC = Form1.mem_player_card5.Text Then
            OpponentDealFirst()
        Else
            Form1.op_card1.Visible = True
            Form1.op_score1.Visible = True
            If RC = 1 Then
                'CARD ID:1 = Ace of Hearths
                Form1.op_card1.Image = My.Resources.H1
                Form1.mem_op_card1.Text = 1
                Form1.op_score1.Text = 11
            End If
            If RC = 2 Then
                'CARD ID:2 = Two of Hearths
                Form1.op_card1.Image = My.Resources.H2
                Form1.mem_op_card1.Text = 2
                Form1.op_score1.Text = 2
            End If
            If RC = 3 Then
                'CARD ID:3 = Three of Hearths
                Form1.op_card1.Image = My.Resources.H3
                Form1.mem_op_card1.Text = 3
                Form1.op_score1.Text = 3
            End If
            If RC = 4 Then
                'CARD ID:4 = Four of Hearths
                Form1.op_card1.Image = My.Resources.H4
                Form1.mem_op_card1.Text = 4
                Form1.op_score1.Text = 4
            End If
            If RC = 5 Then
                'CARD ID:5 = Five of Hearths
                Form1.op_card1.Image = My.Resources.H5
                Form1.mem_op_card1.Text = 5
                Form1.op_score1.Text = 5
            End If
            If RC = 6 Then
                'CARD ID:6 = Six of Hearths
                Form1.op_card1.Image = My.Resources.H6
                Form1.mem_op_card1.Text = 6
                Form1.op_score1.Text = 6
            End If
            If RC = 7 Then
                'CARD ID:7 = Seven of Hearths
                Form1.op_card1.Image = My.Resources.H7
                Form1.mem_op_card1.Text = 7
                Form1.op_score1.Text = 7
            End If
            If RC = 8 Then
                'CARD ID:8 = Eight of Hearths
                Form1.op_card1.Image = My.Resources.H8
                Form1.mem_op_card1.Text = 8
                Form1.op_score1.Text = 8
            End If
            If RC = 9 Then
                'CARD ID:9 = Nine of Hearths
                Form1.op_card1.Image = My.Resources.H9
                Form1.mem_op_card1.Text = 9
                Form1.op_score1.Text = 9
            End If
            If RC = 10 Then
                'CARD ID:10 = Ten of Hearths
                Form1.op_card1.Image = My.Resources.H10
                Form1.mem_op_card1.Text = 10
                Form1.op_score1.Text = 10
            End If
            If RC = 11 Then
                'CARD ID:11 = Jack of Hearths
                Form1.op_card1.Image = My.Resources.H11
                Form1.mem_op_card1.Text = 11
                Form1.op_score1.Text = 10
            End If
            If RC = 12 Then
                'CARD ID:12 = Queen of Hearths
                Form1.op_card1.Image = My.Resources.H12
                Form1.mem_op_card1.Text = 12
                Form1.op_score1.Text = 10
            End If
            If RC = 13 Then
                'CARD ID:13 = King of Hearths
                Form1.op_card1.Image = My.Resources.H13
                Form1.mem_op_card1.Text = 13
                Form1.op_score1.Text = 10
            End If
            If RC = 14 Then
                'CARD ID:14 = Ace of Clubs
                Form1.op_card1.Image = My.Resources.C1
                Form1.mem_op_card1.Text = 14
                Form1.op_score1.Text = 11
            End If
            If RC = 15 Then
                'CARD ID:15 = Two of Clubs
                Form1.op_card1.Image = My.Resources.C2
                Form1.mem_op_card1.Text = 15
                Form1.op_score1.Text = 2
            End If
            If RC = 16 Then
                'CARD ID:16 = Three of Clubs
                Form1.op_card1.Image = My.Resources.C3
                Form1.mem_op_card1.Text = 16
                Form1.op_score1.Text = 3
            End If
            If RC = 17 Then
                'CARD ID:17 = Four of Clubs
                Form1.op_card1.Image = My.Resources.C4
                Form1.mem_op_card1.Text = 17
                Form1.op_score1.Text = 4
            End If
            If RC = 18 Then
                'CARD ID:18 = Five of Clubs
                Form1.op_card1.Image = My.Resources.C5
                Form1.mem_op_card1.Text = 18
                Form1.op_score1.Text = 5
            End If
            If RC = 19 Then
                'CARD ID:19 = Six of Clubs
                Form1.op_card1.Image = My.Resources.C6
                Form1.mem_op_card1.Text = 19
                Form1.op_score1.Text = 6
            End If
            If RC = 20 Then
                'CARD ID:20 = Seven of Clubs
                Form1.op_card1.Image = My.Resources.C7
                Form1.mem_op_card1.Text = 20
                Form1.op_score1.Text = 7
            End If
            If RC = 21 Then
                'CARD ID:21 = Eight of Clubs
                Form1.op_card1.Image = My.Resources.C8
                Form1.mem_op_card1.Text = 21
                Form1.op_score1.Text = 8
            End If
            If RC = 22 Then
                'CARD ID:22 = Nine of Clubs
                Form1.op_card1.Image = My.Resources.C9
                Form1.mem_op_card1.Text = 22
                Form1.op_score1.Text = 9
            End If
            If RC = 23 Then
                'CARD ID:23 = Ten of Clubs
                Form1.op_card1.Image = My.Resources.C10
                Form1.mem_op_card1.Text = 23
                Form1.op_score1.Text = 10
            End If
            If RC = 24 Then
                'CARD ID:24 = Jack of Clubs
                Form1.op_card1.Image = My.Resources.C11
                Form1.mem_op_card1.Text = 24
                Form1.op_score1.Text = 10
            End If
            If RC = 25 Then
                'CARD ID:25 = Queen of Clubs
                Form1.op_card1.Image = My.Resources.C12
                Form1.mem_op_card1.Text = 25
                Form1.op_score1.Text = 10
            End If
            If RC = 26 Then
                'CARD ID:26 = King of Clubs
                Form1.op_card1.Image = My.Resources.C13
                Form1.mem_op_card1.Text = 26
                Form1.op_score1.Text = 10
            End If
            If RC = 27 Then
                'CARD ID:27 = Ace of Diamonds
                Form1.op_card1.Image = My.Resources.D1
                Form1.mem_op_card1.Text = 27
                Form1.op_score1.Text = 11
            End If
            If RC = 28 Then
                'CARD ID:28 = Two of Diamonds
                Form1.op_card1.Image = My.Resources.D2
                Form1.mem_op_card1.Text = 28
                Form1.op_score1.Text = 2
            End If
            If RC = 29 Then
                'CARD ID:27 = Three of Diamonds
                Form1.op_card1.Image = My.Resources.D3
                Form1.mem_op_card1.Text = 29
                Form1.op_score1.Text = 3
            End If
            If RC = 30 Then
                'CARD ID:30 = Four of Diamonds
                Form1.op_card1.Image = My.Resources.D4
                Form1.mem_op_card1.Text = 30
                Form1.op_score1.Text = 4
            End If
            If RC = 31 Then
                'CARD ID:31 = Five of Diamonds
                Form1.op_card1.Image = My.Resources.D5
                Form1.mem_op_card1.Text = 31
                Form1.op_score1.Text = 5
            End If
            If RC = 32 Then
                'CARD ID:32 = Six of Diamonds
                Form1.op_card1.Image = My.Resources.D6
                Form1.mem_op_card1.Text = 32
                Form1.op_score1.Text = 6
            End If
            If RC = 33 Then
                'CARD ID:33 = Seven of Diamonds
                Form1.op_card1.Image = My.Resources.D7
                Form1.mem_op_card1.Text = 33
                Form1.op_score1.Text = 7
            End If
            If RC = 34 Then
                'CARD ID:34 = Eight of Diamonds
                Form1.op_card1.Image = My.Resources.D8
                Form1.mem_op_card1.Text = 34
                Form1.op_score1.Text = 8
            End If
            If RC = 35 Then
                'CARD ID:35 = Nine of Diamonds
                Form1.op_card1.Image = My.Resources.D9
                Form1.mem_op_card1.Text = 35
                Form1.op_score1.Text = 9
            End If
            If RC = 36 Then
                'CARD ID:36 = Ten of Diamonds
                Form1.op_card1.Image = My.Resources.D10
                Form1.mem_op_card1.Text = 36
                Form1.op_score1.Text = 10
            End If
            If RC = 37 Then
                'CARD ID:37 = Jack of Diamonds
                Form1.op_card1.Image = My.Resources.D11
                Form1.mem_op_card1.Text = 37
                Form1.op_score1.Text = 10
            End If
            If RC = 38 Then
                'CARD ID:38 = Queen of Diamonds
                Form1.op_card1.Image = My.Resources.D12
                Form1.mem_op_card1.Text = 38
                Form1.op_score1.Text = 10
            End If
            If RC = 39 Then
                'CARD ID:39 = King of Diamonds
                Form1.op_card1.Image = My.Resources.D13
                Form1.mem_op_card1.Text = 39
                Form1.op_score1.Text = 10
            End If
            If RC = 40 Then
                'CARD ID:40 = Ace of Spades
                Form1.op_card1.Image = My.Resources.S1
                Form1.mem_op_card1.Text = 40
                Form1.op_score1.Text = 11
            End If
            If RC = 41 Then
                'CARD ID:41 = Two of Spades
                Form1.op_card1.Image = My.Resources.S2
                Form1.mem_op_card1.Text = 41
                Form1.op_score1.Text = 2
            End If
            If RC = 42 Then
                'CARD ID:42 = Three of Spades
                Form1.op_card1.Image = My.Resources.S3
                Form1.mem_op_card1.Text = 42
                Form1.op_score1.Text = 3
            End If
            If RC = 43 Then
                'CARD ID:43 = Four of Spades
                Form1.op_card1.Image = My.Resources.S4
                Form1.mem_op_card1.Text = 43
                Form1.op_score1.Text = 4
            End If
            If RC = 44 Then
                'CARD ID:44 = Five of Spades
                Form1.op_card1.Image = My.Resources.S5
                Form1.mem_op_card1.Text = 44
                Form1.op_score1.Text = 5
            End If
            If RC = 45 Then
                'CARD ID:45 = Six of Spades
                Form1.op_card1.Image = My.Resources.S6
                Form1.mem_op_card1.Text = 45
                Form1.op_score1.Text = 6
            End If
            If RC = 46 Then
                'CARD ID:46 = Seven of Spades
                Form1.op_card1.Image = My.Resources.S7
                Form1.mem_op_card1.Text = 46
                Form1.op_score1.Text = 7
            End If
            If RC = 47 Then
                'CARD ID:47 = Eight of Spades
                Form1.op_card1.Image = My.Resources.S8
                Form1.mem_op_card1.Text = 47
                Form1.op_score1.Text = 8
            End If
            If RC = 48 Then
                'CARD ID:48 = Nine of Spades
                Form1.op_card1.Image = My.Resources.S9
                Form1.mem_op_card1.Text = 48
                Form1.op_score1.Text = 9
            End If
            If RC = 49 Then
                'CARD ID:49 = Ten of Spades
                Form1.op_card1.Image = My.Resources.S10
                Form1.mem_op_card1.Text = 49
                Form1.op_score1.Text = 10
            End If
            If RC = 50 Then
                'CARD ID:50 = Jack of Spades
                Form1.op_card1.Image = My.Resources.S11
                Form1.mem_op_card1.Text = 50
                Form1.op_score1.Text = 10
            End If
            If RC = 51 Then
                'CARD ID:51 = Queen of Spades
                Form1.op_card1.Image = My.Resources.S12
                Form1.mem_op_card1.Text = 51
                Form1.op_score1.Text = 10
            End If
            If RC = 52 Then
                'CARD ID:52 = King of Spades
                Form1.op_card1.Image = My.Resources.S13
                Form1.mem_op_card1.Text = 52
                Form1.op_score1.Text = 10
            End If
            Form1.UpdateScore()
        End If
    End Sub

    Public Sub OpponentDealSecond()
        Dim RC As Integer
        Randomize()
        RC = 53 * Rnd()
        If RC = 1 Or RC = 14 Or RC = 27 Or RC = 40 Or RC = 53 Or RC = 0 Or RC = Form1.mem_op_card1.Text Or RC = Form1.mem_op_card2.Text Or RC = Form1.mem_op_card3.Text Or RC = Form1.mem_op_card4.Text Or RC = Form1.mem_op_card5.Text Or RC = Form1.mem_player_card1.Text Or RC = Form1.mem_player_card2.Text Or RC = Form1.mem_player_card3.Text Or RC = Form1.mem_player_card4.Text Or RC = Form1.mem_player_card5.Text Then
            OpponentDealSecond()
        Else
            Form1.op_card2.Visible = True
            Form1.op_score2.Visible = True
            If RC = 1 Then
                'CARD ID:1 = Ace of Hearths
                Form1.op_card2.Image = My.Resources.H1
                Form1.mem_op_card2.Text = 1
                Form1.op_score2.Text = 11
            End If
            If RC = 2 Then
                'CARD ID:2 = Two of Hearths
                Form1.op_card2.Image = My.Resources.H2
                Form1.mem_op_card2.Text = 2
                Form1.op_score2.Text = 2
            End If
            If RC = 3 Then
                'CARD ID:3 = Three of Hearths
                Form1.op_card2.Image = My.Resources.H3
                Form1.mem_op_card2.Text = 3
                Form1.op_score2.Text = 3
            End If
            If RC = 4 Then
                'CARD ID:4 = Four of Hearths
                Form1.op_card2.Image = My.Resources.H4
                Form1.mem_op_card2.Text = 4
                Form1.op_score2.Text = 4
            End If
            If RC = 5 Then
                'CARD ID:5 = Five of Hearths
                Form1.op_card2.Image = My.Resources.H5
                Form1.mem_op_card2.Text = 5
                Form1.op_score2.Text = 5
            End If
            If RC = 6 Then
                'CARD ID:6 = Six of Hearths
                Form1.op_card2.Image = My.Resources.H6
                Form1.mem_op_card2.Text = 6
                Form1.op_score2.Text = 6
            End If
            If RC = 7 Then
                'CARD ID:7 = Seven of Hearths
                Form1.op_card2.Image = My.Resources.H7
                Form1.mem_op_card2.Text = 7
                Form1.op_score2.Text = 7
            End If
            If RC = 8 Then
                'CARD ID:8 = Eight of Hearths
                Form1.op_card2.Image = My.Resources.H8
                Form1.mem_op_card2.Text = 8
                Form1.op_score2.Text = 8
            End If
            If RC = 9 Then
                'CARD ID:9 = Nine of Hearths
                Form1.op_card2.Image = My.Resources.H9
                Form1.mem_op_card2.Text = 9
                Form1.op_score2.Text = 9
            End If
            If RC = 10 Then
                'CARD ID:10 = Ten of Hearths
                Form1.op_card2.Image = My.Resources.H10
                Form1.mem_op_card2.Text = 10
                Form1.op_score2.Text = 10
            End If
            If RC = 11 Then
                'CARD ID:11 = Jack of Hearths
                Form1.op_card2.Image = My.Resources.H11
                Form1.mem_op_card2.Text = 11
                Form1.op_score2.Text = 10
            End If
            If RC = 12 Then
                'CARD ID:12 = Queen of Hearths
                Form1.op_card2.Image = My.Resources.H12
                Form1.mem_op_card2.Text = 12
                Form1.op_score2.Text = 10
            End If
            If RC = 13 Then
                'CARD ID:13 = King of Hearths
                Form1.op_card2.Image = My.Resources.H13
                Form1.mem_op_card2.Text = 13
                Form1.op_score2.Text = 10
            End If
            If RC = 14 Then
                'CARD ID:14 = Ace of Clubs
                Form1.op_card2.Image = My.Resources.C1
                Form1.mem_op_card2.Text = 14
                Form1.op_score2.Text = 11
            End If
            If RC = 15 Then
                'CARD ID:15 = Two of Clubs
                Form1.op_card2.Image = My.Resources.C2
                Form1.mem_op_card2.Text = 15
                Form1.op_score2.Text = 2
            End If
            If RC = 16 Then
                'CARD ID:16 = Three of Clubs
                Form1.op_card2.Image = My.Resources.C3
                Form1.mem_op_card2.Text = 16
                Form1.op_score2.Text = 3
            End If
            If RC = 17 Then
                'CARD ID:17 = Four of Clubs
                Form1.op_card2.Image = My.Resources.C4
                Form1.mem_op_card2.Text = 17
                Form1.op_score2.Text = 4
            End If
            If RC = 18 Then
                'CARD ID:18 = Five of Clubs
                Form1.op_card2.Image = My.Resources.C5
                Form1.mem_op_card2.Text = 18
                Form1.op_score2.Text = 5
            End If
            If RC = 19 Then
                'CARD ID:19 = Six of Clubs
                Form1.op_card2.Image = My.Resources.C6
                Form1.mem_op_card2.Text = 19
                Form1.op_score2.Text = 6
            End If
            If RC = 20 Then
                'CARD ID:20 = Seven of Clubs
                Form1.op_card2.Image = My.Resources.C7
                Form1.mem_op_card2.Text = 20
                Form1.op_score2.Text = 7
            End If
            If RC = 21 Then
                'CARD ID:21 = Eight of Clubs
                Form1.op_card2.Image = My.Resources.C8
                Form1.mem_op_card2.Text = 21
                Form1.op_score2.Text = 8
            End If
            If RC = 22 Then
                'CARD ID:22 = Nine of Clubs
                Form1.op_card2.Image = My.Resources.C9
                Form1.mem_op_card2.Text = 22
                Form1.op_score2.Text = 9
            End If
            If RC = 23 Then
                'CARD ID:23 = Ten of Clubs
                Form1.op_card2.Image = My.Resources.C10
                Form1.mem_op_card2.Text = 23
                Form1.op_score2.Text = 10
            End If
            If RC = 24 Then
                'CARD ID:24 = Jack of Clubs
                Form1.op_card2.Image = My.Resources.C11
                Form1.mem_op_card2.Text = 24
                Form1.op_score2.Text = 10
            End If
            If RC = 25 Then
                'CARD ID:25 = Queen of Clubs
                Form1.op_card2.Image = My.Resources.C12
                Form1.mem_op_card2.Text = 25
                Form1.op_score2.Text = 10
            End If
            If RC = 26 Then
                'CARD ID:26 = King of Clubs
                Form1.op_card2.Image = My.Resources.C13
                Form1.mem_op_card2.Text = 26
                Form1.op_score2.Text = 10
            End If
            If RC = 27 Then
                'CARD ID:27 = Ace of Diamonds
                Form1.op_card2.Image = My.Resources.D1
                Form1.mem_op_card2.Text = 27
                Form1.op_score2.Text = 11
            End If
            If RC = 28 Then
                'CARD ID:28 = Two of Diamonds
                Form1.op_card2.Image = My.Resources.D2
                Form1.mem_op_card2.Text = 28
                Form1.op_score2.Text = 2
            End If
            If RC = 29 Then
                'CARD ID:27 = Three of Diamonds
                Form1.op_card2.Image = My.Resources.D3
                Form1.mem_op_card2.Text = 29
                Form1.op_score2.Text = 3
            End If
            If RC = 30 Then
                'CARD ID:30 = Four of Diamonds
                Form1.op_card2.Image = My.Resources.D4
                Form1.mem_op_card2.Text = 30
                Form1.op_score2.Text = 4
            End If
            If RC = 31 Then
                'CARD ID:31 = Five of Diamonds
                Form1.op_card2.Image = My.Resources.D5
                Form1.mem_op_card2.Text = 31
                Form1.op_score2.Text = 5
            End If
            If RC = 32 Then
                'CARD ID:32 = Six of Diamonds
                Form1.op_card2.Image = My.Resources.D6
                Form1.mem_op_card2.Text = 32
                Form1.op_score2.Text = 6
            End If
            If RC = 33 Then
                'CARD ID:33 = Seven of Diamonds
                Form1.op_card2.Image = My.Resources.D7
                Form1.mem_op_card2.Text = 33
                Form1.op_score2.Text = 7
            End If
            If RC = 34 Then
                'CARD ID:34 = Eight of Diamonds
                Form1.op_card2.Image = My.Resources.D8
                Form1.mem_op_card2.Text = 34
                Form1.op_score2.Text = 8
            End If
            If RC = 35 Then
                'CARD ID:35 = Nine of Diamonds
                Form1.op_card2.Image = My.Resources.D9
                Form1.mem_op_card2.Text = 35
                Form1.op_score2.Text = 9
            End If
            If RC = 36 Then
                'CARD ID:36 = Ten of Diamonds
                Form1.op_card2.Image = My.Resources.D10
                Form1.mem_op_card2.Text = 36
                Form1.op_score2.Text = 10
            End If
            If RC = 37 Then
                'CARD ID:37 = Jack of Diamonds
                Form1.op_card2.Image = My.Resources.D11
                Form1.mem_op_card2.Text = 37
                Form1.op_score2.Text = 10
            End If
            If RC = 38 Then
                'CARD ID:38 = Queen of Diamonds
                Form1.op_card2.Image = My.Resources.D12
                Form1.mem_op_card2.Text = 38
                Form1.op_score2.Text = 10
            End If
            If RC = 39 Then
                'CARD ID:39 = King of Diamonds
                Form1.op_card2.Image = My.Resources.D13
                Form1.mem_op_card2.Text = 39
                Form1.op_score2.Text = 10
            End If
            If RC = 40 Then
                'CARD ID:40 = Ace of Spades
                Form1.op_card2.Image = My.Resources.S1
                Form1.mem_op_card2.Text = 40
                Form1.op_score2.Text = 11
            End If
            If RC = 41 Then
                'CARD ID:41 = Two of Spades
                Form1.op_card2.Image = My.Resources.S2
                Form1.mem_op_card2.Text = 41
                Form1.op_score2.Text = 2
            End If
            If RC = 42 Then
                'CARD ID:42 = Three of Spades
                Form1.op_card2.Image = My.Resources.S3
                Form1.mem_op_card2.Text = 42
                Form1.op_score2.Text = 3
            End If
            If RC = 43 Then
                'CARD ID:43 = Four of Spades
                Form1.op_card2.Image = My.Resources.S4
                Form1.mem_op_card2.Text = 43
                Form1.op_score2.Text = 4
            End If
            If RC = 44 Then
                'CARD ID:44 = Five of Spades
                Form1.op_card2.Image = My.Resources.S5
                Form1.mem_op_card2.Text = 44
                Form1.op_score2.Text = 5
            End If
            If RC = 45 Then
                'CARD ID:45 = Six of Spades
                Form1.op_card2.Image = My.Resources.S6
                Form1.mem_op_card2.Text = 45
                Form1.op_score2.Text = 6
            End If
            If RC = 46 Then
                'CARD ID:46 = Seven of Spades
                Form1.op_card2.Image = My.Resources.S7
                Form1.mem_op_card2.Text = 46
                Form1.op_score2.Text = 7
            End If
            If RC = 47 Then
                'CARD ID:47 = Eight of Spades
                Form1.op_card2.Image = My.Resources.S8
                Form1.mem_op_card2.Text = 47
                Form1.op_score2.Text = 8
            End If
            If RC = 48 Then
                'CARD ID:48 = Nine of Spades
                Form1.op_card2.Image = My.Resources.S9
                Form1.mem_op_card2.Text = 48
                Form1.op_score2.Text = 9
            End If
            If RC = 49 Then
                'CARD ID:49 = Ten of Spades
                Form1.op_card2.Image = My.Resources.S10
                Form1.mem_op_card2.Text = 49
                Form1.op_score2.Text = 10
            End If
            If RC = 50 Then
                'CARD ID:50 = Jack of Spades
                Form1.op_card2.Image = My.Resources.S11
                Form1.mem_op_card2.Text = 50
                Form1.op_score2.Text = 10
            End If
            If RC = 51 Then
                'CARD ID:51 = Queen of Spades
                Form1.op_card2.Image = My.Resources.S12
                Form1.mem_op_card2.Text = 51
                Form1.op_score2.Text = 10
            End If
            If RC = 52 Then
                'CARD ID:52 = King of Spades
                Form1.op_card2.Image = My.Resources.S13
                Form1.mem_op_card2.Text = 52
                Form1.op_score2.Text = 10
            End If
            Form1.UpdateScore()
        End If
    End Sub

    Public Sub OpponentDealThird()
        Dim RC As Integer
        Randomize()
        RC = 53 * Rnd()
        If RC = 1 Or RC = 14 Or RC = 27 Or RC = 40 Or RC = 53 Or RC = 0 Or RC = Form1.mem_op_card1.Text Or RC = Form1.mem_op_card2.Text Or RC = Form1.mem_op_card3.Text Or RC = Form1.mem_op_card4.Text Or RC = Form1.mem_op_card5.Text Or RC = Form1.mem_player_card1.Text Or RC = Form1.mem_player_card2.Text Or RC = Form1.mem_player_card3.Text Or RC = Form1.mem_player_card4.Text Or RC = Form1.mem_player_card5.Text Then
            OpponentDealThird()
        Else
            Form1.op_card3.Visible = True
            Form1.op_score3.Visible = True
            If RC = 1 Then
                'CARD ID:1 = Ace of Hearths
                Form1.op_card3.Image = My.Resources.H1
                Form1.mem_op_card3.Text = 1
                Form1.op_score3.Text = 11
            End If
            If RC = 2 Then
                'CARD ID:2 = Two of Hearths
                Form1.op_card3.Image = My.Resources.H2
                Form1.mem_op_card3.Text = 2
                Form1.op_score3.Text = 2
            End If
            If RC = 3 Then
                'CARD ID:3 = Three of Hearths
                Form1.op_card3.Image = My.Resources.H3
                Form1.mem_op_card3.Text = 3
                Form1.op_score3.Text = 3
            End If
            If RC = 4 Then
                'CARD ID:4 = Four of Hearths
                Form1.op_card3.Image = My.Resources.H4
                Form1.mem_op_card3.Text = 4
                Form1.op_score3.Text = 4
            End If
            If RC = 5 Then
                'CARD ID:5 = Five of Hearths
                Form1.op_card3.Image = My.Resources.H5
                Form1.mem_op_card3.Text = 5
                Form1.op_score3.Text = 5
            End If
            If RC = 6 Then
                'CARD ID:6 = Six of Hearths
                Form1.op_card3.Image = My.Resources.H6
                Form1.mem_op_card3.Text = 6
                Form1.op_score3.Text = 6
            End If
            If RC = 7 Then
                'CARD ID:7 = Seven of Hearths
                Form1.op_card3.Image = My.Resources.H7
                Form1.mem_op_card3.Text = 7
                Form1.op_score3.Text = 7
            End If
            If RC = 8 Then
                'CARD ID:8 = Eight of Hearths
                Form1.op_card3.Image = My.Resources.H8
                Form1.mem_op_card3.Text = 8
                Form1.op_score3.Text = 8
            End If
            If RC = 9 Then
                'CARD ID:9 = Nine of Hearths
                Form1.op_card3.Image = My.Resources.H9
                Form1.mem_op_card3.Text = 9
                Form1.op_score3.Text = 9
            End If
            If RC = 10 Then
                'CARD ID:10 = Ten of Hearths
                Form1.op_card3.Image = My.Resources.H10
                Form1.mem_op_card3.Text = 10
                Form1.op_score3.Text = 10
            End If
            If RC = 11 Then
                'CARD ID:11 = Jack of Hearths
                Form1.op_card3.Image = My.Resources.H11
                Form1.mem_op_card3.Text = 11
                Form1.op_score3.Text = 10
            End If
            If RC = 12 Then
                'CARD ID:12 = Queen of Hearths
                Form1.op_card3.Image = My.Resources.H12
                Form1.mem_op_card3.Text = 12
                Form1.op_score3.Text = 10
            End If
            If RC = 13 Then
                'CARD ID:13 = King of Hearths
                Form1.op_card3.Image = My.Resources.H13
                Form1.mem_op_card3.Text = 13
                Form1.op_score3.Text = 10
            End If
            If RC = 14 Then
                'CARD ID:14 = Ace of Clubs
                Form1.op_card3.Image = My.Resources.C1
                Form1.mem_op_card3.Text = 14
                Form1.op_score3.Text = 11
            End If
            If RC = 15 Then
                'CARD ID:15 = Two of Clubs
                Form1.op_card3.Image = My.Resources.C2
                Form1.mem_op_card3.Text = 15
                Form1.op_score3.Text = 2
            End If
            If RC = 16 Then
                'CARD ID:16 = Three of Clubs
                Form1.op_card3.Image = My.Resources.C3
                Form1.mem_op_card3.Text = 16
                Form1.op_score3.Text = 3
            End If
            If RC = 17 Then
                'CARD ID:17 = Four of Clubs
                Form1.op_card3.Image = My.Resources.C4
                Form1.mem_op_card3.Text = 17
                Form1.op_score3.Text = 4
            End If
            If RC = 18 Then
                'CARD ID:18 = Five of Clubs
                Form1.op_card3.Image = My.Resources.C5
                Form1.mem_op_card3.Text = 18
                Form1.op_score3.Text = 5
            End If
            If RC = 19 Then
                'CARD ID:19 = Six of Clubs
                Form1.op_card3.Image = My.Resources.C6
                Form1.mem_op_card3.Text = 19
                Form1.op_score3.Text = 6
            End If
            If RC = 20 Then
                'CARD ID:20 = Seven of Clubs
                Form1.op_card3.Image = My.Resources.C7
                Form1.mem_op_card3.Text = 20
                Form1.op_score3.Text = 7
            End If
            If RC = 21 Then
                'CARD ID:21 = Eight of Clubs
                Form1.op_card3.Image = My.Resources.C8
                Form1.mem_op_card3.Text = 21
                Form1.op_score3.Text = 8
            End If
            If RC = 22 Then
                'CARD ID:22 = Nine of Clubs
                Form1.op_card3.Image = My.Resources.C9
                Form1.mem_op_card3.Text = 22
                Form1.op_score3.Text = 9
            End If
            If RC = 23 Then
                'CARD ID:23 = Ten of Clubs
                Form1.op_card3.Image = My.Resources.C10
                Form1.mem_op_card3.Text = 23
                Form1.op_score3.Text = 10
            End If
            If RC = 24 Then
                'CARD ID:24 = Jack of Clubs
                Form1.op_card3.Image = My.Resources.C11
                Form1.mem_op_card3.Text = 24
                Form1.op_score3.Text = 10
            End If
            If RC = 25 Then
                'CARD ID:25 = Queen of Clubs
                Form1.op_card3.Image = My.Resources.C12
                Form1.mem_op_card3.Text = 25
                Form1.op_score3.Text = 10
            End If
            If RC = 26 Then
                'CARD ID:26 = King of Clubs
                Form1.op_card3.Image = My.Resources.C13
                Form1.mem_op_card3.Text = 26
                Form1.op_score3.Text = 10
            End If
            If RC = 27 Then
                'CARD ID:27 = Ace of Diamonds
                Form1.op_card3.Image = My.Resources.D1
                Form1.mem_op_card3.Text = 27
                Form1.op_score3.Text = 11
            End If
            If RC = 28 Then
                'CARD ID:28 = Two of Diamonds
                Form1.op_card3.Image = My.Resources.D2
                Form1.mem_op_card3.Text = 28
                Form1.op_score3.Text = 2
            End If
            If RC = 29 Then
                'CARD ID:27 = Three of Diamonds
                Form1.op_card3.Image = My.Resources.D3
                Form1.mem_op_card3.Text = 29
                Form1.op_score3.Text = 3
            End If
            If RC = 30 Then
                'CARD ID:30 = Four of Diamonds
                Form1.op_card3.Image = My.Resources.D4
                Form1.mem_op_card3.Text = 30
                Form1.op_score3.Text = 4
            End If
            If RC = 31 Then
                'CARD ID:31 = Five of Diamonds
                Form1.op_card3.Image = My.Resources.D5
                Form1.mem_op_card3.Text = 31
                Form1.op_score3.Text = 5
            End If
            If RC = 32 Then
                'CARD ID:32 = Six of Diamonds
                Form1.op_card3.Image = My.Resources.D6
                Form1.mem_op_card3.Text = 32
                Form1.op_score3.Text = 6
            End If
            If RC = 33 Then
                'CARD ID:33 = Seven of Diamonds
                Form1.op_card3.Image = My.Resources.D7
                Form1.mem_op_card3.Text = 33
                Form1.op_score3.Text = 7
            End If
            If RC = 34 Then
                'CARD ID:34 = Eight of Diamonds
                Form1.op_card3.Image = My.Resources.D8
                Form1.mem_op_card3.Text = 34
                Form1.op_score3.Text = 8
            End If
            If RC = 35 Then
                'CARD ID:35 = Nine of Diamonds
                Form1.op_card3.Image = My.Resources.D9
                Form1.mem_op_card3.Text = 35
                Form1.op_score3.Text = 9
            End If
            If RC = 36 Then
                'CARD ID:36 = Ten of Diamonds
                Form1.op_card3.Image = My.Resources.D10
                Form1.mem_op_card3.Text = 36
                Form1.op_score3.Text = 10
            End If
            If RC = 37 Then
                'CARD ID:37 = Jack of Diamonds
                Form1.op_card3.Image = My.Resources.D11
                Form1.mem_op_card3.Text = 37
                Form1.op_score3.Text = 10
            End If
            If RC = 38 Then
                'CARD ID:38 = Queen of Diamonds
                Form1.op_card3.Image = My.Resources.D12
                Form1.mem_op_card3.Text = 38
                Form1.op_score3.Text = 10
            End If
            If RC = 39 Then
                'CARD ID:39 = King of Diamonds
                Form1.op_card3.Image = My.Resources.D13
                Form1.mem_op_card3.Text = 39
                Form1.op_score3.Text = 10
            End If
            If RC = 40 Then
                'CARD ID:40 = Ace of Spades
                Form1.op_card3.Image = My.Resources.S1
                Form1.mem_op_card3.Text = 40
                Form1.op_score3.Text = 11
            End If
            If RC = 41 Then
                'CARD ID:41 = Two of Spades
                Form1.op_card3.Image = My.Resources.S2
                Form1.mem_op_card3.Text = 41
                Form1.op_score3.Text = 2
            End If
            If RC = 42 Then
                'CARD ID:42 = Three of Spades
                Form1.op_card3.Image = My.Resources.S3
                Form1.mem_op_card3.Text = 42
                Form1.op_score3.Text = 3
            End If
            If RC = 43 Then
                'CARD ID:43 = Four of Spades
                Form1.op_card3.Image = My.Resources.S4
                Form1.mem_op_card3.Text = 43
                Form1.op_score3.Text = 4
            End If
            If RC = 44 Then
                'CARD ID:44 = Five of Spades
                Form1.op_card3.Image = My.Resources.S5
                Form1.mem_op_card3.Text = 44
                Form1.op_score3.Text = 5
            End If
            If RC = 45 Then
                'CARD ID:45 = Six of Spades
                Form1.op_card3.Image = My.Resources.S6
                Form1.mem_op_card3.Text = 45
                Form1.op_score3.Text = 6
            End If
            If RC = 46 Then
                'CARD ID:46 = Seven of Spades
                Form1.op_card3.Image = My.Resources.S7
                Form1.mem_op_card3.Text = 46
                Form1.op_score3.Text = 7
            End If
            If RC = 47 Then
                'CARD ID:47 = Eight of Spades
                Form1.op_card3.Image = My.Resources.S8
                Form1.mem_op_card3.Text = 47
                Form1.op_score3.Text = 8
            End If
            If RC = 48 Then
                'CARD ID:48 = Nine of Spades
                Form1.op_card3.Image = My.Resources.S9
                Form1.mem_op_card3.Text = 48
                Form1.op_score3.Text = 9
            End If
            If RC = 49 Then
                'CARD ID:49 = Ten of Spades
                Form1.op_card3.Image = My.Resources.S10
                Form1.mem_op_card3.Text = 49
                Form1.op_score3.Text = 10
            End If
            If RC = 50 Then
                'CARD ID:50 = Jack of Spades
                Form1.op_card3.Image = My.Resources.S11
                Form1.mem_op_card3.Text = 50
                Form1.op_score3.Text = 10
            End If
            If RC = 51 Then
                'CARD ID:51 = Queen of Spades
                Form1.op_card3.Image = My.Resources.S12
                Form1.mem_op_card3.Text = 51
                Form1.op_score3.Text = 10
            End If
            If RC = 52 Then
                'CARD ID:52 = King of Spades
                Form1.op_card3.Image = My.Resources.S13
                Form1.mem_op_card3.Text = 52
                Form1.op_score3.Text = 10
            End If
            Form1.UpdateScore()
        End If
    End Sub

    Public Sub OpponentDealFourth()
        Dim RC As Integer
        Randomize()
        RC = 53 * Rnd()
        If RC = 1 Or RC = 14 Or RC = 27 Or RC = 40 Or RC = 53 Or RC = 0 Or RC = Form1.mem_op_card1.Text Or RC = Form1.mem_op_card2.Text Or RC = Form1.mem_op_card3.Text Or RC = Form1.mem_op_card4.Text Or RC = Form1.mem_op_card5.Text Or RC = Form1.mem_player_card1.Text Or RC = Form1.mem_player_card2.Text Or RC = Form1.mem_player_card3.Text Or RC = Form1.mem_player_card4.Text Or RC = Form1.mem_player_card5.Text Then
            OpponentDealFourth()
        Else
            Form1.op_card4.Visible = True
            Form1.op_score4.Visible = True
            If RC = 1 Then
                'CARD ID:1 = Ace of Hearths
                Form1.op_card4.Image = My.Resources.H1
                Form1.mem_op_card4.Text = 1
                Form1.op_score4.Text = 11
            End If
            If RC = 2 Then
                'CARD ID:2 = Two of Hearths
                Form1.op_card4.Image = My.Resources.H2
                Form1.mem_op_card4.Text = 2
                Form1.op_score4.Text = 2
            End If
            If RC = 3 Then
                'CARD ID:3 = Three of Hearths
                Form1.op_card4.Image = My.Resources.H3
                Form1.mem_op_card4.Text = 3
                Form1.op_score4.Text = 3
            End If
            If RC = 4 Then
                'CARD ID:4 = Four of Hearths
                Form1.op_card4.Image = My.Resources.H4
                Form1.mem_op_card4.Text = 4
                Form1.op_score4.Text = 4
            End If
            If RC = 5 Then
                'CARD ID:5 = Five of Hearths
                Form1.op_card4.Image = My.Resources.H5
                Form1.mem_op_card4.Text = 5
                Form1.op_score4.Text = 5
            End If
            If RC = 6 Then
                'CARD ID:6 = Six of Hearths
                Form1.op_card4.Image = My.Resources.H6
                Form1.mem_op_card4.Text = 6
                Form1.op_score4.Text = 6
            End If
            If RC = 7 Then
                'CARD ID:7 = Seven of Hearths
                Form1.op_card4.Image = My.Resources.H7
                Form1.mem_op_card4.Text = 7
                Form1.op_score4.Text = 7
            End If
            If RC = 8 Then
                'CARD ID:8 = Eight of Hearths
                Form1.op_card4.Image = My.Resources.H8
                Form1.mem_op_card4.Text = 8
                Form1.op_score4.Text = 8
            End If
            If RC = 9 Then
                'CARD ID:9 = Nine of Hearths
                Form1.op_card4.Image = My.Resources.H9
                Form1.mem_op_card4.Text = 9
                Form1.op_score4.Text = 9
            End If
            If RC = 10 Then
                'CARD ID:10 = Ten of Hearths
                Form1.op_card4.Image = My.Resources.H10
                Form1.mem_op_card4.Text = 10
                Form1.op_score4.Text = 10
            End If
            If RC = 11 Then
                'CARD ID:11 = Jack of Hearths
                Form1.op_card4.Image = My.Resources.H11
                Form1.mem_op_card4.Text = 11
                Form1.op_score4.Text = 10
            End If
            If RC = 12 Then
                'CARD ID:12 = Queen of Hearths
                Form1.op_card4.Image = My.Resources.H12
                Form1.mem_op_card4.Text = 12
                Form1.op_score4.Text = 10
            End If
            If RC = 13 Then
                'CARD ID:13 = King of Hearths
                Form1.op_card4.Image = My.Resources.H13
                Form1.mem_op_card4.Text = 13
                Form1.op_score4.Text = 10
            End If
            If RC = 14 Then
                'CARD ID:14 = Ace of Clubs
                Form1.op_card4.Image = My.Resources.C1
                Form1.mem_op_card4.Text = 14
                Form1.op_score4.Text = 11
            End If
            If RC = 15 Then
                'CARD ID:15 = Two of Clubs
                Form1.op_card4.Image = My.Resources.C2
                Form1.mem_op_card4.Text = 15
                Form1.op_score4.Text = 2
            End If
            If RC = 16 Then
                'CARD ID:16 = Three of Clubs
                Form1.op_card4.Image = My.Resources.C3
                Form1.mem_op_card4.Text = 16
                Form1.op_score4.Text = 3
            End If
            If RC = 17 Then
                'CARD ID:17 = Four of Clubs
                Form1.op_card4.Image = My.Resources.C4
                Form1.mem_op_card4.Text = 17
                Form1.op_score4.Text = 4
            End If
            If RC = 18 Then
                'CARD ID:18 = Five of Clubs
                Form1.op_card4.Image = My.Resources.C5
                Form1.mem_op_card4.Text = 18
                Form1.op_score4.Text = 5
            End If
            If RC = 19 Then
                'CARD ID:19 = Six of Clubs
                Form1.op_card4.Image = My.Resources.C6
                Form1.mem_op_card4.Text = 19
                Form1.op_score4.Text = 6
            End If
            If RC = 20 Then
                'CARD ID:20 = Seven of Clubs
                Form1.op_card4.Image = My.Resources.C7
                Form1.mem_op_card4.Text = 20
                Form1.op_score4.Text = 7
            End If
            If RC = 21 Then
                'CARD ID:21 = Eight of Clubs
                Form1.op_card4.Image = My.Resources.C8
                Form1.mem_op_card4.Text = 21
                Form1.op_score4.Text = 8
            End If
            If RC = 22 Then
                'CARD ID:22 = Nine of Clubs
                Form1.op_card4.Image = My.Resources.C9
                Form1.mem_op_card4.Text = 22
                Form1.op_score4.Text = 9
            End If
            If RC = 23 Then
                'CARD ID:23 = Ten of Clubs
                Form1.op_card4.Image = My.Resources.C10
                Form1.mem_op_card4.Text = 23
                Form1.op_score4.Text = 10
            End If
            If RC = 24 Then
                'CARD ID:24 = Jack of Clubs
                Form1.op_card4.Image = My.Resources.C11
                Form1.mem_op_card4.Text = 24
                Form1.op_score4.Text = 10
            End If
            If RC = 25 Then
                'CARD ID:25 = Queen of Clubs
                Form1.op_card4.Image = My.Resources.C12
                Form1.mem_op_card4.Text = 25
                Form1.op_score4.Text = 10
            End If
            If RC = 26 Then
                'CARD ID:26 = King of Clubs
                Form1.op_card4.Image = My.Resources.C13
                Form1.mem_op_card4.Text = 26
                Form1.op_score4.Text = 10
            End If
            If RC = 27 Then
                'CARD ID:27 = Ace of Diamonds
                Form1.op_card4.Image = My.Resources.D1
                Form1.mem_op_card4.Text = 27
                Form1.op_score4.Text = 11
            End If
            If RC = 28 Then
                'CARD ID:28 = Two of Diamonds
                Form1.op_card4.Image = My.Resources.D2
                Form1.mem_op_card4.Text = 28
                Form1.op_score4.Text = 2
            End If
            If RC = 29 Then
                'CARD ID:27 = Three of Diamonds
                Form1.op_card4.Image = My.Resources.D3
                Form1.mem_op_card4.Text = 29
                Form1.op_score4.Text = 3
            End If
            If RC = 30 Then
                'CARD ID:30 = Four of Diamonds
                Form1.op_card4.Image = My.Resources.D4
                Form1.mem_op_card4.Text = 30
                Form1.op_score4.Text = 4
            End If
            If RC = 31 Then
                'CARD ID:31 = Five of Diamonds
                Form1.op_card4.Image = My.Resources.D5
                Form1.mem_op_card4.Text = 31
                Form1.op_score4.Text = 5
            End If
            If RC = 32 Then
                'CARD ID:32 = Six of Diamonds
                Form1.op_card4.Image = My.Resources.D6
                Form1.mem_op_card4.Text = 32
                Form1.op_score4.Text = 6
            End If
            If RC = 33 Then
                'CARD ID:33 = Seven of Diamonds
                Form1.op_card4.Image = My.Resources.D7
                Form1.mem_op_card4.Text = 33
                Form1.op_score4.Text = 7
            End If
            If RC = 34 Then
                'CARD ID:34 = Eight of Diamonds
                Form1.op_card4.Image = My.Resources.D8
                Form1.mem_op_card4.Text = 34
                Form1.op_score4.Text = 8
            End If
            If RC = 35 Then
                'CARD ID:35 = Nine of Diamonds
                Form1.op_card4.Image = My.Resources.D9
                Form1.mem_op_card4.Text = 35
                Form1.op_score4.Text = 9
            End If
            If RC = 36 Then
                'CARD ID:36 = Ten of Diamonds
                Form1.op_card4.Image = My.Resources.D10
                Form1.mem_op_card4.Text = 36
                Form1.op_score4.Text = 10
            End If
            If RC = 37 Then
                'CARD ID:37 = Jack of Diamonds
                Form1.op_card4.Image = My.Resources.D11
                Form1.mem_op_card4.Text = 37
                Form1.op_score4.Text = 10
            End If
            If RC = 38 Then
                'CARD ID:38 = Queen of Diamonds
                Form1.op_card4.Image = My.Resources.D12
                Form1.mem_op_card4.Text = 38
                Form1.op_score4.Text = 10
            End If
            If RC = 39 Then
                'CARD ID:39 = King of Diamonds
                Form1.op_card4.Image = My.Resources.D13
                Form1.mem_op_card4.Text = 39
                Form1.op_score4.Text = 10
            End If
            If RC = 40 Then
                'CARD ID:40 = Ace of Spades
                Form1.op_card4.Image = My.Resources.S1
                Form1.mem_op_card4.Text = 40
                Form1.op_score4.Text = 11
            End If
            If RC = 41 Then
                'CARD ID:41 = Two of Spades
                Form1.op_card4.Image = My.Resources.S2
                Form1.mem_op_card4.Text = 41
                Form1.op_score4.Text = 2
            End If
            If RC = 42 Then
                'CARD ID:42 = Three of Spades
                Form1.op_card4.Image = My.Resources.S3
                Form1.mem_op_card4.Text = 42
                Form1.op_score4.Text = 3
            End If
            If RC = 43 Then
                'CARD ID:43 = Four of Spades
                Form1.op_card4.Image = My.Resources.S4
                Form1.mem_op_card4.Text = 43
                Form1.op_score4.Text = 4
            End If
            If RC = 44 Then
                'CARD ID:44 = Five of Spades
                Form1.op_card4.Image = My.Resources.S5
                Form1.mem_op_card4.Text = 44
                Form1.op_score4.Text = 5
            End If
            If RC = 45 Then
                'CARD ID:45 = Six of Spades
                Form1.op_card4.Image = My.Resources.S6
                Form1.mem_op_card4.Text = 45
                Form1.op_score4.Text = 6
            End If
            If RC = 46 Then
                'CARD ID:46 = Seven of Spades
                Form1.op_card4.Image = My.Resources.S7
                Form1.mem_op_card4.Text = 46
                Form1.op_score4.Text = 7
            End If
            If RC = 47 Then
                'CARD ID:47 = Eight of Spades
                Form1.op_card4.Image = My.Resources.S8
                Form1.mem_op_card4.Text = 47
                Form1.op_score4.Text = 8
            End If
            If RC = 48 Then
                'CARD ID:48 = Nine of Spades
                Form1.op_card4.Image = My.Resources.S9
                Form1.mem_op_card4.Text = 48
                Form1.op_score4.Text = 9
            End If
            If RC = 49 Then
                'CARD ID:49 = Ten of Spades
                Form1.op_card4.Image = My.Resources.S10
                Form1.mem_op_card4.Text = 49
                Form1.op_score4.Text = 10
            End If
            If RC = 50 Then
                'CARD ID:50 = Jack of Spades
                Form1.op_card4.Image = My.Resources.S11
                Form1.mem_op_card4.Text = 50
                Form1.op_score4.Text = 10
            End If
            If RC = 51 Then
                'CARD ID:51 = Queen of Spades
                Form1.op_card4.Image = My.Resources.S12
                Form1.mem_op_card4.Text = 51
                Form1.op_score4.Text = 10
            End If
            If RC = 52 Then
                'CARD ID:52 = King of Spades
                Form1.op_card4.Image = My.Resources.S13
                Form1.mem_op_card4.Text = 52
                Form1.op_score4.Text = 10
            End If
            Form1.UpdateScore()
        End If
    End Sub

    Public Sub OpponentDealFifth()
        Dim RC As Integer
        Randomize()
        RC = 53 * Rnd()
        If RC = 1 Or RC = 14 Or RC = 27 Or RC = 40 Or RC = 53 Or RC = 0 Or RC = Form1.mem_op_card1.Text Or RC = Form1.mem_op_card2.Text Or RC = Form1.mem_op_card3.Text Or RC = Form1.mem_op_card4.Text Or RC = Form1.mem_op_card5.Text Or RC = Form1.mem_player_card1.Text Or RC = Form1.mem_player_card2.Text Or RC = Form1.mem_player_card3.Text Or RC = Form1.mem_player_card4.Text Or RC = Form1.mem_player_card5.Text Then
            OpponentDealFifth()
        Else
            Form1.op_card5.Visible = True
            Form1.op_score5.Visible = True
            If RC = 1 Then
                'CARD ID:1 = Ace of Hearths
                Form1.op_card5.Image = My.Resources.H1
                Form1.mem_op_card5.Text = 1
                Form1.op_score5.Text = 11
            End If
            If RC = 2 Then
                'CARD ID:2 = Two of Hearths
                Form1.op_card5.Image = My.Resources.H2
                Form1.mem_op_card5.Text = 2
                Form1.op_score5.Text = 2
            End If
            If RC = 3 Then
                'CARD ID:3 = Three of Hearths
                Form1.op_card5.Image = My.Resources.H3
                Form1.mem_op_card5.Text = 3
                Form1.op_score5.Text = 3
            End If
            If RC = 4 Then
                'CARD ID:4 = Four of Hearths
                Form1.op_card5.Image = My.Resources.H4
                Form1.mem_op_card5.Text = 4
                Form1.op_score5.Text = 4
            End If
            If RC = 5 Then
                'CARD ID:5 = Five of Hearths
                Form1.op_card5.Image = My.Resources.H5
                Form1.mem_op_card5.Text = 5
                Form1.op_score5.Text = 5
            End If
            If RC = 6 Then
                'CARD ID:6 = Six of Hearths
                Form1.op_card5.Image = My.Resources.H6
                Form1.mem_op_card5.Text = 6
                Form1.op_score5.Text = 6
            End If
            If RC = 7 Then
                'CARD ID:7 = Seven of Hearths
                Form1.op_card5.Image = My.Resources.H7
                Form1.mem_op_card5.Text = 7
                Form1.op_score5.Text = 7
            End If
            If RC = 8 Then
                'CARD ID:8 = Eight of Hearths
                Form1.op_card5.Image = My.Resources.H8
                Form1.mem_op_card5.Text = 8
                Form1.op_score5.Text = 8
            End If
            If RC = 9 Then
                'CARD ID:9 = Nine of Hearths
                Form1.op_card5.Image = My.Resources.H9
                Form1.mem_op_card5.Text = 9
                Form1.op_score5.Text = 9
            End If
            If RC = 10 Then
                'CARD ID:10 = Ten of Hearths
                Form1.op_card5.Image = My.Resources.H10
                Form1.mem_op_card5.Text = 10
                Form1.op_score5.Text = 10
            End If
            If RC = 11 Then
                'CARD ID:11 = Jack of Hearths
                Form1.op_card5.Image = My.Resources.H11
                Form1.mem_op_card5.Text = 11
                Form1.op_score5.Text = 10
            End If
            If RC = 12 Then
                'CARD ID:12 = Queen of Hearths
                Form1.op_card5.Image = My.Resources.H12
                Form1.mem_op_card5.Text = 12
                Form1.op_score5.Text = 10
            End If
            If RC = 13 Then
                'CARD ID:13 = King of Hearths
                Form1.op_card5.Image = My.Resources.H13
                Form1.mem_op_card5.Text = 13
                Form1.op_score5.Text = 10
            End If
            If RC = 14 Then
                'CARD ID:14 = Ace of Clubs
                Form1.op_card5.Image = My.Resources.C1
                Form1.mem_op_card5.Text = 14
                Form1.op_score5.Text = 11
            End If
            If RC = 15 Then
                'CARD ID:15 = Two of Clubs
                Form1.op_card5.Image = My.Resources.C2
                Form1.mem_op_card5.Text = 15
                Form1.op_score5.Text = 2
            End If
            If RC = 16 Then
                'CARD ID:16 = Three of Clubs
                Form1.op_card5.Image = My.Resources.C3
                Form1.mem_op_card5.Text = 16
                Form1.op_score5.Text = 3
            End If
            If RC = 17 Then
                'CARD ID:17 = Four of Clubs
                Form1.op_card5.Image = My.Resources.C4
                Form1.mem_op_card5.Text = 17
                Form1.op_score5.Text = 4
            End If
            If RC = 18 Then
                'CARD ID:18 = Five of Clubs
                Form1.op_card5.Image = My.Resources.C5
                Form1.mem_op_card5.Text = 18
                Form1.op_score5.Text = 5
            End If
            If RC = 19 Then
                'CARD ID:19 = Six of Clubs
                Form1.op_card5.Image = My.Resources.C6
                Form1.mem_op_card5.Text = 19
                Form1.op_score5.Text = 6
            End If
            If RC = 20 Then
                'CARD ID:20 = Seven of Clubs
                Form1.op_card5.Image = My.Resources.C7
                Form1.mem_op_card5.Text = 20
                Form1.op_score5.Text = 7
            End If
            If RC = 21 Then
                'CARD ID:21 = Eight of Clubs
                Form1.op_card5.Image = My.Resources.C8
                Form1.mem_op_card5.Text = 21
                Form1.op_score5.Text = 8
            End If
            If RC = 22 Then
                'CARD ID:22 = Nine of Clubs
                Form1.op_card5.Image = My.Resources.C9
                Form1.mem_op_card5.Text = 22
                Form1.op_score5.Text = 9
            End If
            If RC = 23 Then
                'CARD ID:23 = Ten of Clubs
                Form1.op_card5.Image = My.Resources.C10
                Form1.mem_op_card5.Text = 23
                Form1.op_score5.Text = 10
            End If
            If RC = 24 Then
                'CARD ID:24 = Jack of Clubs
                Form1.op_card5.Image = My.Resources.C11
                Form1.mem_op_card5.Text = 24
                Form1.op_score5.Text = 10
            End If
            If RC = 25 Then
                'CARD ID:25 = Queen of Clubs
                Form1.op_card5.Image = My.Resources.C12
                Form1.mem_op_card5.Text = 25
                Form1.op_score5.Text = 10
            End If
            If RC = 26 Then
                'CARD ID:26 = King of Clubs
                Form1.op_card5.Image = My.Resources.C13
                Form1.mem_op_card5.Text = 26
                Form1.op_score5.Text = 10
            End If
            If RC = 27 Then
                'CARD ID:27 = Ace of Diamonds
                Form1.op_card5.Image = My.Resources.D1
                Form1.mem_op_card5.Text = 27
                Form1.op_score5.Text = 11
            End If
            If RC = 28 Then
                'CARD ID:28 = Two of Diamonds
                Form1.op_card5.Image = My.Resources.D2
                Form1.mem_op_card5.Text = 28
                Form1.op_score5.Text = 2
            End If
            If RC = 29 Then
                'CARD ID:27 = Three of Diamonds
                Form1.op_card5.Image = My.Resources.D3
                Form1.mem_op_card5.Text = 29
                Form1.op_score5.Text = 3
            End If
            If RC = 30 Then
                'CARD ID:30 = Four of Diamonds
                Form1.op_card5.Image = My.Resources.D4
                Form1.mem_op_card5.Text = 30
                Form1.op_score5.Text = 4
            End If
            If RC = 31 Then
                'CARD ID:31 = Five of Diamonds
                Form1.op_card5.Image = My.Resources.D5
                Form1.mem_op_card5.Text = 31
                Form1.op_score5.Text = 5
            End If
            If RC = 32 Then
                'CARD ID:32 = Six of Diamonds
                Form1.op_card5.Image = My.Resources.D6
                Form1.mem_op_card5.Text = 32
                Form1.op_score5.Text = 6
            End If
            If RC = 33 Then
                'CARD ID:33 = Seven of Diamonds
                Form1.op_card5.Image = My.Resources.D7
                Form1.mem_op_card5.Text = 33
                Form1.op_score5.Text = 7
            End If
            If RC = 34 Then
                'CARD ID:34 = Eight of Diamonds
                Form1.op_card5.Image = My.Resources.D8
                Form1.mem_op_card5.Text = 34
                Form1.op_score5.Text = 8
            End If
            If RC = 35 Then
                'CARD ID:35 = Nine of Diamonds
                Form1.op_card5.Image = My.Resources.D9
                Form1.mem_op_card5.Text = 35
                Form1.op_score5.Text = 9
            End If
            If RC = 36 Then
                'CARD ID:36 = Ten of Diamonds
                Form1.op_card5.Image = My.Resources.D10
                Form1.mem_op_card5.Text = 36
                Form1.op_score5.Text = 10
            End If
            If RC = 37 Then
                'CARD ID:37 = Jack of Diamonds
                Form1.op_card5.Image = My.Resources.D11
                Form1.mem_op_card5.Text = 37
                Form1.op_score5.Text = 10
            End If
            If RC = 38 Then
                'CARD ID:38 = Queen of Diamonds
                Form1.op_card5.Image = My.Resources.D12
                Form1.mem_op_card5.Text = 38
                Form1.op_score5.Text = 10
            End If
            If RC = 39 Then
                'CARD ID:39 = King of Diamonds
                Form1.op_card5.Image = My.Resources.D13
                Form1.mem_op_card5.Text = 39
                Form1.op_score5.Text = 10
            End If
            If RC = 40 Then
                'CARD ID:40 = Ace of Spades
                Form1.op_card5.Image = My.Resources.S1
                Form1.mem_op_card5.Text = 40
                Form1.op_score5.Text = 11
            End If
            If RC = 41 Then
                'CARD ID:41 = Two of Spades
                Form1.op_card5.Image = My.Resources.S2
                Form1.mem_op_card5.Text = 41
                Form1.op_score5.Text = 2
            End If
            If RC = 42 Then
                'CARD ID:42 = Three of Spades
                Form1.op_card5.Image = My.Resources.S3
                Form1.mem_op_card5.Text = 42
                Form1.op_score5.Text = 3
            End If
            If RC = 43 Then
                'CARD ID:43 = Four of Spades
                Form1.op_card5.Image = My.Resources.S4
                Form1.mem_op_card5.Text = 43
                Form1.op_score5.Text = 4
            End If
            If RC = 44 Then
                'CARD ID:44 = Five of Spades
                Form1.op_card5.Image = My.Resources.S5
                Form1.mem_op_card5.Text = 44
                Form1.op_score5.Text = 5
            End If
            If RC = 45 Then
                'CARD ID:45 = Six of Spades
                Form1.op_card5.Image = My.Resources.S6
                Form1.mem_op_card5.Text = 45
                Form1.op_score5.Text = 6
            End If
            If RC = 46 Then
                'CARD ID:46 = Seven of Spades
                Form1.op_card5.Image = My.Resources.S7
                Form1.mem_op_card5.Text = 46
                Form1.op_score5.Text = 7
            End If
            If RC = 47 Then
                'CARD ID:47 = Eight of Spades
                Form1.op_card5.Image = My.Resources.S8
                Form1.mem_op_card5.Text = 47
                Form1.op_score5.Text = 8
            End If
            If RC = 48 Then
                'CARD ID:48 = Nine of Spades
                Form1.op_card5.Image = My.Resources.S9
                Form1.mem_op_card5.Text = 48
                Form1.op_score5.Text = 9
            End If
            If RC = 49 Then
                'CARD ID:49 = Ten of Spades
                Form1.op_card5.Image = My.Resources.S10
                Form1.mem_op_card5.Text = 49
                Form1.op_score5.Text = 10
            End If
            If RC = 50 Then
                'CARD ID:50 = Jack of Spades
                Form1.op_card5.Image = My.Resources.S11
                Form1.mem_op_card5.Text = 50
                Form1.op_score5.Text = 10
            End If
            If RC = 51 Then
                'CARD ID:51 = Queen of Spades
                Form1.op_card5.Image = My.Resources.S12
                Form1.mem_op_card5.Text = 51
                Form1.op_score5.Text = 10
            End If
            If RC = 52 Then
                'CARD ID:52 = King of Spades
                Form1.op_card5.Image = My.Resources.S13
                Form1.mem_op_card5.Text = 52
                Form1.op_score5.Text = 10
            End If
            Form1.UpdateScore()
        End If
    End Sub

    Public Sub CoverCard(ByVal slot As Integer)
        Form1.out_op_score.Visible = False
        If slot = 1 Then
            Form1.cover1.Visible = True
            Form1.op_card1.Visible = False
            Form1.op_score1.Visible = False
        Else
            If slot = 2 Then
                Form1.cover2.Visible = True
                Form1.op_card2.Visible = False
                Form1.op_score2.Visible = False
            Else
                If slot = 3 Then
                    Form1.cover3.Visible = True
                    Form1.op_card3.Visible = False
                    Form1.op_score3.Visible = False
                Else
                    If slot = 4 Then
                        Form1.cover4.Visible = True
                        Form1.op_card4.Visible = False
                        Form1.op_score4.Visible = False
                    Else
                        If slot = 5 Then
                            Form1.cover5.Visible = True
                            Form1.op_card5.Visible = False
                            Form1.op_score5.Visible = False
                        Else
                            MsgBox("Ops, erro de programação, vai continuar saltando este script", 0, "Ah não!")
                            CoverCard(1)
                        End If
                    End If
                End If
            End If
        End If
    End Sub

    Public Sub UnCoverCard(ByVal slot As Integer)
        Form1.out_op_score.Visible = True
        If slot = 1 Then
            Form1.cover1.Visible = False
            Form1.op_card1.Visible = True
            Form1.op_score1.Visible = True
        Else
            If slot = 2 Then
                Form1.cover2.Visible = False
                Form1.op_card2.Visible = True
                Form1.op_score2.Visible = True
            Else
                If slot = 3 Then
                    Form1.cover3.Visible = False
                    Form1.op_card3.Visible = True
                    Form1.op_score3.Visible = True
                Else
                    If slot = 4 Then
                        Form1.cover4.Visible = False
                        Form1.op_card4.Visible = True
                        Form1.op_score4.Visible = True
                    Else
                        If slot = 5 Then
                            Form1.cover5.Visible = False
                            Form1.op_card5.Visible = True
                            Form1.op_score5.Visible = True
                        Else
                            MsgBox("Ops, erro de programação, vai continuar saltando este script", 0, "Ah não!")
                            UnCoverCard(1)
                        End If
                    End If
                End If
            End If
        End If
    End Sub

    '______________________________________________________________________
    '|####################################################################|
    '|####################################################################|
    '|############/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\############|
    '|############<  @@@   @       @@   @   @  @@@@  @@@     >############|
    '|############<  @  @  @      @  @   @ @   @__   @  @    >############|
    '|############<  @@@   @     @@@@@@   @    @     @@@     >############|
    '|############<  @     @@@@  @    @   @    @@@@  @  @    >############|
    '|############\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/############|
    '|############################\##########/############################|
    '|##############################\||||||/##############################|
    '----------------------------------------------------------------------
    'EMPTY, Moved to Form1



    Private Sub deal_class_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class