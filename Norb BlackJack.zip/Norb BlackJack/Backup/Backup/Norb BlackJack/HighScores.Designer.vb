﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class HighScores
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.score10 = New System.Windows.Forms.Label
        Me.score9 = New System.Windows.Forms.Label
        Me.score8 = New System.Windows.Forms.Label
        Me.score7 = New System.Windows.Forms.Label
        Me.score6 = New System.Windows.Forms.Label
        Me.score5 = New System.Windows.Forms.Label
        Me.score4 = New System.Windows.Forms.Label
        Me.score3 = New System.Windows.Forms.Label
        Me.score2 = New System.Windows.Forms.Label
        Me.score1 = New System.Windows.Forms.Label
        Me.player10 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.player9 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.player8 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.player7 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.player6 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.player5 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.player4 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.player3 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.player2 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.player1 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(1, 4)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(284, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "BlackJack Pontuações Altas"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(6, 14)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(18, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "1."
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.GroupBox2)
        Me.GroupBox1.Controls.Add(Me.player10)
        Me.GroupBox1.Controls.Add(Me.Label20)
        Me.GroupBox1.Controls.Add(Me.player9)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.player8)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.player7)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.player6)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.player5)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.player4)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.player3)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.player2)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.player1)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 37)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(264, 153)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Numero do Jogador"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.score10)
        Me.GroupBox2.Controls.Add(Me.score9)
        Me.GroupBox2.Controls.Add(Me.score8)
        Me.GroupBox2.Controls.Add(Me.score7)
        Me.GroupBox2.Controls.Add(Me.score6)
        Me.GroupBox2.Controls.Add(Me.score5)
        Me.GroupBox2.Controls.Add(Me.score4)
        Me.GroupBox2.Controls.Add(Me.score3)
        Me.GroupBox2.Controls.Add(Me.score2)
        Me.GroupBox2.Controls.Add(Me.score1)
        Me.GroupBox2.Location = New System.Drawing.Point(123, 0)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(141, 153)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Pontuação (Cash)"
        '
        'score10
        '
        Me.score10.AutoSize = True
        Me.score10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.score10.Location = New System.Drawing.Point(7, 133)
        Me.score10.Name = "score10"
        Me.score10.Size = New System.Drawing.Size(13, 13)
        Me.score10.TabIndex = 1
        Me.score10.Text = "0"
        '
        'score9
        '
        Me.score9.AutoSize = True
        Me.score9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.score9.Location = New System.Drawing.Point(7, 120)
        Me.score9.Name = "score9"
        Me.score9.Size = New System.Drawing.Size(13, 13)
        Me.score9.TabIndex = 1
        Me.score9.Text = "0"
        '
        'score8
        '
        Me.score8.AutoSize = True
        Me.score8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.score8.Location = New System.Drawing.Point(7, 107)
        Me.score8.Name = "score8"
        Me.score8.Size = New System.Drawing.Size(13, 13)
        Me.score8.TabIndex = 1
        Me.score8.Text = "0"
        '
        'score7
        '
        Me.score7.AutoSize = True
        Me.score7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.score7.Location = New System.Drawing.Point(7, 94)
        Me.score7.Name = "score7"
        Me.score7.Size = New System.Drawing.Size(13, 13)
        Me.score7.TabIndex = 1
        Me.score7.Text = "0"
        '
        'score6
        '
        Me.score6.AutoSize = True
        Me.score6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.score6.Location = New System.Drawing.Point(7, 81)
        Me.score6.Name = "score6"
        Me.score6.Size = New System.Drawing.Size(13, 13)
        Me.score6.TabIndex = 1
        Me.score6.Text = "0"
        '
        'score5
        '
        Me.score5.AutoSize = True
        Me.score5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.score5.Location = New System.Drawing.Point(7, 68)
        Me.score5.Name = "score5"
        Me.score5.Size = New System.Drawing.Size(13, 13)
        Me.score5.TabIndex = 1
        Me.score5.Text = "0"
        '
        'score4
        '
        Me.score4.AutoSize = True
        Me.score4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.score4.Location = New System.Drawing.Point(7, 55)
        Me.score4.Name = "score4"
        Me.score4.Size = New System.Drawing.Size(13, 13)
        Me.score4.TabIndex = 1
        Me.score4.Text = "0"
        '
        'score3
        '
        Me.score3.AutoSize = True
        Me.score3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.score3.Location = New System.Drawing.Point(7, 42)
        Me.score3.Name = "score3"
        Me.score3.Size = New System.Drawing.Size(13, 13)
        Me.score3.TabIndex = 1
        Me.score3.Text = "0"
        '
        'score2
        '
        Me.score2.AutoSize = True
        Me.score2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.score2.Location = New System.Drawing.Point(7, 29)
        Me.score2.Name = "score2"
        Me.score2.Size = New System.Drawing.Size(13, 13)
        Me.score2.TabIndex = 1
        Me.score2.Text = "0"
        '
        'score1
        '
        Me.score1.AutoSize = True
        Me.score1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.score1.Location = New System.Drawing.Point(6, 14)
        Me.score1.Name = "score1"
        Me.score1.Size = New System.Drawing.Size(14, 13)
        Me.score1.TabIndex = 1
        Me.score1.Text = "0"
        '
        'player10
        '
        Me.player10.AutoSize = True
        Me.player10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.player10.Location = New System.Drawing.Point(30, 133)
        Me.player10.Name = "player10"
        Me.player10.Size = New System.Drawing.Size(10, 13)
        Me.player10.TabIndex = 1
        Me.player10.Text = "-"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(5, 133)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(22, 13)
        Me.Label20.TabIndex = 1
        Me.Label20.Text = "10."
        '
        'player9
        '
        Me.player9.AutoSize = True
        Me.player9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.player9.Location = New System.Drawing.Point(30, 120)
        Me.player9.Name = "player9"
        Me.player9.Size = New System.Drawing.Size(10, 13)
        Me.player9.TabIndex = 1
        Me.player9.Text = "-"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(6, 120)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(16, 13)
        Me.Label18.TabIndex = 1
        Me.Label18.Text = "9."
        '
        'player8
        '
        Me.player8.AutoSize = True
        Me.player8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.player8.Location = New System.Drawing.Point(30, 107)
        Me.player8.Name = "player8"
        Me.player8.Size = New System.Drawing.Size(10, 13)
        Me.player8.TabIndex = 1
        Me.player8.Text = "-"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(6, 107)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(16, 13)
        Me.Label16.TabIndex = 1
        Me.Label16.Text = "8."
        '
        'player7
        '
        Me.player7.AutoSize = True
        Me.player7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.player7.Location = New System.Drawing.Point(30, 94)
        Me.player7.Name = "player7"
        Me.player7.Size = New System.Drawing.Size(10, 13)
        Me.player7.TabIndex = 1
        Me.player7.Text = "-"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(6, 94)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(16, 13)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "7."
        '
        'player6
        '
        Me.player6.AutoSize = True
        Me.player6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.player6.Location = New System.Drawing.Point(30, 81)
        Me.player6.Name = "player6"
        Me.player6.Size = New System.Drawing.Size(10, 13)
        Me.player6.TabIndex = 1
        Me.player6.Text = "-"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(6, 81)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(16, 13)
        Me.Label12.TabIndex = 1
        Me.Label12.Text = "6."
        '
        'player5
        '
        Me.player5.AutoSize = True
        Me.player5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.player5.Location = New System.Drawing.Point(30, 68)
        Me.player5.Name = "player5"
        Me.player5.Size = New System.Drawing.Size(10, 13)
        Me.player5.TabIndex = 1
        Me.player5.Text = "-"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(6, 68)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(16, 13)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "5."
        '
        'player4
        '
        Me.player4.AutoSize = True
        Me.player4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.player4.Location = New System.Drawing.Point(30, 55)
        Me.player4.Name = "player4"
        Me.player4.Size = New System.Drawing.Size(10, 13)
        Me.player4.TabIndex = 1
        Me.player4.Text = "-"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(6, 55)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(16, 13)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "4."
        '
        'player3
        '
        Me.player3.AutoSize = True
        Me.player3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.player3.Location = New System.Drawing.Point(30, 42)
        Me.player3.Name = "player3"
        Me.player3.Size = New System.Drawing.Size(10, 13)
        Me.player3.TabIndex = 1
        Me.player3.Text = "-"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(6, 42)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(16, 13)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "3."
        '
        'player2
        '
        Me.player2.AutoSize = True
        Me.player2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.player2.Location = New System.Drawing.Point(30, 29)
        Me.player2.Name = "player2"
        Me.player2.Size = New System.Drawing.Size(10, 13)
        Me.player2.TabIndex = 1
        Me.player2.Text = "-"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(6, 29)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(16, 13)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "2."
        '
        'player1
        '
        Me.player1.AutoSize = True
        Me.player1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.player1.Location = New System.Drawing.Point(30, 14)
        Me.player1.Name = "player1"
        Me.player1.Size = New System.Drawing.Size(11, 13)
        Me.player1.TabIndex = 1
        Me.player1.Text = "-"
        '
        'HighScores
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(288, 199)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(304, 235)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(304, 235)
        Me.Name = "HighScores"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.Text = "High-Scores"
        Me.TopMost = True
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents player2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents player1 As System.Windows.Forms.Label
    Friend WithEvents player10 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents player9 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents player8 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents player7 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents player6 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents player5 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents player4 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents player3 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents score10 As System.Windows.Forms.Label
    Friend WithEvents score9 As System.Windows.Forms.Label
    Friend WithEvents score8 As System.Windows.Forms.Label
    Friend WithEvents score7 As System.Windows.Forms.Label
    Friend WithEvents score6 As System.Windows.Forms.Label
    Friend WithEvents score5 As System.Windows.Forms.Label
    Friend WithEvents score4 As System.Windows.Forms.Label
    Friend WithEvents score3 As System.Windows.Forms.Label
    Friend WithEvents score2 As System.Windows.Forms.Label
    Friend WithEvents score1 As System.Windows.Forms.Label
End Class
