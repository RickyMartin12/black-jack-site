﻿Public Class HighScores

    Private Sub HighScores_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Me.Text = "Pontuações Máximas"

        Try
            If My.Computer.FileSystem.FileExists("NorbBJhs.dat") Then
                Dim HSReader As IO.StreamReader
                HSReader = My.Computer.FileSystem.OpenTextFileReader("NorbBJhs.dat")
                player1.Text = HSReader.ReadLine
                score1.Text = HSReader.ReadLine
                player2.Text = HSReader.ReadLine
                score2.Text = HSReader.ReadLine
                player3.Text = HSReader.ReadLine
                score3.Text = HSReader.ReadLine
                player4.Text = HSReader.ReadLine
                score4.Text = HSReader.ReadLine
                player5.Text = HSReader.ReadLine
                score5.Text = HSReader.ReadLine
                player6.Text = HSReader.ReadLine
                score6.Text = HSReader.ReadLine
                player7.Text = HSReader.ReadLine
                score7.Text = HSReader.ReadLine
                player8.Text = HSReader.ReadLine
                score8.Text = HSReader.ReadLine
                player9.Text = HSReader.ReadLine
                score9.Text = HSReader.ReadLine
                player10.Text = HSReader.ReadLine
                score10.Text = HSReader.ReadLine
                HSReader.Close()
            Else
                MsgBox("Não é possível encontrar pontos de alta", 0, "Ficheiro não encontrado")
                Close()
            End If
        Catch ex As Exception
            MsgBox("Não é possível ler de alta pontuação, tente executar como administrador", 0, "Não é possível ler o arquivo")
        End Try

    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub
End Class